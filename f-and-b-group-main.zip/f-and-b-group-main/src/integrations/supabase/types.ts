export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  public: {
    Tables: {
      DocumentStatus: {
        Row: {
          createdAt: string
          documentType: Database["public"]["Enums"]["DocumentType"]
          farmerId: number
          id: number
          notes: string | null
          status: Database["public"]["Enums"]["VerificationStatus"]
          submissionDate: string | null
          updatedAt: string
          verificationDate: string | null
        }
        Insert: {
          createdAt?: string
          documentType: Database["public"]["Enums"]["DocumentType"]
          farmerId: number
          id?: number
          notes?: string | null
          status?: Database["public"]["Enums"]["VerificationStatus"]
          submissionDate?: string | null
          updatedAt: string
          verificationDate?: string | null
        }
        Update: {
          createdAt?: string
          documentType?: Database["public"]["Enums"]["DocumentType"]
          farmerId?: number
          id?: number
          notes?: string | null
          status?: Database["public"]["Enums"]["VerificationStatus"]
          submissionDate?: string | null
          updatedAt?: string
          verificationDate?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "DocumentStatus_farmerId_fkey"
            columns: ["farmerId"]
            isOneToOne: false
            referencedRelation: "Farmer"
            referencedColumns: ["id"]
          },
        ]
      }
      Example: {
        Row: {
          createdAt: string
          id: number
        }
        Insert: {
          createdAt?: string
          id?: number
        }
        Update: {
          createdAt?: string
          id?: number
        }
        Relationships: []
      }
      Farmer: {
        Row: {
          aadhaarNumber: string | null
          address: string | null
          block: string
          createdAt: string
          district: string
          id: number
          irrigationType: Database["public"]["Enums"]["IrrigationType"]
          land_holding: number | null
          name: string
          phoneNumber: string | null
          updatedAt: string
          village: string | null
        }
        Insert: {
          aadhaarNumber?: string | null
          address?: string | null
          block: string
          createdAt?: string
          district: string
          id?: number
          irrigationType: Database["public"]["Enums"]["IrrigationType"]
          land_holding?: number | null
          name: string
          phoneNumber?: string | null
          updatedAt: string
          village?: string | null
        }
        Update: {
          aadhaarNumber?: string | null
          address?: string | null
          block?: string
          createdAt?: string
          district?: string
          id?: number
          irrigationType?: Database["public"]["Enums"]["IrrigationType"]
          land_holding?: number | null
          name?: string
          phoneNumber?: string | null
          updatedAt?: string
          village?: string | null
        }
        Relationships: []
      }
      farmers: {
        Row: {
          aadhar_number: string | null
          beneficiary_name: string
          beneficiary_type: string | null
          block_name: string | null
          created_at: string | null
          crop_spacing: string | null
          crop_type: string | null
          current_status: string | null
          dealer_name: string | null
          district_name: string | null
          doc_upload_status: string | null
          enrollment_number: string | null
          epic_number: string | null
          farmer_category: string | null
          farmer_status: string | null
          financial_year: string | null
          gram_panchayet: string | null
          id: string
          indicative_cost: string | null
          irrigation_area: string | null
          irrigation_type: string | null
          is_pump_available: string | null
          mobile_number: string | null
          mouza_name: string | null
          other_water_source: string | null
          pincode: string | null
          police_station: string | null
          post_office: string | null
          pump_capacity: string | null
          pump_type: string | null
          registration_date: string | null
          registration_number: string | null
          sex: string | null
          sub_division: string | null
          updated_at: string | null
          water_source: string | null
        }
        Insert: {
          aadhar_number?: string | null
          beneficiary_name: string
          beneficiary_type?: string | null
          block_name?: string | null
          created_at?: string | null
          crop_spacing?: string | null
          crop_type?: string | null
          current_status?: string | null
          dealer_name?: string | null
          district_name?: string | null
          doc_upload_status?: string | null
          enrollment_number?: string | null
          epic_number?: string | null
          farmer_category?: string | null
          farmer_status?: string | null
          financial_year?: string | null
          gram_panchayet?: string | null
          id?: string
          indicative_cost?: string | null
          irrigation_area?: string | null
          irrigation_type?: string | null
          is_pump_available?: string | null
          mobile_number?: string | null
          mouza_name?: string | null
          other_water_source?: string | null
          pincode?: string | null
          police_station?: string | null
          post_office?: string | null
          pump_capacity?: string | null
          pump_type?: string | null
          registration_date?: string | null
          registration_number?: string | null
          sex?: string | null
          sub_division?: string | null
          updated_at?: string | null
          water_source?: string | null
        }
        Update: {
          aadhar_number?: string | null
          beneficiary_name?: string
          beneficiary_type?: string | null
          block_name?: string | null
          created_at?: string | null
          crop_spacing?: string | null
          crop_type?: string | null
          current_status?: string | null
          dealer_name?: string | null
          district_name?: string | null
          doc_upload_status?: string | null
          enrollment_number?: string | null
          epic_number?: string | null
          farmer_category?: string | null
          farmer_status?: string | null
          financial_year?: string | null
          gram_panchayet?: string | null
          id?: string
          indicative_cost?: string | null
          irrigation_area?: string | null
          irrigation_type?: string | null
          is_pump_available?: string | null
          mobile_number?: string | null
          mouza_name?: string | null
          other_water_source?: string | null
          pincode?: string | null
          police_station?: string | null
          post_office?: string | null
          pump_capacity?: string | null
          pump_type?: string | null
          registration_date?: string | null
          registration_number?: string | null
          sex?: string | null
          sub_division?: string | null
          updated_at?: string | null
          water_source?: string | null
        }
        Relationships: []
      }
      Invoice: {
        Row: {
          amount: number
          billingDate: string
          createdAt: string
          dueDate: string | null
          id: number
          invoiceNumber: string
          paidDate: string | null
          status: Database["public"]["Enums"]["InvoiceStatus"]
          subsidyId: number
          updatedAt: string
        }
        Insert: {
          amount: number
          billingDate: string
          createdAt?: string
          dueDate?: string | null
          id?: number
          invoiceNumber: string
          paidDate?: string | null
          status?: Database["public"]["Enums"]["InvoiceStatus"]
          subsidyId: number
          updatedAt: string
        }
        Update: {
          amount?: number
          billingDate?: string
          createdAt?: string
          dueDate?: string | null
          id?: number
          invoiceNumber?: string
          paidDate?: string | null
          status?: Database["public"]["Enums"]["InvoiceStatus"]
          subsidyId?: number
          updatedAt?: string
        }
        Relationships: [
          {
            foreignKeyName: "Invoice_subsidyId_fkey"
            columns: ["subsidyId"]
            isOneToOne: false
            referencedRelation: "Subsidy"
            referencedColumns: ["id"]
          },
        ]
      }
      invoices: {
        Row: {
          amount: number | null
          approved_on: string | null
          bill_date: string | null
          bill_no: string | null
          bksy_amount_paid: number | null
          bksy_cgst: number | null
          bksy_paid_by: string | null
          bksy_released_on: string | null
          bksy_sgst: number | null
          bksy_subsidy: number | null
          bksy_subsidy_addl: number | null
          bksy_tds: number | null
          bksy_transaction_date: string | null
          bksy_transaction_ref: string | null
          created_at: string | null
          dlic_date: string | null
          dlic_number: string | null
          farmer_id: string | null
          farmers_share: number | null
          farmers_share_addl: number | null
          financial_year: string | null
          gst_amount: number | null
          gst_amount_addl: number | null
          id: string
          inspection_date: string | null
          installation_date: string | null
          joint_insp_date: string | null
          paid_by_farmer: number | null
          payment_date: string | null
          payment_reference: string | null
          pmksy_amount_paid: number | null
          pmksy_cgst: number | null
          pmksy_paid_by: string | null
          pmksy_released_on: string | null
          pmksy_sgst: number | null
          pmksy_subsidy: number | null
          pmksy_subsidy_addl: number | null
          pmksy_tds: number | null
          pmksy_transaction_date: string | null
          pmksy_transaction_ref: string | null
          quot_approval_date: string | null
          quotation_date: string | null
          quotation_no: string | null
          tax_inv_no: string | null
          total_farmer_share: number | null
          total_subsidy: number | null
          type_of_payment: string | null
          updated_at: string | null
          work_order_date: string | null
          work_order_memo: string | null
        }
        Insert: {
          amount?: number | null
          approved_on?: string | null
          bill_date?: string | null
          bill_no?: string | null
          bksy_amount_paid?: number | null
          bksy_cgst?: number | null
          bksy_paid_by?: string | null
          bksy_released_on?: string | null
          bksy_sgst?: number | null
          bksy_subsidy?: number | null
          bksy_subsidy_addl?: number | null
          bksy_tds?: number | null
          bksy_transaction_date?: string | null
          bksy_transaction_ref?: string | null
          created_at?: string | null
          dlic_date?: string | null
          dlic_number?: string | null
          farmer_id?: string | null
          farmers_share?: number | null
          farmers_share_addl?: number | null
          financial_year?: string | null
          gst_amount?: number | null
          gst_amount_addl?: number | null
          id?: string
          inspection_date?: string | null
          installation_date?: string | null
          joint_insp_date?: string | null
          paid_by_farmer?: number | null
          payment_date?: string | null
          payment_reference?: string | null
          pmksy_amount_paid?: number | null
          pmksy_cgst?: number | null
          pmksy_paid_by?: string | null
          pmksy_released_on?: string | null
          pmksy_sgst?: number | null
          pmksy_subsidy?: number | null
          pmksy_subsidy_addl?: number | null
          pmksy_tds?: number | null
          pmksy_transaction_date?: string | null
          pmksy_transaction_ref?: string | null
          quot_approval_date?: string | null
          quotation_date?: string | null
          quotation_no?: string | null
          tax_inv_no?: string | null
          total_farmer_share?: number | null
          total_subsidy?: number | null
          type_of_payment?: string | null
          updated_at?: string | null
          work_order_date?: string | null
          work_order_memo?: string | null
        }
        Update: {
          amount?: number | null
          approved_on?: string | null
          bill_date?: string | null
          bill_no?: string | null
          bksy_amount_paid?: number | null
          bksy_cgst?: number | null
          bksy_paid_by?: string | null
          bksy_released_on?: string | null
          bksy_sgst?: number | null
          bksy_subsidy?: number | null
          bksy_subsidy_addl?: number | null
          bksy_tds?: number | null
          bksy_transaction_date?: string | null
          bksy_transaction_ref?: string | null
          created_at?: string | null
          dlic_date?: string | null
          dlic_number?: string | null
          farmer_id?: string | null
          farmers_share?: number | null
          farmers_share_addl?: number | null
          financial_year?: string | null
          gst_amount?: number | null
          gst_amount_addl?: number | null
          id?: string
          inspection_date?: string | null
          installation_date?: string | null
          joint_insp_date?: string | null
          paid_by_farmer?: number | null
          payment_date?: string | null
          payment_reference?: string | null
          pmksy_amount_paid?: number | null
          pmksy_cgst?: number | null
          pmksy_paid_by?: string | null
          pmksy_released_on?: string | null
          pmksy_sgst?: number | null
          pmksy_subsidy?: number | null
          pmksy_subsidy_addl?: number | null
          pmksy_tds?: number | null
          pmksy_transaction_date?: string | null
          pmksy_transaction_ref?: string | null
          quot_approval_date?: string | null
          quotation_date?: string | null
          quotation_no?: string | null
          tax_inv_no?: string | null
          total_farmer_share?: number | null
          total_subsidy?: number | null
          type_of_payment?: string | null
          updated_at?: string | null
          work_order_date?: string | null
          work_order_memo?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "invoices_farmer_id_fkey"
            columns: ["farmer_id"]
            isOneToOne: false
            referencedRelation: "farmers"
            referencedColumns: ["id"]
          },
        ]
      }
      PaymentStatus: {
        Row: {
          amount: number
          createdAt: string
          farmerId: number
          id: number
          notes: string | null
          paymentDate: string | null
          status: Database["public"]["Enums"]["PaymentStatusType"]
          transactionId: string | null
          updatedAt: string
        }
        Insert: {
          amount: number
          createdAt?: string
          farmerId: number
          id?: number
          notes?: string | null
          paymentDate?: string | null
          status?: Database["public"]["Enums"]["PaymentStatusType"]
          transactionId?: string | null
          updatedAt: string
        }
        Update: {
          amount?: number
          createdAt?: string
          farmerId?: number
          id?: number
          notes?: string | null
          paymentDate?: string | null
          status?: Database["public"]["Enums"]["PaymentStatusType"]
          transactionId?: string | null
          updatedAt?: string
        }
        Relationships: [
          {
            foreignKeyName: "PaymentStatus_farmerId_fkey"
            columns: ["farmerId"]
            isOneToOne: false
            referencedRelation: "Farmer"
            referencedColumns: ["id"]
          },
        ]
      }
      Subsidy: {
        Row: {
          amount: number
          createdAt: string
          dateApproved: string | null
          dateDistributed: string | null
          farmerId: number
          financial_year: string
          id: number
          schemeType: Database["public"]["Enums"]["SchemeType"]
          status: Database["public"]["Enums"]["SubsidyStatus"]
          updatedAt: string
        }
        Insert: {
          amount: number
          createdAt?: string
          dateApproved?: string | null
          dateDistributed?: string | null
          farmerId: number
          financial_year: string
          id?: number
          schemeType: Database["public"]["Enums"]["SchemeType"]
          status?: Database["public"]["Enums"]["SubsidyStatus"]
          updatedAt: string
        }
        Update: {
          amount?: number
          createdAt?: string
          dateApproved?: string | null
          dateDistributed?: string | null
          farmerId?: number
          financial_year?: string
          id?: number
          schemeType?: Database["public"]["Enums"]["SchemeType"]
          status?: Database["public"]["Enums"]["SubsidyStatus"]
          updatedAt?: string
        }
        Relationships: [
          {
            foreignKeyName: "Subsidy_farmerId_fkey"
            columns: ["farmerId"]
            isOneToOne: false
            referencedRelation: "Farmer"
            referencedColumns: ["id"]
          },
        ]
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      [_ in never]: never
    }
    Enums: {
      DocumentType:
        | "AADHAAR"
        | "LAND_RECORD"
        | "BANK_DETAILS"
        | "APPLICATION_FORM"
        | "OTHER"
      InvoiceStatus: "PENDING" | "PAID" | "OVERDUE" | "CANCELLED"
      IrrigationType: "DRIP" | "SPRINKLER" | "SURFACE" | "OTHER"
      PaymentStatusType: "PENDING" | "PROCESSING" | "COMPLETED" | "FAILED"
      SchemeType: "PMKSY" | "BKSY"
      SubsidyStatus: "PENDING" | "APPROVED" | "REJECTED" | "DISTRIBUTED"
      VerificationStatus: "PENDING" | "VERIFIED" | "REJECTED"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DefaultSchema = Database[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof Database },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof Database
  }
    ? keyof (Database[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        Database[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends { schema: keyof Database }
  ? (Database[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      Database[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof Database },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof Database
  }
    ? keyof Database[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends { schema: keyof Database }
  ? Database[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof Database },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof Database
  }
    ? keyof Database[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends { schema: keyof Database }
  ? Database[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof Database },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof Database
  }
    ? keyof Database[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends { schema: keyof Database }
  ? Database[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof Database },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof Database
  }
    ? keyof Database[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends { schema: keyof Database }
  ? Database[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      DocumentType: [
        "AADHAAR",
        "LAND_RECORD",
        "BANK_DETAILS",
        "APPLICATION_FORM",
        "OTHER",
      ],
      InvoiceStatus: ["PENDING", "PAID", "OVERDUE", "CANCELLED"],
      IrrigationType: ["DRIP", "SPRINKLER", "SURFACE", "OTHER"],
      PaymentStatusType: ["PENDING", "PROCESSING", "COMPLETED", "FAILED"],
      SchemeType: ["PMKSY", "BKSY"],
      SubsidyStatus: ["PENDING", "APPROVED", "REJECTED", "DISTRIBUTED"],
      VerificationStatus: ["PENDING", "VERIFIED", "REJECTED"],
    },
  },
} as const
