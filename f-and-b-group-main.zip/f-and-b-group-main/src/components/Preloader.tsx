
import React, { useEffect, useState } from 'react';
import { useAppContext } from '@/context/AppContext';

const Preloader = () => {
  const { loading, blockSummaries } = useAppContext();
  const [hide, setHide] = useState(false);
  const [fadeOut, setFadeOut] = useState(false);
  
  useEffect(() => {
    // Only start the fade-out when loading is complete AND we have data
    if (!loading && blockSummaries.length > 0) {
      // Start fade out animation
      setFadeOut(true);
      
      // After animation completes, hide the preloader
      const timer = setTimeout(() => {
        setHide(true);
      }, 1000); // Match this to the transition duration
      
      return () => clearTimeout(timer);
    } else {
      // Reset if loading starts again or no data
      setFadeOut(false);
      setHide(false);
    }
  }, [loading, blockSummaries]);
  
  // If hide is true, don't render the component
  if (hide) return null;
  
  return (
    <div className={`fixed inset-0 z-50 flex items-center justify-center bg-white transition-opacity duration-1000 ${fadeOut ? 'opacity-0' : 'opacity-100'}`}>
      <div className="w-full max-w-[400px] p-8 relative flex flex-col items-center">
        {/* Modern Preloader Animation */}
        <div className="mb-8 relative w-32 h-32">
          <svg viewBox="0 0 100 100" className="w-full h-full">
            {/* Circular track */}
            <circle 
              cx="50" 
              cy="50" 
              r="40" 
              stroke="#e6e8eb" 
              strokeWidth="8" 
              fill="none" 
            />
            
            {/* Progress circle with animation */}
            <circle 
              cx="50" 
              cy="50" 
              r="40" 
              stroke="#10b981" 
              strokeWidth="8" 
              fill="none" 
              strokeLinecap="round" 
              strokeDasharray="251.2" 
              strokeDashoffset="125.6" 
              className="origin-center animate-[spin_2s_linear_infinite] transition-all" 
            />
            
            {/* Plant icon in center */}
            <path 
              d="M50,30 C50,30 45,40 45,50 C45,55 50,60 50,60 C50,60 55,55 55,50 C55,40 50,30 50,30 Z" 
              fill="#10b981" 
              className="origin-bottom animate-[growShrink_3s_ease-in-out_infinite]" 
            />
            <path 
              d="M40,40 C45,35 50,38 50,38 C50,38 50,45 45,48 C40,52 35,48 35,48 C35,48 35,45 40,40 Z" 
              fill="#10b981" 
              className="origin-center animate-[sway_4s_ease-in-out_infinite_alternate]" 
            />
            <path 
              d="M60,40 C55,35 50,38 50,38 C50,38 50,45 55,48 C60,52 65,48 65,48 C65,48 65,45 60,40 Z" 
              fill="#10b981" 
              className="origin-center animate-[sway_4s_ease-in-out_infinite_alternate-reverse]" 
            />
            
            {/* Water drop animation */}
            <g className="animate-[dropWater_2s_ease-in-out_infinite]">
              <circle 
                cx="50" 
                cy="20" 
                r="3" 
                fill="#3b82f6" 
              />
            </g>
          </svg>
        </div>
        
        {/* Loading text */}
        <div className="text-center">
          <div className="text-2xl font-bold text-gray-800 mb-2">
            <div className="flex items-center justify-center">
              <span className="inline-block animate-[bounce_1s_ease-in-out_infinite_-320ms]">L</span>
              <span className="inline-block animate-[bounce_1s_ease-in-out_infinite_-280ms]">o</span>
              <span className="inline-block animate-[bounce_1s_ease-in-out_infinite_-240ms]">a</span>
              <span className="inline-block animate-[bounce_1s_ease-in-out_infinite_-200ms]">d</span>
              <span className="inline-block animate-[bounce_1s_ease-in-out_infinite_-160ms]">i</span>
              <span className="inline-block animate-[bounce_1s_ease-in-out_infinite_-120ms]">n</span>
              <span className="inline-block animate-[bounce_1s_ease-in-out_infinite_-80ms]">g</span>
              <span className="inline-block animate-[bounce_1s_ease-in-out_infinite_-40ms]">.</span>
              <span className="inline-block animate-[bounce_1s_ease-in-out_infinite]">.</span>
              <span className="inline-block animate-[bounce_1s_ease-in-out_infinite_-40ms]">.</span>
            </div>
          </div>
          <p className="text-gray-500">Please wait while we load your data</p>
        </div>

        {/* Improved Progress bar with animated gradient */}
        <div className="w-full max-w-[300px] h-2 bg-gray-100 rounded-full mt-8 overflow-hidden relative">
          <div className="h-full bg-gradient-to-r from-emerald-500 via-blue-500 to-emerald-500 animate-gradientFlow rounded-full absolute inset-0"></div>
        </div>

        <style>{`
          @keyframes gradientFlow {
            0% { background-position: 0% 50%; transform: translateX(-100%); }
            50% { background-position: 100% 50%; transform: translateX(0%); }
            100% { background-position: 0% 50%; transform: translateX(100%); }
          }
          
          @keyframes sway {
            0% { transform: rotate(-5deg); }
            100% { transform: rotate(5deg); }
          }
          
          @keyframes growShrink {
            0% { transform: scaleY(0.9); }
            50% { transform: scaleY(1.1); }
            100% { transform: scaleY(0.9); }
          }
          
          @keyframes dropWater {
            0% { transform: translateY(-10px); opacity: 0; }
            50% { transform: translateY(30px); opacity: 1; }
            80% { opacity: 0; }
            100% { transform: translateY(50px); opacity: 0; }
          }
        `}</style>
      </div>
    </div>
  );
};

export default Preloader;
