
import React, { useMemo } from 'react';
import { useAppContext } from '../context/AppContext';
import { Download, FileText } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useNavigate } from 'react-router-dom';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Drawer, DrawerContent, DrawerHeader, DrawerTitle, DrawerDescription } from "@/components/ui/drawer";
import { useIsMobile } from '@/hooks/use-mobile';
import {
  Table,
  TableHeader,
  TableBody,
  TableHead,
  TableRow,
  TableCell
} from '@/components/ui/table';
import { ScrollArea } from '@/components/ui/scroll-area';

const MissingDocsReport = ({ isOpen, onClose }) => {
  const { filteredFarmerData } = useAppContext();
  const navigate = useNavigate();
  const isMobile = useIsMobile();

  // Filter farmers with "installed & inspected" status and "Insp. File Missing" document status
  // Using the same criteria as in FarmersPage
  const missingDocsFarmers = useMemo(() => {
    return filteredFarmerData.filter(farmer => 
      farmer.currentStatus?.toLowerCase().includes('install') && 
      farmer.currentStatus?.toLowerCase().includes('inspected') && 
      (!farmer.docUploadStatus || farmer.docUploadStatus === 'Insp. File Missing')
    );
  }, [filteredFarmerData]);

  const exportToCSV = () => {
    const headers = [
      'Name', 
      'Registration Number', 
      'Mobile Number',
      'Block',
      'District',
      'Status',
      'Irrigation Type'
    ].join(',');
    
    const rows = missingDocsFarmers.map(farmer => [
      `"${farmer.beneficiaryName || ''}"`,
      `"${farmer.farmerRegistrationNumber || ''}"`,
      `"${farmer.mobileNumber || farmer.mobileNo || ''}"`,
      `"${farmer.blockName || ''}"`,
      `"${farmer.districtName || ''}"`,
      `"${farmer.currentStatus || ''}"`,
      `"${farmer.irrigationType || ''}"`
    ].join(','));
    
    const csvContent = [headers, ...rows].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', 'missing_docs_farmers.csv');
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const renderContent = () => (
    <>
      <div className="flex justify-end mb-4">
        <Button 
          onClick={exportToCSV}
          disabled={missingDocsFarmers.length === 0}
          variant="outline"
          className="flex items-center gap-2"
        >
          <Download className="h-4 w-4 mr-2" />
          Export CSV
        </Button>
      </div>
        
      {/* Farmers Table - Updated to match the style of other tables */}
      <div className="bg-white rounded-lg shadow-sm p-4 mb-6 overflow-hidden border">
        <h3 className="text-md font-semibold mb-3">Farmers List</h3>
        {missingDocsFarmers.length > 0 ? (
          <ScrollArea className="h-[60vh] md:h-[500px]">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Name</TableHead>
                  <TableHead>Registration No.</TableHead>
                  <TableHead>Mobile</TableHead>
                  <TableHead>Block</TableHead>
                  <TableHead>Irrigation Type</TableHead>
                  <TableHead>Doc Status</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {missingDocsFarmers.map((farmer, index) => (
                  <TableRow key={index}>
                    <TableCell className="font-medium">{farmer.beneficiaryName || 'N/A'}</TableCell>
                    <TableCell>{farmer.farmerRegistrationNumber || 'N/A'}</TableCell>
                    <TableCell>{farmer.mobileNumber || farmer.mobileNo || 'N/A'}</TableCell>
                    <TableCell>{farmer.blockName || 'N/A'}</TableCell>
                    <TableCell>{farmer.irrigationType || 'N/A'}</TableCell>
                    <TableCell>{farmer.docUploadStatus || 'Missing'}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </ScrollArea>
        ) : (
          <div className="text-center py-10">
            <p className="text-gray-500">No farmers found with missing documentation.</p>
          </div>
        )}
        {missingDocsFarmers.length > 0 && (
          <div className="mt-4 text-right">
            <span className="text-sm text-gray-500">Showing {missingDocsFarmers.length} of {missingDocsFarmers.length} farmers</span>
          </div>
        )}
      </div>
    </>
  );

  return isMobile ? (
    <Drawer open={isOpen} onOpenChange={onClose}>
      <DrawerContent className="h-[90vh] overflow-y-auto pt-10">
        <DrawerHeader className="pb-4">
          <DrawerTitle>Missing Documentation Report</DrawerTitle>
          <DrawerDescription>
            Installed & Inspected farmers with missing inspection documentation: {missingDocsFarmers.length}
          </DrawerDescription>
        </DrawerHeader>
        <div className="px-4 pb-8">
          {renderContent()}
        </div>
      </DrawerContent>
    </Drawer>
  ) : (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-7xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Missing Documentation Report</DialogTitle>
          <DialogDescription>
            Installed & Inspected farmers with missing inspection documentation: {missingDocsFarmers.length}
          </DialogDescription>
        </DialogHeader>
        {renderContent()}
      </DialogContent>
    </Dialog>
  );
};

export default MissingDocsReport;
