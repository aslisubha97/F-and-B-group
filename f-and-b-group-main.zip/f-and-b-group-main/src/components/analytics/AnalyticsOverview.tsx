
import React, { useState, useMemo } from 'react';
import { useAppContext } from '../../context/AppContext';
import { Filter, BarChart2, PieChart } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent } from '@/components/ui/card';
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, Cell, PieChart as RechartsPieChart, Pie } from 'recharts';

// Define status colors for consistency
const STATUS_COLORS = {
  'new registration': '#FCD34D',
  // Yellow
  'joint inspection': '#a0d5a1',
  // Green
  'work order': '#7DE3E1',
  // Teal
  'installed & inspected': '#f5abfc',
  // Pink/Purple
  'installed': '#93c2fd',
  // Blue
  'default': '#6B7280' // Gray
};

// Get status color based on status text
const getStatusColor = (status: string) => {
  const statusLower = status.toLowerCase();
  if (statusLower.includes('new registration')) return STATUS_COLORS['new registration'];
  if (statusLower.includes('joint inspection')) return STATUS_COLORS['joint inspection'];
  if (statusLower.includes('work order')) return STATUS_COLORS['work order'];
  if (statusLower.includes('installed') && statusLower.includes('inspected')) return STATUS_COLORS['installed & inspected'];
  if (statusLower.includes('installed') || statusLower.includes('install')) return STATUS_COLORS['installed'];
  return STATUS_COLORS['default'];
};

// Chart Card Component
const ChartCard = ({
  title,
  subtitle = "",
  data = [],
  renderChart,
  icon,
  height = "h-64"
}: any) => {
  return <Card className="shadow-sm hover:shadow-md transition-shadow">
      <div className="p-4 pb-2">
        <div className="flex justify-between items-center">
          <h3 className="text-lg font-medium flex items-center">
            {icon && React.cloneElement(icon, {
            className: "h-5 w-5 mr-2 text-emerald-600"
          })}
            {title}
          </h3>
        </div>
        {subtitle && <p className="text-sm text-gray-500">{subtitle}</p>}
      </div>
      <div className={`${height} pt-0 px-4`}>
        {renderChart()}
      </div>
    </Card>;
};

// Render Chart Component
const renderChartComponent = (data: any[], chartType: string) => {
  if (!data || data.length === 0) {
    return <div className="flex flex-col items-center justify-center h-full">
        <PieChart className="h-12 w-12 text-gray-300 mb-2" />
        <p className="text-gray-500">No data available</p>
      </div>;
  }
  if (chartType === 'pie') {
    return <ResponsiveContainer width="100%" height="100%">
        <RechartsPieChart>
          <Pie data={data} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={80} labelLine={false} label={({
          name,
          percent
        }) => `${name}: ${(percent * 100).toFixed(0)}%`}>
            {data.map((entry, index) => <Cell key={`cell-${index}`} fill={entry.color} stroke="#fff" strokeWidth={2} />)}
          </Pie>
          <Tooltip formatter={value => [`${value} farmers`, 'Count']} />
          <Legend verticalAlign="bottom" layout="horizontal" />
        </RechartsPieChart>
      </ResponsiveContainer>;
  } else {
    return <ResponsiveContainer width="100%" height="100%">
        <BarChart data={data} layout="vertical" margin={{
        top: 5,
        right: 20,
        left: 60,
        bottom: 15
      }} barSize={chartType === 'horizontal' ? 15 : 15}>
          <CartesianGrid strokeDasharray="3 3" opacity={0.1} horizontal={true} vertical={false} />
          <XAxis type="number" />
          <YAxis dataKey="name" type="category" width={100} tick={{
          fontSize: 12
        }} interval={0} />
          <Tooltip formatter={value => [`${value} farmers`, 'Count']} />
          <Bar dataKey="value" name="Number of Farmers" radius={[0, 4, 4, 0]}>
            {data.map((entry, index) => <Cell key={`cell-${index}`} fill={entry.color} />)}
          </Bar>
        </BarChart>
      </ResponsiveContainer>;
  }
};

// Analytics Overview Component
const AnalyticsOverview = () => {
  const {
    filteredFarmerData
  } = useAppContext();
  const [blockFilter, setBlockFilter] = useState('all');
  const [irrigationFilter, setIrrigationFilter] = useState('all');

  // Compute unique blocks and irrigation types for filters
  const blocks = useMemo(() => {
    const uniqueBlocks = Array.from(new Set(filteredFarmerData.map(farmer => farmer.blockName))).filter(Boolean).sort();
    return ['all', ...uniqueBlocks];
  }, [filteredFarmerData]);
  const irrigationTypes = useMemo(() => {
    const uniqueTypes = Array.from(new Set(filteredFarmerData.map(farmer => farmer.irrigationType))).filter(Boolean).sort();
    return ['all', ...uniqueTypes];
  }, [filteredFarmerData]);

  // Filter data based on current selections
  const displayData = useMemo(() => {
    return filteredFarmerData.filter(farmer => {
      const matchesBlock = blockFilter === 'all' || farmer.blockName === blockFilter;
      const matchesIrrigation = irrigationFilter === 'all' || farmer.irrigationType === irrigationFilter;
      return matchesBlock && matchesIrrigation;
    });
  }, [filteredFarmerData, blockFilter, irrigationFilter]);

  // Status count data for charts
  const statusData = useMemo(() => {
    const statusCounts: Record<string, number> = {};
    displayData.forEach(farmer => {
      const status = farmer.currentStatus || 'Unknown Status';
      statusCounts[status] = (statusCounts[status] || 0) + 1;
    });
    return Object.entries(statusCounts).map(([name, value]) => ({
      name: name.length > 20 ? name.substring(0, 20) + '...' : name,
      value: Number(value),
      color: getStatusColor(name)
    })).sort((a, b) => b.value - a.value);
  }, [displayData]);

  // Gender distribution data
  const genderData = useMemo(() => {
    const maleCount = displayData.filter(farmer => farmer.sex?.toLowerCase() === 'male').length;
    const femaleCount = displayData.filter(farmer => farmer.sex?.toLowerCase() === 'female').length;
    const otherCount = displayData.length - maleCount - femaleCount;
    return [{
      name: 'Male',
      value: Number(maleCount),
      color: '#0369A1'
    }, {
      name: 'Female',
      value: Number(femaleCount),
      color: '#DB2777'
    }, {
      name: 'Not Specified',
      value: Number(otherCount),
      color: '#9CA3AF'
    }].filter(item => item.value > 0);
  }, [displayData]);

  // District count data with consistent colors
  const districtData = useMemo(() => {
    const districtCounts: Record<string, number> = {};
    displayData.forEach(farmer => {
      const district = farmer.districtName || 'Unknown District';
      districtCounts[district] = (districtCounts[district] || 0) + 1;
    });
    const colors = ['#34D399', '#60A5FA', '#F472B6', '#FBBF24', '#A78BFA', '#FB7185', '#38BDF8'];
    return Object.entries(districtCounts).map(([name, value], index) => ({
      name,
      value: Number(value),
      color: colors[index % colors.length]
    })).sort((a, b) => b.value - a.value);
  }, [displayData]);

  // Block count data
  const blockData = useMemo(() => {
    const blockCounts: Record<string, number> = {};
    displayData.forEach(farmer => {
      const block = farmer.blockName || 'Unknown Block';
      blockCounts[block] = (blockCounts[block] || 0) + 1;
    });
    const colors = ['#4DD4AC', '#38BDF8', '#FB7185', '#FACC15', '#C084FC', '#F43F5E', '#0EA5E9', '#8B5CF6', '#F59E0B', '#EC4899'];
    return Object.entries(blockCounts).map(([name, value], index) => ({
      name,
      value: Number(value),
      color: colors[index % colors.length]
    })).sort((a, b) => b.value - a.value).slice(0, 10); // Take top 10
  }, [displayData]);

  // Irrigation type data
  const irrigationData = useMemo(() => {
    const typeCounts: Record<string, number> = {};
    displayData.forEach(farmer => {
      const type = farmer.irrigationType || 'Unknown Type';
      typeCounts[type] = (typeCounts[type] || 0) + 1;
    });
    const colors = ['#0EA5E9', '#10B981', '#F59E0B', '#8B5CF6', '#EC4899', '#6366F1', '#F97316'];
    return Object.entries(typeCounts).map(([name, value], index) => ({
      name: name.length > 15 ? name.substring(0, 15) + '...' : name,
      value: Number(value),
      color: colors[index % colors.length]
    }));
  }, [displayData]);

  // Key stats
  // Updated logic - only consider "Installed & Inspected" as completed
  const completedCount = displayData.filter(f => {
    if (!f.currentStatus) return false;
    const status = f.currentStatus.toLowerCase();
    return status.includes('install') && status.includes('inspect');
  }).length;
  
  // Not completed is everything except "Installed & Inspected"
  const notCompletedCount = displayData.length - completedCount;

  return <div className="space-y-6 animate-fade-in">
      {/* Key Stats Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="bg-gradient-to-br from-emerald-50 to-white border-l-4 border-emerald-500">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-emerald-600">Total Farmers</p>
                <p className="text-3xl font-bold text-gray-800 mt-1">{displayData.length}</p>
              </div>
              <div className="h-12 w-12 bg-emerald-100 rounded-full flex items-center justify-center">
                <PieChart className="h-6 w-6 text-emerald-600" />
              </div>
            </div>
          </CardContent>
        </Card>
                
        <Card className="bg-gradient-to-br from-blue-50 to-white border-l-4 border-blue-500">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-blue-600">All Completed</p>
                <p className="text-3xl font-bold text-gray-800 mt-1">{completedCount}</p>
              </div>
              <div className="h-12 w-12 bg-blue-100 rounded-full flex items-center justify-center">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-6 w-6 text-blue-600"><polyline points="22 12 16 12 14 15 10 15 8 12 2 12"></polyline><path d="M5.45 5.11 2 12v6a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-6l-3.45-6.89A2 2 0 0 0 16.76 4H7.24a2 2 0 0 0-1.79 1.11z"></path></svg>
              </div>
            </div>
            <p className="text-xs text-gray-500 mt-3">
              {displayData.length > 0 ? Math.round(completedCount / displayData.length * 100) : 0}% of total registrations
            </p>
          </CardContent>
        </Card>
                
        <Card className="bg-gradient-to-br from-purple-50 to-white border-l-4 border-purple-500">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-purple-600">Not Completed</p>
                <p className="text-3xl font-bold text-gray-800 mt-1">{notCompletedCount}</p>
              </div>
              <div className="h-12 w-12 bg-purple-100 rounded-full flex items-center justify-center">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-6 w-6 text-purple-600"><path d="M15.5 2H8.6c-.4 0-.8.2-1.1.5-.3.3-.5.7-.5 1.1v12.8c0 .4.2.8.5 1.1.3.3.7.5 1.1.5h9.8c.4 0 .8-.2 1.1-.5.3-.3.5-.7.5-1.1V6.5L15.5 2z"></path><path d="M3 7.6v12.8c0 .4.2.8.5 1.1.3.3.7.5 1.1.5h9.8"></path><path d="M15 2v5h5"></path></svg>
              </div>
            </div>
            <p className="text-xs text-gray-500 mt-3">
              {displayData.length > 0 ? Math.round(notCompletedCount / displayData.length * 100) : 0}% of total registrations
            </p>
          </CardContent>
        </Card>
                
        <Card className="bg-gradient-to-br from-amber-50 to-white border-l-4 border-amber-500">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-amber-600">Districts</p>
                <p className="text-3xl font-bold text-gray-800 mt-1">{districtData.length}</p>
              </div>
              <div className="h-12 w-12 bg-amber-100 rounded-full flex items-center justify-center">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-6 w-6 text-amber-600"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10"></path></svg>
              </div>
            </div>
            <p className="text-xs text-gray-500 mt-3">
              {blockData.length} blocks across {districtData.length} districts
            </p>
          </CardContent>
        </Card>
      </div>
      
      {/* Filters */}
      <div className="p-4 bg-white rounded-lg shadow-sm mb-6">
        <div className="flex flex-col md:flex-row gap-4 md:items-end">
          <div className="w-full md:w-1/3">
            <label className="text-xs font-medium text-gray-500 mb-1 block">Block Filter</label>
            <Select value={blockFilter} onValueChange={setBlockFilter}>
              <SelectTrigger className="w-full">
                <SelectValue placeholder="Select Block" />
              </SelectTrigger>
              <SelectContent>
                {blocks.map(block => <SelectItem key={block} value={block}>
                    {block === 'all' ? 'All Blocks' : block}
                  </SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          
          <div className="w-full md:w-1/3">
            <label className="text-xs font-medium text-gray-500 mb-1 block">Irrigation Type</label>
            <Select value={irrigationFilter} onValueChange={setIrrigationFilter}>
              <SelectTrigger className="w-full">
                <SelectValue placeholder="Select Irrigation Type" />
              </SelectTrigger>
              <SelectContent>
                {irrigationTypes.map(type => <SelectItem key={type} value={type}>
                    {type === 'all' ? 'All Types' : type}
                  </SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          
          <Button variant="outline" size="sm" onClick={() => {
          setBlockFilter('all');
          setIrrigationFilter('all');
        }} className="mb-px">
            <Filter className="h-4 w-4 mr-1" />
            Clear Filters
          </Button>
        </div>
      </div>
      
      {/* Charts */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
        <ChartCard title="Status Distribution" subtitle={`${statusData.length} different statuses`} data={statusData} renderChart={() => renderChartComponent(statusData, 'bar')} icon={<BarChart2 />} height="h-80" />
            
        <ChartCard title="Gender Distribution" data={genderData} renderChart={() => renderChartComponent(genderData, 'pie')} icon={<PieChart />} height="h-80" />
      </div>
          
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
        <ChartCard title="Top 10 Blocks" subtitle="Blocks with most farmers" data={blockData} renderChart={() => renderChartComponent(blockData, 'bar')} icon={<BarChart2 />} height="h-80" />
            
        <ChartCard title="Irrigation Type Distribution" subtitle={`${irrigationData.length} different types`} data={irrigationData} renderChart={() => renderChartComponent(irrigationData, 'bar')} icon={<PieChart />} height="h-80" />
      </div>
          
      <ChartCard title="District Distribution" subtitle="Farmers by district" data={districtData} renderChart={() => renderChartComponent(districtData, 'bar')} icon={<BarChart2 />} height="h-80" />
    </div>;
};
export default AnalyticsOverview;
