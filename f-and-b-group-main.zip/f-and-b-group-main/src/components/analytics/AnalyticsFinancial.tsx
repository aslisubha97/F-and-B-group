
import React, { useMemo } from 'react';
import { useAppContext } from '../../context/AppContext';
import { FileText } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { useNavigate } from 'react-router-dom';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, Cell, PieChart, Pie } from 'recharts';
import { useIsMobile } from '@/hooks/use-mobile';

const AnalyticsFinancial = () => {
  const { filteredFarmerData } = useAppContext();
  const navigate = useNavigate();
  const isMobile = useIsMobile();
  
  // Updated financial statistics calculation using Finance page logic
  const financialStats = useMemo(() => {
    let totalBksyDue = 0;
    let totalPmksyDue = 0;
    let totalBksyPaid = 0;
    let totalPmksyPaid = 0;
    let totalGstSubmitted = 0;
    let totalGstDue = 0;
    
    filteredFarmerData.forEach(farmer => {
      // PMKSY calculations - due (farmers without transaction ref but having PMKSY subsidy)
      if (!farmer.pmksyTransactionRef && farmer.pmksySubsidy && parseFloat(farmer.pmksySubsidy) > 0) {
        totalPmksyDue += parseFloat(farmer.pmksySubsidy);
      }
      
      // BKSY calculations - due (farmers without transaction ref but having BKSY subsidy)
      if (!farmer.bksyTransactionRef && farmer.bksySubsidy && parseFloat(farmer.bksySubsidy) > 0) {
        totalBksyDue += parseFloat(farmer.bksySubsidy);
      }
      
      // PMKSY paid (farmers with transaction ref and amount paid)
      if (farmer.pmksyTransactionRef && farmer.pmksyAmountPaid && parseFloat(farmer.pmksyAmountPaid) > 0) {
        totalPmksyPaid += parseFloat(farmer.pmksyAmountPaid);
      }
      
      // BKSY paid (farmers with transaction ref and amount paid)
      if (farmer.bksyTransactionRef && farmer.bksyAmountPaid && parseFloat(farmer.bksyAmountPaid) > 0) {
        totalBksyPaid += parseFloat(farmer.bksyAmountPaid);
      }

      // GST calculations using Payment Reference field
      if (farmer.gstAmount && parseFloat(farmer.gstAmount) > 0) {
        const gstAmount = parseFloat(farmer.gstAmount);
        
        // If Payment Reference exists, GST is submitted
        if (farmer.paymentReference && farmer.paymentReference.trim() !== '') {
          totalGstSubmitted += gstAmount;
        } else {
          // No Payment Reference means GST is due
          totalGstDue += gstAmount;
        }
      }
    });
    
    return {
      totalPmksyDue,
      totalPmksyPaid, 
      totalBksyDue,
      totalBksyPaid,
      totalGstSubmitted,
      totalGstDue
    };
  }, [filteredFarmerData]);
  
  // Calculate total subsidy amount for completion percentage
  const totalSubsidyAmount = useMemo(() => 
    financialStats.totalPmksyDue + financialStats.totalPmksyPaid + 
    financialStats.totalBksyDue + financialStats.totalBksyPaid
  , [financialStats]);
  
  // Calculate total paid amount
  const totalPaidAmount = financialStats.totalPmksyPaid + financialStats.totalBksyPaid;
  
  // Calculate payment completion percentage
  const paymentCompletionPercentage = totalSubsidyAmount > 0 
    ? Math.round((totalPaidAmount / totalSubsidyAmount) * 100)
    : 0;
    
  // Payment status data
  const paymentStatusData = useMemo(() => [
    { name: 'PMKSY Paid', value: financialStats.totalPmksyPaid, color: '#34D399' },
    { name: 'PMKSY Due', value: financialStats.totalPmksyDue, color: '#F97316' },
    { name: 'BKSY Paid', value: financialStats.totalBksyPaid, color: '#3B82F6' },
    { name: 'BKSY Due', value: financialStats.totalBksyDue, color: '#EAB308' },
  ], [financialStats]);
  
  // GST status data
  const gstStatusData = useMemo(() => [
    { name: 'GST Submitted', value: financialStats.totalGstSubmitted, color: '#10B981' },
    { name: 'GST Due', value: financialStats.totalGstDue, color: '#F43F5E' },
  ], [financialStats]);
  
  return (
    <div className="space-y-8 animate-fade-in">
      {/* High-level financial summary */}
      <div className="bg-white p-6 rounded-lg shadow-sm">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-4">
          <div>
            <h3 className="text-xl font-semibold">Financial Summary</h3>
            <p className="text-gray-500">Overall subsidy payment status</p>
          </div>
          <Button 
            variant="outline" 
            className="mt-2 md:mt-0"
            onClick={() => navigate('/finance')}
          >
            <FileText className="h-4 w-4 mr-2" />
            View Full Financial Reports
          </Button>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-6">
          <div>
            <div className="flex flex-col space-y-2">
              <div className="flex justify-between">
                <span className="text-gray-500">Total Subsidy Amount:</span>
                <span className="font-semibold">₹{totalSubsidyAmount.toLocaleString()}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-500">Total Paid Amount:</span>
                <span className="font-semibold text-emerald-600">₹{totalPaidAmount.toLocaleString()}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-500">Total Due Amount:</span>
                <span className="font-semibold text-amber-600">₹{(totalSubsidyAmount - totalPaidAmount).toLocaleString()}</span>
              </div>
            </div>
            
            <div className="mt-4">
              <div className="flex justify-between items-center mb-1">
                <span className="text-sm text-gray-600">Payment Completion</span>
                <span className="text-sm font-medium">{paymentCompletionPercentage}%</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2.5">
                <div 
                  className="bg-emerald-600 h-2.5 rounded-full" 
                  style={{ width: `${paymentCompletionPercentage}%` }}
                ></div>
              </div>
            </div>
          </div>
          
          <div className="h-60">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={paymentStatusData}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, percent }) => isMobile ? `${(percent * 100).toFixed(0)}%` : `${name}: ${(percent * 100).toFixed(0)}%`}
                  outerRadius={isMobile ? 60 : 80}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {paymentStatusData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip formatter={(value) => [`₹${Number(value).toLocaleString()}`, 'Amount']} />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
      
      {/* Subsidy Payment Cards - Updated for better mobile responsiveness */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <Card className="bg-gradient-to-br from-emerald-50 to-white">
          <CardHeader className="pb-2">
            <CardTitle className="text-lg">GST Summary</CardTitle>
          </CardHeader>
          <CardContent className="pt-0">
            <div className="grid grid-cols-2 gap-2">
              <div>
                <p className="text-xs sm:text-sm text-gray-500">Submitted</p>
                <p className="text-lg sm:text-xl lg:text-2xl font-bold text-gray-800">₹{financialStats.totalGstSubmitted.toLocaleString()}</p>
              </div>
              <div>
                <p className="text-xs sm:text-sm text-gray-500">Due</p>
                <p className="text-lg sm:text-xl lg:text-2xl font-bold text-red-600">₹{financialStats.totalGstDue.toLocaleString()}</p>
              </div>
            </div>
          </CardContent>
          <CardFooter className="pt-0">
            <p className="text-xs text-gray-500">
              {(financialStats.totalGstSubmitted + financialStats.totalGstDue) > 0 ? 
                Math.round(financialStats.totalGstSubmitted / (financialStats.totalGstSubmitted + financialStats.totalGstDue) * 100) : 0}% submitted
            </p>
          </CardFooter>
        </Card>
        
        <Card className="bg-gradient-to-br from-blue-50 to-white">
          <CardHeader className="pb-2">
            <CardTitle className="text-lg">PMKSY Payments</CardTitle>
          </CardHeader>
          <CardContent className="pt-0">
            <div className="grid grid-cols-2 gap-2">
              <div>
                <p className="text-xs sm:text-sm text-gray-500">Paid</p>
                <p className="text-lg sm:text-xl lg:text-2xl font-bold text-gray-800">₹{financialStats.totalPmksyPaid.toLocaleString()}</p>
              </div>
              <div>
                <p className="text-xs sm:text-sm text-gray-500">Due</p>
                <p className="text-lg sm:text-xl lg:text-2xl font-bold text-amber-600">₹{financialStats.totalPmksyDue.toLocaleString()}</p>
              </div>
            </div>
          </CardContent>
          <CardFooter className="pt-0">
            <p className="text-xs text-gray-500">
              {(financialStats.totalPmksyPaid + financialStats.totalPmksyDue) > 0 ? 
                Math.round(financialStats.totalPmksyPaid / (financialStats.totalPmksyPaid + financialStats.totalPmksyDue) * 100) : 0}% disbursed
            </p>
          </CardFooter>
        </Card>
        
        <Card className="bg-gradient-to-br from-purple-50 to-white">
          <CardHeader className="pb-2">
            <CardTitle className="text-lg">BKSY Payments</CardTitle>
          </CardHeader>
          <CardContent className="pt-0">
            <div className="grid grid-cols-2 gap-2">
              <div>
                <p className="text-xs sm:text-sm text-gray-500">Paid</p>
                <p className="text-lg sm:text-xl lg:text-2xl font-bold text-gray-800">₹{financialStats.totalBksyPaid.toLocaleString()}</p>
              </div>
              <div>
                <p className="text-xs sm:text-sm text-gray-500">Due</p>
                <p className="text-lg sm:text-xl lg:text-2xl font-bold text-amber-600">₹{financialStats.totalBksyDue.toLocaleString()}</p>
              </div>
            </div>
          </CardContent>
          <CardFooter className="pt-0">
            <p className="text-xs text-gray-500">
              {(financialStats.totalBksyPaid + financialStats.totalBksyDue) > 0 ? 
                Math.round(financialStats.totalBksyPaid / (financialStats.totalBksyPaid + financialStats.totalBksyDue) * 100) : 0}% disbursed
            </p>
          </CardFooter>
        </Card>
      </div>
        
      {/* GST Chart */}
      <Card>
        <CardHeader>
          <CardTitle>GST Status</CardTitle>
          <CardDescription>GST submission status across all farmers</CardDescription>
        </CardHeader>
        <CardContent className={isMobile ? "h-60" : "h-80"}>
          <ResponsiveContainer width="100%" height="100%">
            <BarChart 
              data={gstStatusData}
              layout="vertical"
              margin={{ top: 10, right: 30, left: isMobile ? 90 : 40, bottom: 10 }}
            >
              <CartesianGrid strokeDasharray="3 3" horizontal={true} vertical={false} />
              <XAxis type="number" />
              <YAxis 
                dataKey="name" 
                type="category" 
                width={isMobile ? 80 : 40}
                tick={{ fontSize: isMobile ? 10 : 12 }}
              />
              <Tooltip formatter={(value) => [`₹${Number(value).toLocaleString()}`, 'Amount']} />
              <Bar dataKey="value" radius={[0, 4, 4, 0]}>
                {gstStatusData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>
        
      {/* Invoice Dashboard Link */}
      <Card className="bg-gradient-to-br from-gray-50 to-white">
        <CardContent className="p-6">
          <div className="flex flex-col md:flex-row items-center justify-between">
            <div className="mb-4 md:mb-0">
              <h3 className="text-lg font-semibold">Invoice Dashboard</h3>
              <p className="text-gray-500 mt-1">Access detailed invoice information and management tools</p>
            </div>
            <Button onClick={() => navigate('/invoice')} className="bg-emerald-600 hover:bg-emerald-700">
              <FileText className="h-4 w-4 mr-2" />
              View Invoice Dashboard
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default AnalyticsFinancial;
