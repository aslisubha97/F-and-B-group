import React, { useState } from 'react';
import { useAppContext } from '../../context/AppContext';
import { FileText, AlertTriangle, AlertCircle, File, Download, ArrowRight, BarChart2, ChartPie } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { toast } from "sonner";
import MissingDocsReport from '../MissingDocsReport';
import MissingBillReport from '../MissingBillReport';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

// Report Card Component with improved design
const ReportCard = ({ title, description, count, icon, color, action, variant = "default" }) => {
  return (
    <Card className={`overflow-hidden transition-all duration-300 hover:shadow-lg ${count > 0 ? 'border-l-4' : ''}`} 
          style={{ borderLeftColor: count > 0 ? color : 'transparent' }}>
      <CardContent className="p-6">
        <div className="flex items-start">
          <div className={`rounded-full p-3 ${color} mr-4 shrink-0`}>
            {icon}
          </div>
          <div className="flex-1">
            <div className="flex items-center justify-between mb-2">
              <h3 className="font-medium">{title}</h3>
              {count > 0 && (
                <Badge variant={variant === "outline" ? "outline" : variant === "destructive" ? "destructive" : "default"} className="ml-2">
                  {count} {count === 1 ? 'issue' : 'issues'}
                </Badge>
              )}
            </div>
            <p className="text-sm text-gray-500 mb-4">{description}</p>
            <Button 
              variant={count > 0 ? "default" : "outline"} 
              size="sm"
              onClick={action}
              className={count > 0 ? "bg-blue-600 hover:bg-blue-700" : ""}
              disabled={count === 0}
            >
              View Report
              <ArrowRight className="ml-2 h-3.5 w-3.5" />
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

// Generate Report Dialog Component
const GenerateReportDialog = ({ open, onClose }) => {
  const { filteredFarmerData, selectedFinancialYear } = useAppContext();
  
  const handleDownloadCSV = (type) => {
    let rows;
    const headers = ['Name', 'Registration Number', 'Mobile Number', 'Block', 'District', 'Status', 'Financial Year', 'Irrigation Type'];
    
    if (type === 'all') {
      rows = filteredFarmerData.map(farmer => [
        `"${farmer.beneficiaryName || ''}"`,
        `"${farmer.farmerRegistrationNumber || ''}"`,
        `"${farmer.mobileNumber || farmer.mobileNo || ''}"`,
        `"${farmer.blockName || ''}"`,
        `"${farmer.districtName || ''}"`,
        `"${farmer.currentStatus || ''}"`,
        `"${farmer.financialYear || ''}"`,
        `"${farmer.irrigationType || ''}"`,
      ]);
    } else if (type === 'completed') {
      const completedFarmers = filteredFarmerData.filter(farmer => 
        farmer.currentStatus && 
        farmer.currentStatus.toLowerCase().includes('installed') && 
        farmer.currentStatus.toLowerCase().includes('inspected')
      );
      rows = completedFarmers.map(farmer => [
        `"${farmer.beneficiaryName || ''}"`,
        `"${farmer.farmerRegistrationNumber || ''}"`,
        `"${farmer.mobileNumber || farmer.mobileNo || ''}"`,
        `"${farmer.blockName || ''}"`,
        `"${farmer.districtName || ''}"`,
        `"${farmer.currentStatus || ''}"`,
        `"${farmer.financialYear || ''}"`,
        `"${farmer.irrigationType || ''}"`,
      ]);
    } else if (type === 'pending') {
      const pendingFarmers = filteredFarmerData.filter(farmer => 
        !farmer.currentStatus || 
        !(farmer.currentStatus.toLowerCase().includes('installed') && 
          farmer.currentStatus.toLowerCase().includes('inspected'))
      );
      rows = pendingFarmers.map(farmer => [
        `"${farmer.beneficiaryName || ''}"`,
        `"${farmer.farmerRegistrationNumber || ''}"`,
        `"${farmer.mobileNumber || farmer.mobileNo || ''}"`,
        `"${farmer.blockName || ''}"`,
        `"${farmer.districtName || ''}"`,
        `"${farmer.currentStatus || ''}"`,
        `"${farmer.financialYear || ''}"`,
        `"${farmer.irrigationType || ''}"`,
      ]);
    }
    
    // Generate and download the CSV file
    const csvContent = [headers.join(','), ...rows.map(row => row.join(','))].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `${type}_farmers_${selectedFinancialYear.replace(/\//g, '-')}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    
    toast.success(`${rows.length} records exported successfully`);
  };
  
  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle>Generate Reports</DialogTitle>
          <DialogDescription>Download farmer data in CSV format</DialogDescription>
        </DialogHeader>
        
        <div className="space-y-4 py-4">
          <div className="flex flex-col space-y-2 rounded-md border p-4 hover:bg-gray-50 transition-colors">
            <h4 className="font-medium">Complete Farmer Database</h4>
            <p className="text-sm text-gray-500">
              Export all farmer data for the selected financial year.
            </p>
            <Button 
              variant="outline" 
              size="sm" 
              className="mt-2 self-start"
              onClick={() => handleDownloadCSV('all')}
            >
              <Download className="mr-2 h-4 w-4" />
              Download CSV ({filteredFarmerData.length} records)
            </Button>
          </div>
          
          <div className="flex flex-col space-y-2 rounded-md border p-4 hover:bg-gray-50 transition-colors">
            <h4 className="font-medium">Completed Installations</h4>
            <p className="text-sm text-gray-500">
              Export data for farmers with completed installations and inspections.
            </p>
            <Button 
              variant="outline" 
              size="sm" 
              className="mt-2 self-start"
              onClick={() => handleDownloadCSV('completed')}
            >
              <Download className="mr-2 h-4 w-4" />
              Download CSV ({filteredFarmerData.filter(f => 
                f.currentStatus?.toLowerCase().includes('installed') && 
                f.currentStatus?.toLowerCase().includes('inspected')).length} records)
            </Button>
          </div>
          
          <div className="flex flex-col space-y-2 rounded-md border p-4 hover:bg-gray-50 transition-colors">
            <h4 className="font-medium">Pending Installations</h4>
            <p className="text-sm text-gray-500">
              Export data for farmers with pending installations or inspections.
            </p>
            <Button 
              variant="outline" 
              size="sm" 
              className="mt-2 self-start"
              onClick={() => handleDownloadCSV('pending')}
            >
              <Download className="mr-2 h-4 w-4" />
              Download CSV ({filteredFarmerData.filter(f => 
                !f.currentStatus?.toLowerCase().includes('installed') || 
                !f.currentStatus?.toLowerCase().includes('inspected')).length} records)
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};

// Pending Payments Report Dialog
const PendingPaymentsDialog = ({ open, onClose }) => {
  const { filteredFarmerData } = useAppContext();
  
  const pendingPayments = filteredFarmerData.filter(f => 
    f.totalSubsidy && parseFloat(f.totalSubsidy) > 0 && 
    (!f.paymentDate || f.paymentDate === '-')
  );
  
  const totalAmount = pendingPayments.reduce((sum, farmer) => {
    const amount = parseFloat(farmer.totalSubsidy || '0');
    return sum + (isNaN(amount) ? 0 : amount);
  }, 0);
  
  const handleExportCSV = () => {
    const headers = ['Farmer Name', 'Registration Number', 'Block', 'District', 'Subsidy Amount', 'Status'];
    const rows = pendingPayments.map(farmer => [
      `"${farmer.beneficiaryName || ''}"`,
      `"${farmer.farmerRegistrationNumber || ''}"`,
      `"${farmer.blockName || ''}"`,
      `"${farmer.districtName || ''}"`,
      `"${farmer.totalSubsidy || '0'}"`,
      `"${farmer.currentStatus || ''}"`,
    ]);
    
    const csvContent = [headers.join(','), ...rows.map(row => row.join(','))].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', 'pending_payments.csv');
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    
    toast.success(`${rows.length} records exported successfully`);
  };
  
  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[700px]">
        <DialogHeader>
          <DialogTitle>Pending Payments Report</DialogTitle>
          <DialogDescription>
            Farmers with approved subsidies but pending payments
          </DialogDescription>
        </DialogHeader>
        
        <div className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pb-4">
            <Card className="bg-blue-50">
              <CardContent className="p-4">
                <h4 className="text-sm font-medium text-blue-700">Total Pending Amount</h4>
                <p className="text-2xl font-bold mt-1">₹ {totalAmount.toLocaleString('en-IN')}</p>
                <p className="text-xs text-blue-600 mt-1">Across {pendingPayments.length} farmers</p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="flex flex-col justify-between p-4 h-full">
                <p className="text-sm text-gray-600">Export all pending payment records for further processing.</p>
                <Button 
                  variant="outline" 
                  size="sm" 
                  className="self-start mt-2"
                  onClick={handleExportCSV}
                >
                  <Download className="mr-2 h-4 w-4" />
                  Export CSV
                </Button>
              </CardContent>
            </Card>
          </div>
          
          <div className="rounded-md border overflow-hidden">
            <Table>
              <TableHeader className="bg-gray-50">
                <TableRow>
                  <TableHead>Farmer Name</TableHead>
                  <TableHead>Registration No.</TableHead>
                  <TableHead>Block</TableHead>
                  <TableHead className="text-right">Amount (₹)</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {pendingPayments.slice(0, 5).map((farmer, index) => (
                  <TableRow key={index}>
                    <TableCell className="font-medium">{farmer.beneficiaryName}</TableCell>
                    <TableCell>{farmer.farmerRegistrationNumber}</TableCell>
                    <TableCell>{farmer.blockName}</TableCell>
                    <TableCell className="text-right">
                      {parseFloat(farmer.totalSubsidy || '0').toLocaleString('en-IN')}
                    </TableCell>
                  </TableRow>
                ))}
                {pendingPayments.length > 5 && (
                  <TableRow>
                    <TableCell colSpan={4} className="text-center text-sm text-gray-500">
                      + {pendingPayments.length - 5} more records
                    </TableCell>
                  </TableRow>
                )}
                {pendingPayments.length === 0 && (
                  <TableRow>
                    <TableCell colSpan={4} className="text-center text-sm text-gray-500">
                      No pending payments found
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};

const AnalyticsReports = () => {
  const { filteredFarmerData } = useAppContext();
  
  // States for various dialogs
  const [showMissingDocsReport, setShowMissingDocsReport] = useState(false);
  const [showMissingBillReport, setShowMissingBillReport] = useState(false);
  const [showPendingPaymentsReport, setShowPendingPaymentsReport] = useState(false);
  const [showGenerateReportDialog, setShowGenerateReportDialog] = useState(false);
  const [activeTab, setActiveTab] = useState("issue");
  
  // Calculate counts for report badges - using corrected criteria
  const missingDocsCount = filteredFarmerData.filter(f => 
    f.currentStatus?.toLowerCase().includes('installed') && 
    f.currentStatus?.toLowerCase().includes('inspected') && 
    (!f.docUploadStatus || f.docUploadStatus === 'Insp. File Missing')
  ).length;
  
  const missingBillCount = filteredFarmerData.filter(f => 
    f.paymentReference && f.paymentReference.trim() !== '' && 
    (!f.billNo || f.billNo.trim() === '')
  ).length;
  
  const pendingPaymentsCount = filteredFarmerData.filter(f => 
    f.totalSubsidy && parseFloat(f.totalSubsidy) > 0 && 
    (!f.paymentDate || f.paymentDate === '-')
  ).length;
  
  return (
    <div className="space-y-8 animate-fade-in">
      {/* Reports Header Card */}
      <Card className="bg-gradient-to-r from-blue-50 via-indigo-50 to-white">
        <CardHeader className="pb-2">
          <CardTitle className="text-xl font-semibold text-blue-800 flex items-center">
            <FileText className="mr-2 h-5 w-5 text-blue-600" />
            Reports & Analytics
          </CardTitle>
          <CardDescription>
            Generate reports and analyze data for better decision making
          </CardDescription>
        </CardHeader>
        <CardContent className="pt-0 pb-6">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div className="text-sm text-gray-600">
              {filteredFarmerData.length} farmers in the selected financial year
            </div>
            <Button 
              onClick={() => setShowGenerateReportDialog(true)}
              className="bg-blue-600 hover:bg-blue-700"
            >
              <File className="mr-2 h-4 w-4" />
              Generate Reports
            </Button>
          </div>
        </CardContent>
      </Card>
      
      {/* Report Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid grid-cols-2 w-full max-w-md mx-auto mb-6">
          <TabsTrigger value="issue" className="px-6">Issue Reports</TabsTrigger>
          <TabsTrigger value="finance" className="px-6">Financial Reports</TabsTrigger>
        </TabsList>
        
        <TabsContent value="issue" className="animate-fadeIn">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <ReportCard 
              title="Missing Documentation Report" 
              description="Farmers with installed & inspected status but missing inspection files" 
              count={missingDocsCount}
              icon={<FileText className="h-5 w-5 text-amber-600" />}
              color="bg-amber-100"
              variant="default"
              action={() => setShowMissingDocsReport(true)}
            />
            
            <ReportCard 
              title="Missing Bill Number Report" 
              description="Farmers with payment references but missing bill numbers" 
              count={missingBillCount}
              icon={<AlertCircle className="h-5 w-5 text-red-600" />}
              color="bg-red-100"
              variant="destructive"
              action={() => setShowMissingBillReport(true)}
            />
          </div>
        </TabsContent>
        
        <TabsContent value="finance" className="animate-fadeIn">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <ReportCard 
              title="Pending Payment Report" 
              description="Farmers with approved subsidies but pending payments" 
              count={pendingPaymentsCount}
              icon={<ChartPie className="h-5 w-5 text-blue-600" />}
              color="bg-blue-100"
              variant="default"
              action={() => setShowPendingPaymentsReport(true)}
            />
            
            <ReportCard 
              title="Financial Year Summary" 
              description="Overall financial analysis for the selected period" 
              count={filteredFarmerData.length > 0 ? 1 : 0}
              icon={<BarChart2 className="h-5 w-5 text-emerald-600" />}
              color="bg-emerald-100"
              variant="outline"
              action={() => {
                setShowGenerateReportDialog(true);
              }}
            />
          </div>
        </TabsContent>
      </Tabs>
      
      {/* Report Dialogs */}
      <MissingDocsReport isOpen={showMissingDocsReport} onClose={() => setShowMissingDocsReport(false)} />
      <MissingBillReport isOpen={showMissingBillReport} onClose={() => setShowMissingBillReport(false)} />
      <PendingPaymentsDialog open={showPendingPaymentsReport} onClose={() => setShowPendingPaymentsReport(false)} />
      <GenerateReportDialog open={showGenerateReportDialog} onClose={() => setShowGenerateReportDialog(false)} />
    </div>
  );
};

export default AnalyticsReports;
