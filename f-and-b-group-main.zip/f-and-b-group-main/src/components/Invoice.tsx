
import React, { useState, useMemo } from 'react';
import { useAppContext } from '../context/AppContext';
import { FileText, Users, Download, ChevronDown, ChevronUp, File, CreditCard, IndianRupee } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogClose } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { formatToMonthYear, getFinancialYearFromRegNumber, getSortedMonthsInRange } from '../utils/dateUtils';
import { Drawer, DrawerContent, DrawerHeader, DrawerTitle, DrawerDescription, DrawerClose } from "@/components/ui/drawer";
import { useIsMobile } from '@/hooks/use-mobile';

// Define status colors for consistent coloring across the app
const STATUS_COLORS = {
  'New Registration': '#FFE082',
  'Joint Inspection': '#336633',
  'Work Order': '#B2FFFF',
  // Updated to match the requested color
  'Install': '#1E6AF4',
  'Install & Inspection': '#CC00CB',
  'Other': '#CCCCCC'
};
const Invoice = () => {
  const {
    filteredFarmerData,
    blockSummaries,
    selectedFinancialYear
  } = useAppContext();
  const [selectedBlock, setSelectedBlock] = useState('All Blocks');
  const [selectedMonth, setSelectedMonth] = useState('All');
  const [showFarmerList, setShowFarmerList] = useState(false);
  const [dialogTitle, setDialogTitle] = useState('');
  const [farmersList, setFarmersList] = useState<any[]>([]);
  const [filteredInvoices, setFilteredInvoices] = useState<any[]>([]);
  const [totalGeneratedForSelection, setTotalGeneratedForSelection] = useState(0);
  const [expandedBlocks, setExpandedBlocks] = useState<string[]>([]);
  const isMobile = useIsMobile();

  // Use filtered farmer data instead of all farmer data
  const filteredByYear = useMemo(() => {
    return filteredFarmerData;
  }, [filteredFarmerData]);

  // Get all blocks
  const allBlocks = useMemo(() => {
    return Array.from(new Set(blockSummaries.map(block => block.blockName)));
  }, [blockSummaries]);

  // Update filtered data when block or month changes
  React.useEffect(() => {
    let filtered = filteredByYear.filter(farmer => {
      // Filter by block
      if (selectedBlock !== 'All Blocks' && farmer.blockName !== selectedBlock) {
        return false;
      }

      // Filter by month if specified
      if (selectedMonth !== 'All' && farmer.paymentDate) {
        const month = getMonthFromDate(farmer.paymentDate);
        if (month !== selectedMonth) {
          return false;
        }
      }

      // Only include invoiced farmers (has payment reference)
      return !!farmer.paymentReference;
    });
    setFilteredInvoices(filtered);
    setTotalGeneratedForSelection(filtered.length);
    
    console.log(`Invoice Component: Applied financial year filter: ${selectedFinancialYear}. Filtered to ${filtered.length} records`);
  }, [filteredByYear, selectedBlock, selectedMonth, selectedFinancialYear]);

  // Calculate GST metrics based on GST Amount field and Payment Reference
  const gstMetrics = useMemo(() => {
    // Get all farmers with GST Amount and Payment Reference (GST submitted)
    const submittedGST = filteredByYear.reduce((total, farmer) => {
      if (farmer.paymentReference && farmer.gstAmount) {
        const gstAmount = parseFloat(farmer.gstAmount || '0');
        return total + (isNaN(gstAmount) ? 0 : gstAmount);
      }
      return total;
    }, 0);

    // Get all farmers with GST Amount but no Payment Reference (GST due)
    // Only count farmers with Work Order or Install status for GST due
    const dueGST = filteredByYear.reduce((total, farmer) => {
      if (!farmer.paymentReference && farmer.gstAmount && farmer.currentStatus && (farmer.currentStatus.toLowerCase().includes('work order') || farmer.currentStatus.toLowerCase().includes('install'))) {
        const gstAmount = parseFloat(farmer.gstAmount || '0');
        return total + (isNaN(gstAmount) ? 0 : gstAmount);
      }
      return total;
    }, 0);
    return {
      gstSubmitted: submittedGST,
      gstDue: dueGST
    };
  }, [filteredByYear]);
  const getMonthFromDate = (dateStr?: string): string => {
    if (!dateStr) return '';
    const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    try {
      const dateParts = dateStr.split(/[-\/]/);
      if (dateParts.length === 3) {
        // Try to handle different date formats
        let month;
        if (dateParts[1].length === 3) {
          // Format is like "DD-MMM-YY"
          const monthAbbr = dateParts[1].substring(0, 3);
          month = months.findIndex(m => m.toLowerCase() === monthAbbr.toLowerCase());
        } else {
          // Format might be "MM/DD/YYYY" or "DD/MM/YYYY"
          month = parseInt(dateParts[1]) - 1;
        }
        if (month >= 0 && month < 12) {
          return months[month];
        }
      }
    } catch (error) {
      console.error('Error parsing date:', dateStr);
    }
    return '';
  };

  // Get a standardized status key
  const getStatusKey = (status?: string): string => {
    if (!status) return 'Other';
    const statusLower = status.toLowerCase();
    if (statusLower.includes('new registration')) return 'New Registration';
    if (statusLower.includes('joint inspection')) return 'Joint Inspection';
    if (statusLower.includes('work order')) return 'Work Order';
    if (statusLower.includes('install') && statusLower.includes('inspection')) return 'Install & Inspection';
    if (statusLower.includes('install')) return 'Install';
    return 'Other';
  };

  // Get farmers who have payment reference but are not installed & inspected
  const invoicedButNotInspected = useMemo(() => {
    return filteredByYear.filter(farmer => {
      // Has payment reference (invoice generated)
      const hasInvoice = !!farmer.paymentReference;

      // Not installed & inspected
      const isNotInstalledAndInspected = !farmer.currentStatus || !(farmer.currentStatus.toLowerCase().includes('install') && farmer.currentStatus.toLowerCase().includes('inspect'));
      return hasInvoice && isNotInstalledAndInspected;
    });
  }, [filteredByYear]);

  // Prepare data by status
  const invoiceStatusData = useMemo(() => {
    const statusCounts: {
      [key: string]: number;
    } = {};
    filteredInvoices.forEach(farmer => {
      const status = getStatusKey(farmer.currentStatus);
      if (!statusCounts[status]) {
        statusCounts[status] = 0;
      }
      statusCounts[status]++;
    });
    return Object.entries(statusCounts).map(([status, count]) => ({
      name: status,
      count,
      color: STATUS_COLORS[status as keyof typeof STATUS_COLORS] || STATUS_COLORS.Other
    }));
  }, [filteredInvoices]);

  // Calculate invoice due by block - only count farmers with Work Order or Install status without payment reference
  const invoiceDueByBlock = useMemo(() => {
    const dueByBlock: {
      [key: string]: {
        [key: string]: number;
      };
    } = {};
    filteredByYear.forEach(farmer => {
      const isDue = farmer.currentStatus && (farmer.currentStatus.toLowerCase().includes('work order') || farmer.currentStatus.toLowerCase().includes('install')) && !farmer.paymentReference;
      if (isDue && farmer.blockName) {
        if (!dueByBlock[farmer.blockName]) {
          dueByBlock[farmer.blockName] = {};
        }
        let type = 'Unknown';
        if (farmer.irrigationType) {
          if (farmer.irrigationType.includes('Portable Sprinkler 63mm')) {
            type = 'Portable Sprinkler 63mm';
          } else if (farmer.irrigationType.includes('Portable Sprinkler 75mm')) {
            type = 'Portable Sprinkler 75mm';
          } else if (farmer.irrigationType.includes('Portable Sprinkler')) {
            type = 'Portable Sprinkler (Other)';
          } else {
            const matches = farmer.irrigationType.match(/([A-Za-z\s]+)(?:\s+(\d+)(?:mm)?)?/);
            type = matches ? matches[1].trim() : farmer.irrigationType;
          }
        }
        if (!dueByBlock[farmer.blockName][type]) {
          dueByBlock[farmer.blockName][type] = 0;
        }
        dueByBlock[farmer.blockName][type]++;
      }
    });
    return dueByBlock;
  }, [filteredByYear]);
  const invoiceDueBlockData = useMemo(() => {
    return Object.entries(invoiceDueByBlock).map(([block, types]) => ({
      block,
      total: Object.values(types).reduce((sum, count) => sum + count, 0),
      types
    })).sort((a, b) => b.total - a.total);
  }, [invoiceDueByBlock]);

  // Calculate totals properly
  const totalInvoiceGenerated = useMemo(() => {
    return filteredByYear.filter(farmer => !!farmer.paymentReference).length;
  }, [filteredByYear]);
  const totalInvoiceDue = useMemo(() => {
    return filteredByYear.filter(farmer => !farmer.paymentReference && farmer.currentStatus && (farmer.currentStatus.toLowerCase().includes('work order') || farmer.currentStatus.toLowerCase().includes('install'))).length;
  }, [filteredByYear]);

  // Get all months for dashboard table
  const months = useMemo(() => {
    return getSortedMonthsInRange(filteredByYear.filter(farmer => !!farmer.paymentReference));
  }, [filteredByYear]);

  // Get all districts
  const districts = useMemo(() => {
    const districtSet = new Set<string>();
    filteredByYear.forEach(farmer => {
      if (farmer.districtName && farmer.paymentReference) {
        districtSet.add(farmer.districtName);
      }
    });
    return Array.from(districtSet).sort();
  }, [filteredByYear]);

  // Generate district summary data
  const districtSummaryData = useMemo(() => {
    const data: Record<string, Record<string, number>> = {};

    // Initialize data structure
    districts.forEach(district => {
      data[district] = {};
      months.forEach(month => {
        data[district][month] = 0;
      });
    });

    // Populate with counts
    filteredByYear.forEach(farmer => {
      if (farmer.districtName && farmer.paymentDate && farmer.paymentReference) {
        const monthYear = formatToMonthYear(farmer.paymentDate);
        if (months.includes(monthYear)) {
          data[farmer.districtName][monthYear] = (data[farmer.districtName][monthYear] || 0) + 1;
        }
      }
    });
    return data;
  }, [districts, months, filteredByYear]);

  // Calculate row totals
  const districtTotals = useMemo(() => {
    const totals: Record<string, number> = {};
    districts.forEach(district => {
      totals[district] = months.reduce((sum, month) => {
        return sum + (districtSummaryData[district][month] || 0);
      }, 0);
    });
    return totals;
  }, [districts, months, districtSummaryData]);

  // Calculate column totals
  const monthTotals = useMemo(() => {
    const totals: Record<string, number> = {};
    months.forEach(month => {
      totals[month] = districts.reduce((sum, district) => {
        return sum + (districtSummaryData[district][month] || 0);
      }, 0);
    });
    return totals;
  }, [districts, months, districtSummaryData]);

  // Calculate grand total
  const grandTotal = useMemo(() => {
    return districts.reduce((sum, district) => {
      return sum + districtTotals[district];
    }, 0);
  }, [districts, districtTotals]);

  // Get farmers for selected month in summary table
  const [summarySelectedMonth, setSummarySelectedMonth] = useState<string | null>(null);
  const summarySelectedMonthFarmers = useMemo(() => {
    if (!summarySelectedMonth) return [];
    return filteredByYear.filter(farmer => {
      if (!farmer.paymentReference) return false;
      const monthYear = formatToMonthYear(farmer.paymentDate);
      return monthYear === summarySelectedMonth;
    }).sort((a, b) => {
      // Sort by district name first, then by beneficiary name
      return a.districtName.localeCompare(b.districtName) || a.beneficiaryName.localeCompare(b.beneficiaryName);
    });
  }, [summarySelectedMonth, filteredByYear]);

  // Export to CSV
  const exportToCSV = (farmers: any[], filename: string) => {
    const headers = ['Name', 'Registration Number', 'Mobile Number', 'Block', 'Irrigation Type', 'Current Status', 'Tax Invoice', 'Payment Reference', 'Payment Date'].join(',');
    const rows = farmers.map(farmer => [`"${farmer.beneficiaryName || ''}"`, `"${farmer.farmerRegistrationNumber || ''}"`, `"${farmer.mobileNumber || ''}"`, `"${farmer.blockName || ''}"`, `"${farmer.irrigationType || ''}"`, `"${farmer.currentStatus || ''}"`, `"${farmer.taxInvNo || ''}"`, `"${farmer.paymentReference || ''}"`, `"${farmer.paymentDate || ''}"`].join(','));
    const csvContent = [headers, ...rows].join('\n');
    const blob = new Blob([csvContent], {
      type: 'text/csv;charset=utf-8;'
    });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `${filename}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };
  const toggleBlockExpansion = (blockName: string) => {
    if (expandedBlocks.includes(blockName)) {
      setExpandedBlocks(expandedBlocks.filter(b => b !== blockName));
    } else {
      setExpandedBlocks([...expandedBlocks, blockName]);
    }
  };
  const handleIrrigationTypeClick = (blockName: string, irrigationType: string) => {
    const matchingFarmers = filteredByYear.filter(farmer => {
      const isDue = farmer.currentStatus && (farmer.currentStatus.toLowerCase().includes('work order') || farmer.currentStatus.toLowerCase().includes('install')) && !farmer.paymentReference;
      let matchesType = false;
      if (irrigationType === 'Portable Sprinkler 63mm') {
        matchesType = farmer.irrigationType?.includes('Portable Sprinkler 63mm') || false;
      } else if (irrigationType === 'Portable Sprinkler 75mm') {
        matchesType = farmer.irrigationType?.includes('Portable Sprinkler 75mm') || false;
      } else if (irrigationType === 'Portable Sprinkler (Other)') {
        matchesType = farmer.irrigationType?.includes('Portable Sprinkler') && !farmer.irrigationType?.includes('63mm') && !farmer.irrigationType?.includes('75mm');
      } else {
        const baseType = irrigationType.trim();
        matchesType = farmer.irrigationType?.includes(baseType) || false;
      }
      return isDue && farmer.blockName === blockName && matchesType;
    });
    setFarmersList(matchingFarmers);
    setDialogTitle(`${irrigationType} Due in ${blockName}`);
    setShowFarmerList(true);
  };
  const handleBlockDueClick = (blockName: string) => {
    const matchingFarmers = filteredByYear.filter(farmer => {
      const isDue = farmer.currentStatus && (farmer.currentStatus.toLowerCase().includes('work order') || farmer.currentStatus.toLowerCase().includes('install')) && !farmer.paymentReference;
      return isDue && farmer.blockName === blockName;
    });
    setFarmersList(matchingFarmers);
    setDialogTitle(`Invoices Due in ${blockName}`);
    setShowFarmerList(true);
  };

  // Handle month selection in summary table
  const handleSummaryMonthClick = (month: string) => {
    setSummarySelectedMonth(month === summarySelectedMonth ? null : month);
  };

  // Handle viewing invoiced but not inspected farmers
  const handleViewInvoicedButNotInspected = () => {
    setFarmersList(invoicedButNotInspected);
    setDialogTitle("Invoiced but Not Installed & Inspected");
    setShowFarmerList(true);
  };
  return <div className="max-w-7xl mx-auto">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6 mb-4 md:mb-6">
        <div className="bg-white rounded-lg shadow-sm p-4 border-l-4 border-blue-500">
          <div className="flex items-center">
            <div className="bg-blue-100 p-2 rounded-full mr-3">
              <FileText className="h-5 w-5 text-blue-600" />
            </div>
            <div>
              <div className="text-xs md:text-sm text-gray-500 text-left">Total Invoice Generated</div>
              <div className="text-xl md:text-2xl font-bold text-left">{totalInvoiceGenerated}</div>
              {(selectedBlock !== 'All Blocks' || selectedMonth !== 'All') && <div className="text-xs text-gray-500 text-left">
                  {totalGeneratedForSelection} invoices for current selection
                </div>}
            </div>
            <Button variant="outline" size="sm" className="ml-auto" onClick={() => exportToCSV(filteredByYear.filter(farmer => !!farmer.paymentReference), 'total_invoices_generated')}>
              <Download className="h-4 w-4" />
            </Button>
          </div>
        </div>
        
        <div className="bg-white rounded-lg shadow-sm p-4 border-l-4 border-orange-500">
          <div className="flex items-center">
            <div className="bg-orange-100 p-2 rounded-full mr-3">
              <File className="h-5 w-5 text-orange-600" />
            </div>
            <div>
              <div className="text-xs md:text-sm text-gray-500 text-left">Total Invoice Due</div>
              <div className="text-xl md:text-2xl font-bold text-left">{totalInvoiceDue}</div>
            </div>
            <Button variant="outline" size="sm" className="ml-auto" onClick={() => {
            const dueInvoiceFarmers = filteredByYear.filter(farmer => {
              const isDue = farmer.currentStatus && (farmer.currentStatus.toLowerCase().includes('work order') || farmer.currentStatus.toLowerCase().includes('install')) && !farmer.paymentReference;
              return isDue;
            });
            exportToCSV(dueInvoiceFarmers, 'total_invoices_due');
          }}>
              <Download className="h-4 w-4" />
            </Button>
          </div>
        </div>
        
        {/* GST Submitted Tile with icon */}
        <div className="bg-white rounded-lg shadow-sm p-4 border-l-4 border-green-500 px-[17px]">
          <div className="flex items-center">
            <div className="bg-green-100 p-2 rounded-full mr-3">
              <IndianRupee className="h-5 w-5 text-green-600" />
            </div>
            <div>
              <div className="text-xs md:text-sm text-gray-500 text-left">GST Submitted</div>
              <div className="text-xl md:text-2xl font-bold py-0 px-0 text-left">₹ {gstMetrics.gstSubmitted.toLocaleString('en-IN')}</div>
            </div>
          </div>
        </div>
        
        {/* GST Due Tile with icon */}
        <div className="bg-white rounded-lg shadow-sm p-4 border-l-4 border-red-500">
          <div className="flex items-center">
            <div className="bg-red-100 p-2 rounded-full mr-3">
              <IndianRupee className="h-5 w-5 text-red-600" />
            </div>
            <div>
              <div className="text-xs md:text-sm text-gray-500 text-left">GST Due</div>
              <div className="text-xl md:text-2xl font-bold text-left">₹ {gstMetrics.gstDue.toLocaleString('en-IN')}</div>
            </div>
          </div>
        </div>
      </div>
      
      <Card className="mb-6">
        <CardHeader>
          <CardTitle className="font-normal text-center">Invoice Generation Summary</CardTitle>
          <CardDescription className="font-extralight text-center">By District and Month</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="sticky left-0 bg-white z-10">District Name</TableHead>
                  {months.map(month => <TableHead key={month} className="cursor-pointer hover:bg-gray-50" onClick={() => handleSummaryMonthClick(month)}>
                      <div className="flex items-center justify-center">
                        {month}
                        {summarySelectedMonth === month && <ChevronDown className="h-4 w-4 ml-1" />}
                      </div>
                    </TableHead>)}
                  <TableHead>Grand Total</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {districts.map(district => <TableRow key={district} className="hover:bg-gray-50">
                    <TableCell className="font-medium sticky left-0 bg-white z-10">
                      {district}
                    </TableCell>
                    {months.map(month => <TableCell key={month} className="text-center">
                        <TooltipProvider>
                          <Tooltip>
                            <TooltipTrigger asChild>
                              <span className={`px-2 py-1 rounded-full ${districtSummaryData[district][month] > 0 ? 'bg-blue-100' : ''}`}>
                                {districtSummaryData[district][month] || '-'}
                              </span>
                            </TooltipTrigger>
                            <TooltipContent>
                              <p>{district}: {districtSummaryData[district][month] || 0} in {month}</p>
                            </TooltipContent>
                          </Tooltip>
                        </TooltipProvider>
                      </TableCell>)}
                    <TableCell className="text-center font-semibold">
                      {districtTotals[district]}
                    </TableCell>
                  </TableRow>)}
                <TableRow className="bg-gray-50 font-semibold">
                  <TableCell className="sticky left-0 bg-gray-50 z-10">Monthly Totals</TableCell>
                  {months.map(month => <TableCell key={month} className="text-center">
                      {monthTotals[month]}
                    </TableCell>)}
                  <TableCell className="text-center">{grandTotal}</TableCell>
                </TableRow>
              </TableBody>
            </Table>
          </div>
          
          {summarySelectedMonth && summarySelectedMonthFarmers.length > 0 && <div className="mt-6">
              <div className="flex justify-between items-center mb-3">
                <h3 className="text-lg font-semibold">
                  Details for {summarySelectedMonth} ({summarySelectedMonthFarmers.length} records)
                </h3>
                <Button variant="outline" size="sm" onClick={() => exportToCSV(summarySelectedMonthFarmers, `invoices_${summarySelectedMonth}`)}>
                  <Download className="h-4 w-4 mr-1" />
                  Export
                </Button>
              </div>
              
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Name</TableHead>
                      <TableHead>District</TableHead>
                      <TableHead>Payment Date</TableHead>
                      <TableHead>Payment Reference</TableHead>
                      <TableHead>Current Status</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {summarySelectedMonthFarmers.map((farmer, index) => <TableRow key={index}>
                        <TableCell className="font-medium">{farmer.beneficiaryName || 'N/A'}</TableCell>
                        <TableCell>{farmer.districtName || 'N/A'}</TableCell>
                        <TableCell>{farmer.paymentDate || 'N/A'}</TableCell>
                        <TableCell>{farmer.paymentReference || 'N/A'}</TableCell>
                        <TableCell>{farmer.currentStatus || 'N/A'}</TableCell>
                      </TableRow>)}
                  </TableBody>
                </Table>
              </div>
            </div>}
        </CardContent>
      </Card>
      
      {/* Invoiced but Not Installed & Inspected */}
      <Card className="mb-6">
        <CardHeader>
          <CardTitle className="flex justify-between items-center">
            <span className="font-light text-center">Invoiced but Not Installed & Inspected</span>
            <Badge variant="outline" className="px-[19px] py-[9px] bg-red-500">
              {invoicedButNotInspected.length} Farmers
            </Badge>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col gap-4">
            {invoicedButNotInspected.length > 0 ? <div className="flex justify-between">
                <div className="flex gap-2">
                  <Button variant="outline" size="sm" onClick={handleViewInvoicedButNotInspected} className="text-emerald-600">
                    <Users className="h-4 w-4 mr-1" />
                    View List
                  </Button>
                  <Button variant="outline" size="sm" onClick={() => exportToCSV(invoicedButNotInspected, 'invoiced_not_inspected')} className="bg-emerald-600 hover:bg-emerald-500 text-slate-50">
                    <Download className="h-4 w-4 mr-1" />
                    Export
                  </Button>
                </div>
              </div> : <div className="text-center py-8">
                <FileText className="h-12 w-12 mx-auto text-gray-400 mb-3" />
                <p className="text-gray-600">No farmers found in this category</p>
              </div>}
          </div>
        </CardContent>
      </Card>
      
      <div className="bg-white rounded-lg shadow-sm p-4 mb-4 md:mb-6">
        <div className="flex justify-between items-center mb-3 md:mb-4">
          <h2 className="text-lg font-light text-center">Invoice Due by Block</h2>
          {invoiceDueBlockData.length > 0 && <Badge variant="outline" className="bg-red-500">
              {invoiceDueBlockData.length} Blocks with due invoices
            </Badge>}
        </div>
        
        {invoiceDueBlockData.length > 0 ? <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {invoiceDueBlockData.map(({
          block,
          total,
          types
        }) => <Card key={block} className="shadow-sm hover:shadow-md transition-shadow">
                <CardHeader className="pb-2">
                  <CardTitle className="text-base flex justify-between items-center">
                    <span>{block}</span>
                    <Badge variant="outline" className="bg-red-500">{total}</Badge>
                  </CardTitle>
                  <CardDescription>Invoices pending generation</CardDescription>
                </CardHeader>
                <CardContent className="pb-2">
                  <Button variant="outline" size="sm" onClick={() => toggleBlockExpansion(block)} className="w-full text-emerald-600">
                    {expandedBlocks.includes(block) ? "Hide Details" : "View Details"}
                  </Button>
                  
                  {expandedBlocks.includes(block) && <div className="mt-3 space-y-2">
                      {Object.entries(types).map(([type, count]) => <div key={type} className="flex justify-between items-center p-2 bg-gray-50 hover:bg-gray-100 rounded text-sm cursor-pointer min-h-10" onClick={() => handleIrrigationTypeClick(block, type)}>
                          <span className="truncate max-w-[70%]">{type}</span>
                          <Badge variant="outline" className="bg-blue-50">{count}</Badge>
                        </div>)}
                    </div>}
                </CardContent>
                <CardFooter className="flex justify-between">
                  <Button variant="outline" size="sm" onClick={() => handleBlockDueClick(block)} className="text-slate-50 bg-emerald-600 hover:bg-emerald-500">
                    <Users className="h-3 w-3 mr-1" />
                    View All
                  </Button>
                  <Button variant="outline" size="sm" onClick={() => {
              const matchingFarmers = filteredByYear.filter(farmer => {
                const isDue = farmer.currentStatus && (farmer.currentStatus.toLowerCase().includes('work order') || farmer.currentStatus.toLowerCase().includes('install')) && !farmer.paymentReference;
                return isDue && farmer.blockName === block;
              });
              exportToCSV(matchingFarmers, `invoice_due_${block}`);
            }} className="text-slate-50 bg-emerald-600 hover:bg-emerald-500">
                    <Download className="h-3 w-3 mr-1" />
                    Export
                  </Button>
                </CardFooter>
              </Card>)}
          </div> : <div className="text-center py-8">
            <FileText className="h-12 w-12 mx-auto text-gray-400 mb-3" />
            <p className="text-gray-600">No invoice due data available</p>
          </div>}
      </div>
      
      {isMobile ? (
        <Drawer open={showFarmerList} onOpenChange={setShowFarmerList}>
          <DrawerContent>
            <DrawerHeader>
              <DrawerTitle>{dialogTitle}</DrawerTitle>
              <DrawerDescription>
                {farmersList.length} farmers found
              </DrawerDescription>
            </DrawerHeader>
            
            {farmersList.length > 0 ? <div className="p-4">
                <div className="overflow-x-auto">
                  <table className="min-w-full divide-y divide-gray-200">
                    <thead className="bg-gray-50">
                      <tr>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Name</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Registration No.</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Mobile</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Block</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Irrigation Type</th>
                      </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200">
                      {farmersList.map((farmer, index) => <tr key={index} className={index % 2 === 0 ? 'bg-white' : 'bg-gray-50'}>
                          <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{farmer.beneficiaryName || 'N/A'}</td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{farmer.farmerRegistrationNumber || 'N/A'}</td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{farmer.mobileNumber || farmer.mobileNo || 'N/A'}</td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{farmer.blockName || 'N/A'}</td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{farmer.currentStatus || 'N/A'}</td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{farmer.irrigationType || 'N/A'}</td>
                        </tr>)}
                    </tbody>
                  </table>
                </div>
                <div className="flex justify-end mt-4">
                  <Button onClick={() => exportToCSV(farmersList, 'invoice_due_farmers')}>
                    <Download className="h-4 w-4 mr-2" />
                    Export to CSV
                  </Button>
                </div>
              </div> : <div className="text-center py-6">
                <p>No matching farmers found.</p>
              </div>}
          </DrawerContent>
        </Drawer>
      ) : (
        <Dialog open={showFarmerList} onOpenChange={setShowFarmerList}>
          <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>{dialogTitle}</DialogTitle>
              <DialogDescription>
                {farmersList.length} farmers found
              </DialogDescription>
            </DialogHeader>
            
            {farmersList.length > 0 ? <div className="mt-4">
                <div className="overflow-x-auto">
                  <table className="min-w-full divide-y divide-gray-200">
                    <thead className="bg-gray-50">
                      <tr>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Name</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Registration No.</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Mobile</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Block</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Irrigation Type</th>
                      </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200">
                      {farmersList.map((farmer, index) => <tr key={index} className={index % 2 === 0 ? 'bg-white' : 'bg-gray-50'}>
                          <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{farmer.beneficiaryName || 'N/A'}</td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{farmer.farmerRegistrationNumber || 'N/A'}</td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{farmer.mobileNumber || farmer.mobileNo || 'N/A'}</td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{farmer.blockName || 'N/A'}</td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{farmer.currentStatus || 'N/A'}</td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{farmer.irrigationType || 'N/A'}</td>
                        </tr>)}
                    </tbody>
                  </table>
                </div>
                <div className="flex justify-end mt-4">
                  <Button onClick={() => exportToCSV(farmersList, 'invoice_due_farmers')}>
                    <Download className="h-4 w-4 mr-2" />
                    Export to CSV
                  </Button>
                </div>
              </div> : <div className="text-center py-6">
                <p>No matching farmers found.</p>
              </div>}
          </DialogContent>
        </Dialog>
      )}
    </div>;
};

export default Invoice;
