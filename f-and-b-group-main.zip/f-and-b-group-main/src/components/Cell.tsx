
import React from 'react';
import { Cell as RechartCell } from 'recharts';

interface CellProps {
  key: string;
  fill: string;
}

const Cell: React.FC<CellProps> = ({ key, fill }) => {
  return <RechartCell key={key} fill={fill} />;
};

export default Cell;
