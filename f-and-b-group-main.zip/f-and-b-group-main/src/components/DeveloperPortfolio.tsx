
import React from 'react';
import { Linkedin, Github, Globe, Mail, Code, Award, Briefcase, User, Calendar } from 'lucide-react';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Separator } from '@/components/ui/separator';

const DeveloperPortfolio = () => {
  const technologies = [
    "React", "TypeScript", "Tailwind CSS", "Node.js", 
    "Express", "MongoDB", "PostgreSQL", "AWS", "Docker",
    "GraphQL", "Next.js", "Supabase"
  ];
  
  const projects = [
    {
      title: "PMKSY-BKSY Portal",
      description: "A comprehensive management system for government agricultural schemes",
      tags: ["React", "TypeScript", "Tailwind CSS", "Supabase"],
      link: "/",
      image: "https://images.unsplash.com/photo-1530367027480-83bfa4e72a40?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=80"
    },
    {
      title: "AgriConnect",
      description: "Mobile-first platform connecting farmers directly with consumers",
      tags: ["React Native", "Firebase", "Google Maps API"],
      link: "https://agriconnect.example.com",
      image: "https://images.unsplash.com/photo-1495107334309-fcf20504a5ab?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=80"
    },
    {
      title: "CropAnalytics",
      description: "Data visualization dashboard for agricultural analytics",
      tags: ["D3.js", "Python", "Machine Learning"],
      link: "https://cropanalytics.example.com",
      image: "https://images.unsplash.com/photo-1605000797499-95a51c5269ae?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=80"
    },
    {
      title: "AgriField",
      description: "Field management and cultivation planning tool for farmers",
      tags: ["React", "Node.js", "PostgreSQL"],
      link: "https://agrifield.example.com",
      image: "https://images.unsplash.com/photo-1500651230702-0e2d8a49d4ad?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=80"
    }
  ];
  
  const experiences = [
    {
      role: "Lead Engineer",
      company: "AgriTech Solutions",
      period: "2021 - Present",
      description: "Leading the development of agricultural technology solutions, focusing on IoT integration and sustainable farming practices."
    },
    {
      role: "Full Stack Developer",
      company: "Farm Innovations Ltd",
      period: "2018 - 2021",
      description: "Developed web and mobile applications for precision agriculture and farm management."
    },
    {
      role: "Software Engineer",
      company: "EcoTech",
      period: "2016 - 2018",
      description: "Built environmental monitoring systems using IoT sensors and cloud technologies."
    }
  ];
  
  const education = [
    {
      degree: "MSc in Agricultural Technology",
      institution: "University of AgriScience",
      year: "2016"
    },
    {
      degree: "BSc in Computer Science",
      institution: "Tech University",
      year: "2014"
    }
  ];
  
  return (
    <div className="container mx-auto px-4 py-6 max-w-6xl">
      {/* Hero Section */}
      <div className="bg-gradient-to-br from-emerald-50 to-blue-50 rounded-xl p-6 md:p-10 mb-12">
        <div className="flex flex-col md:flex-row items-center gap-8 md:gap-12">
          <div className="relative">
            <div className="w-40 h-40 md:w-64 md:h-64 rounded-full overflow-hidden border-4 border-white shadow-lg">
              <img 
                src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=80" 
                alt="AgriTech Solutions" 
                className="w-full h-full object-cover"
              />
            </div>
            <div className="absolute bottom-3 right-3 bg-emerald-500 rounded-full p-1.5 border-2 border-white">
              <Code className="h-5 w-5 text-white" />
            </div>
          </div>
          
          <div className="text-center md:text-left space-y-4 flex-1">
            <div>
              <h1 className="text-3xl md:text-4xl font-bold bg-gradient-to-r from-emerald-600 to-blue-600 bg-clip-text text-transparent">
                AgriTech Solutions
              </h1>
              <p className="text-lg md:text-xl text-gray-600 mt-2">
                Creating innovative technology solutions for agriculture
              </p>
            </div>
            
            <p className="text-gray-600 max-w-2xl">
              We specialize in developing sustainable technology solutions for the agricultural sector, 
              combining cutting-edge software with practical farming knowledge to improve efficiency, 
              sustainability, and profitability.
            </p>
            
            <div className="flex items-center justify-center md:justify-start gap-4 mt-6">
              <a href="https://github.com/agritech-solutions" target="_blank" rel="noreferrer">
                <Button variant="outline" size="icon" className="rounded-full">
                  <Github className="h-5 w-5" />
                </Button>
              </a>
              <a href="https://linkedin.com/company/agritech-solutions" target="_blank" rel="noreferrer">
                <Button variant="outline" size="icon" className="rounded-full">
                  <Linkedin className="h-5 w-5" />
                </Button>
              </a>
              <a href="https://agritech-solutions.dev" target="_blank" rel="noreferrer">
                <Button variant="outline" size="icon" className="rounded-full">
                  <Globe className="h-5 w-5" />
                </Button>
              </a>
              <a href="mailto:contact@agritech-solutions.dev">
                <Button variant="outline" size="icon" className="rounded-full">
                  <Mail className="h-5 w-5" />
                </Button>
              </a>
            </div>
            
            <div className="flex flex-wrap gap-2 justify-center md:justify-start mt-4">
              <Badge variant="secondary" className="bg-emerald-100 text-emerald-800 hover:bg-emerald-200">
                Agricultural Tech
              </Badge>
              <Badge variant="secondary" className="bg-blue-100 text-blue-800 hover:bg-blue-200">
                Sustainable Farming
              </Badge>
              <Badge variant="secondary" className="bg-amber-100 text-amber-800 hover:bg-amber-200">
                IoT Solutions
              </Badge>
            </div>
          </div>
        </div>
      </div>
      
      {/* Tabs for Portfolio Sections */}
      <Tabs defaultValue="projects" className="mb-12">
        <TabsList className="w-full mb-8 justify-center">
          <TabsTrigger value="projects" className="text-base">Projects</TabsTrigger>
          <TabsTrigger value="experience" className="text-base">Experience</TabsTrigger>
          <TabsTrigger value="about" className="text-base">About Us</TabsTrigger>
        </TabsList>
        
        {/* Projects Tab */}
        <TabsContent value="projects" className="space-y-8">
          <h2 className="text-2xl font-bold text-center mb-8">Featured Projects</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {projects.map((project, index) => (
              <Card key={index} className="overflow-hidden hover:shadow-lg transition-all duration-300">
                <div className="h-48 overflow-hidden">
                  <img 
                    src={project.image} 
                    alt={project.title} 
                    className="w-full h-full object-cover transition-transform hover:scale-105 duration-500"
                  />
                </div>
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg">{project.title}</CardTitle>
                  <CardDescription>{project.description}</CardDescription>
                </CardHeader>
                <CardContent className="pt-0">
                  <div className="flex flex-wrap gap-1 mb-4">
                    {project.tags.map((tag, i) => (
                      <Badge key={i} variant="outline" className="text-xs">
                        {tag}
                      </Badge>
                    ))}
                  </div>
                </CardContent>
                <CardFooter>
                  <Button asChild variant="default" size="sm" className="bg-emerald-600 hover:bg-emerald-700">
                    <a href={project.link} target="_blank" rel="noreferrer">
                      View Project
                    </a>
                  </Button>
                </CardFooter>
              </Card>
            ))}
          </div>
        </TabsContent>
        
        {/* Experience Tab */}
        <TabsContent value="experience" className="space-y-8">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div>
              <div className="flex items-center mb-6">
                <Briefcase className="h-5 w-5 mr-2 text-emerald-600" />
                <h2 className="text-2xl font-bold">Work Experience</h2>
              </div>
              <div className="space-y-6">
                {experiences.map((exp, index) => (
                  <div key={index} className="relative pl-8 pb-6 border-l-2 border-gray-200">
                    <div className="absolute left-[-9px] top-0 w-4 h-4 rounded-full bg-emerald-600" />
                    <h3 className="font-semibold text-lg">{exp.role}</h3>
                    <div className="flex items-center text-sm text-gray-600 mb-2">
                      <span>{exp.company}</span>
                      <span className="mx-2">•</span>
                      <span className="flex items-center">
                        <Calendar className="h-3 w-3 mr-1" />
                        {exp.period}
                      </span>
                    </div>
                    <p className="text-gray-600">{exp.description}</p>
                  </div>
                ))}
              </div>
            </div>
            
            <div>
              <div>
                <div className="flex items-center mb-6">
                  <Award className="h-5 w-5 mr-2 text-emerald-600" />
                  <h2 className="text-2xl font-bold">Education</h2>
                </div>
                <div className="space-y-4 mb-8">
                  {education.map((edu, index) => (
                    <div key={index} className="p-4 border rounded-lg hover:bg-gray-50 transition-colors">
                      <h3 className="font-semibold">{edu.degree}</h3>
                      <div className="text-sm text-gray-600 flex justify-between">
                        <span>{edu.institution}</span>
                        <span>{edu.year}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
              
              <div>
                <div className="flex items-center mb-6">
                  <Code className="h-5 w-5 mr-2 text-emerald-600" />
                  <h2 className="text-2xl font-bold">Technologies</h2>
                </div>
                <div className="flex flex-wrap gap-2">
                  {technologies.map((tech, index) => (
                    <Badge key={index} variant="secondary" className="bg-blue-50 text-blue-800 hover:bg-blue-100">
                      {tech}
                    </Badge>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </TabsContent>
        
        {/* About Tab */}
        <TabsContent value="about">
          <Card>
            <CardHeader>
              <div className="flex items-center mb-2">
                <User className="h-5 w-5 mr-2 text-emerald-600" />
                <CardTitle>About AgriTech Solutions</CardTitle>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-gray-700 leading-relaxed">
                AgriTech Solutions is a tech company specializing in modern agricultural solutions. 
                We bridge the gap between traditional farming and cutting-edge technology to improve efficiency, 
                sustainability, and profitability for farmers and agricultural organizations.
              </p>
              <p className="text-gray-700 leading-relaxed">
                With over 5 years of experience building software for the agricultural sector, 
                we've worked with government agencies, private farms, and research institutions 
                to develop tailored solutions that address real-world agricultural challenges.
              </p>
              <p className="text-gray-700 leading-relaxed">
                Our team combines expertise in software development, data science, and agricultural practices
                to create applications that make a real difference in the field. We believe in sustainable
                agriculture and using technology to minimize environmental impact while maximizing productivity.
              </p>
              
              <Separator className="my-6" />
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <h3 className="font-semibold mb-2 text-lg">Our Mission</h3>
                  <p className="text-gray-600">
                    To transform agricultural practices through innovative technology solutions that promote
                    sustainability, efficiency, and profitability for farmers worldwide.
                  </p>
                </div>
                <div>
                  <h3 className="font-semibold mb-2 text-lg">Our Vision</h3>
                  <p className="text-gray-600">
                    A world where technology empowers farmers to feed growing populations while preserving
                    natural resources and adapting to climate change.
                  </p>
                </div>
              </div>
            </CardContent>
            <CardFooter className="flex justify-center md:justify-end border-t pt-6">
              <Button asChild variant="default" className="bg-emerald-600 hover:bg-emerald-700">
                <a href="mailto:contact@agritech-solutions.dev">
                  <Mail className="mr-2 h-4 w-4" />
                  Contact Us
                </a>
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>
      </Tabs>
      
      {/* Contact Section */}
      <div className="bg-gradient-to-br from-gray-50 to-blue-50 rounded-xl p-6 md:p-8">
        <h2 className="text-2xl font-bold text-center mb-6">Get in Touch</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div className="space-y-4">
            <p className="text-gray-700">
              Interested in our services? Feel free to reach out to discuss how we can help with your agricultural technology needs.
            </p>
            <div className="space-y-3 mt-4">
              <div className="flex items-center">
                <Mail className="h-5 w-5 mr-3 text-emerald-600" />
                <a href="mailto:contact@agritech-solutions.dev" className="text-gray-700 hover:text-emerald-600 transition-colors">
                  contact@agritech-solutions.dev
                </a>
              </div>
              <div className="flex items-center">
                <Globe className="h-5 w-5 mr-3 text-emerald-600" />
                <a href="https://agritech-solutions.dev" target="_blank" rel="noreferrer" className="text-gray-700 hover:text-emerald-600 transition-colors">
                  agritech-solutions.dev
                </a>
              </div>
            </div>
          </div>
          <div className="flex flex-col justify-center items-center md:items-end">
            <Button asChild className="bg-emerald-600 hover:bg-emerald-700">
              <a href="mailto:contact@agritech-solutions.dev">
                Send us a message
              </a>
            </Button>
            <p className="text-sm text-gray-500 mt-2">We'll respond within 24 hours</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DeveloperPortfolio;
