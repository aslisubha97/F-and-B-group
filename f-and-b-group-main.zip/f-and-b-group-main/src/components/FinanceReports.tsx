import React, { useMemo, useState } from 'react';
import { useAppContext } from '../context/AppContext';
import { IndianRupee, Calendar, ArrowUpRight } from 'lucide-react';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip, Legend, BarChart, Bar, XAxis, YAxis, CartesianGrid } from 'recharts';
import { useIsMobile } from '../hooks/use-mobile';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Drawer, DrawerContent, DrawerHeader, DrawerTitle } from '@/components/ui/drawer';
import { Table, TableHeader, TableBody, TableHead, TableRow, TableCell } from '@/components/ui/table';
import { ScrollArea } from '@/components/ui/scroll-area';

interface FinanceReportsSummary {
  totalBksyDue: number;
  totalPmksyDue: number;
  totalBksyPaid: number;
  totalPmksyPaid: number;
  averageTotalAmount: number;
  pmksyDueFarmers: any[];
  bksyDueFarmers: any[];
}

const FinanceReports = () => {
  const { filteredFarmerData, selectedFinancialYear } = useAppContext();
  const isMobile = useIsMobile();
  
  const [showPmksyDueList, setShowPmksyDueList] = useState(false);
  const [showBksyDueList, setShowBksyDueList] = useState(false);
  
  const financeSummary = useMemo(() => {
    if (!filteredFarmerData || filteredFarmerData.length === 0) {
      return {
        totalBksyDue: 0,
        totalPmksyDue: 0,
        totalBksyPaid: 0,
        totalPmksyPaid: 0,
        averageTotalAmount: 0,
        pmksyDueFarmers: [],
        bksyDueFarmers: []
      };
    }
    
    // Log the financial year filter being applied
    console.log(`FinanceReports: Processing ${filteredFarmerData.length} farmers with financial year filter: ${selectedFinancialYear}`);
    
    let totalBksyDue = 0;
    let totalPmksyDue = 0;
    let totalBksyPaid = 0;
    let totalPmksyPaid = 0;
    let totalAmount = 0;
    let farmersWithAmount = 0;
    
    // Arrays to store farmers with due subsidies
    const pmksyDueFarmers = [];
    const bksyDueFarmers = [];
    
    filteredFarmerData.forEach(farmer => {
      // Calculate PMKSY due (farmers without payment reference but having PMKSY subsidy)
      if (!farmer.pmksyTransactionRef && farmer.pmksySubsidy && parseFloat(farmer.pmksySubsidy) > 0) {
        totalPmksyDue += parseFloat(farmer.pmksySubsidy);
        pmksyDueFarmers.push(farmer);
      }
      
      // Calculate BKSY due (farmers without payment reference but having BKSY subsidy)
      if (!farmer.bksyTransactionRef && farmer.bksySubsidy && parseFloat(farmer.bksySubsidy) > 0) {
        totalBksyDue += parseFloat(farmer.bksySubsidy);
        bksyDueFarmers.push(farmer);
      }
      
      // Calculate PMKSY paid (farmers with payment reference and PMKSY amount)
      if (farmer.pmksyTransactionRef && farmer.pmksyAmountPaid && parseFloat(farmer.pmksyAmountPaid) > 0) {
        totalPmksyPaid += parseFloat(farmer.pmksyAmountPaid);
      }
      
      // Calculate BKSY paid (farmers with payment reference and BKSY amount)
      if (farmer.bksyTransactionRef && farmer.bksyAmountPaid && parseFloat(farmer.bksyAmountPaid) > 0) {
        totalBksyPaid += parseFloat(farmer.bksyAmountPaid);
      }
      
      // Calculate average total amount
      if (farmer.totalAmount && parseFloat(farmer.totalAmount) > 0) {
        totalAmount += parseFloat(farmer.totalAmount);
        farmersWithAmount++;
      }
    });
    
    return {
      totalBksyDue,
      totalPmksyDue, 
      totalBksyPaid,
      totalPmksyPaid,
      averageTotalAmount: farmersWithAmount > 0 ? totalAmount / farmersWithAmount : 0,
      pmksyDueFarmers,
      bksyDueFarmers
    };
  }, [filteredFarmerData, selectedFinancialYear]);
  
  // Create data for pie charts with theme colors - update work-order color
  const pmksyPieData = [
    { name: 'PMKSY Due', value: financeSummary.totalPmksyDue, color: '#FCD34D' }, // status.new-registration
    { name: 'PMKSY Paid', value: financeSummary.totalPmksyPaid, color: '#f5abfc' }  // status.install-inspected
  ];
  
  const bksyPieData = [
    { name: 'BKSY Due', value: financeSummary.totalBksyDue, color: '#7DE3E1' }, // Updated from #00b599 to #7DE3E1
    { name: 'BKSY Paid', value: financeSummary.totalBksyPaid, color: '#93c2fd' }  // status.install
  ];
  
  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    }).format(amount);
  };
  
  const renderDuesList = (dueType: 'PMKSY' | 'BKSY') => {
    const farmers = dueType === 'PMKSY' ? financeSummary.pmksyDueFarmers : financeSummary.bksyDueFarmers;
    const subsidyField = dueType === 'PMKSY' ? 'pmksySubsidy' : 'bksySubsidy';
    
    return (
      <ScrollArea className="h-[60vh] md:h-[500px]">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Farmer Name</TableHead>
              <TableHead>Registration Number</TableHead>
              <TableHead>Block</TableHead>
              <TableHead>Amount Due</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {farmers.length > 0 ? (
              farmers.map((farmer, index) => (
                <TableRow key={index}>
                  <TableCell className="font-medium">{farmer.beneficiaryName || 'N/A'}</TableCell>
                  <TableCell>{farmer.farmerRegistrationNumber || 'N/A'}</TableCell>
                  <TableCell>{farmer.blockName || 'N/A'}</TableCell>
                  <TableCell>{formatCurrency(parseFloat(farmer[subsidyField] || '0'))}</TableCell>
                </TableRow>
              ))
            ) : (
              <TableRow>
                <TableCell colSpan={4} className="text-center py-4">No farmers with due {dueType} subsidies</TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </ScrollArea>
    );
  };

  // Handle clicks for the PMKSY Due and BKSY Due tiles
  const handlePmksyDueClick = () => {
    setShowPmksyDueList(true);
  };

  const handleBksyDueClick = () => {
    setShowBksyDueList(true);
  };

  return (
    <div className="bg-white rounded-lg shadow-sm p-4 md:p-6">
      <h2 className="text-lg md:text-xl font-semibold mb-4">
        Finance Reports
        {selectedFinancialYear !== 'All Years' && (
          <span className="ml-2 text-base font-medium text-gray-500">
            ({selectedFinancialYear})
          </span>
        )}
      </h2>
      
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-gradient-to-r from-sidebar-accent/20 to-sidebar-accent/40 p-4 rounded-lg">
          <div className="flex justify-between items-start">
            <div>
              <div className="text-sm text-gray-500 mb-1">Average Invoice Amount</div>
              <div className="text-xl md:text-2xl font-bold">{formatCurrency(financeSummary.averageTotalAmount)}</div>
            </div>
            <div className="bg-white p-2 rounded-full shadow-sm">
              <IndianRupee className="h-5 w-5 text-sidebar-primary" />
            </div>
          </div>
          <div className="mt-3 text-xs text-gray-500 flex items-center">
            <Calendar className="h-3 w-3 mr-1" />
            Based on all farmers with invoice data
          </div>
        </div>
        
        <div 
          className="bg-gradient-to-r from-status-new-registration/20 to-status-new-registration/30 p-4 rounded-lg cursor-pointer hover:shadow-md transition-shadow"
          onClick={handlePmksyDueClick}
          role="button"
          aria-label="View PMKSY Due farmers list"
          tabIndex={0}
        >
          <div className="flex justify-between items-start">
            <div>
              <div className="text-sm text-gray-500 mb-1">PMKSY Due</div>
              <div className="text-xl md:text-2xl font-bold">{formatCurrency(financeSummary.totalPmksyDue)}</div>
            </div>
            <div className="bg-white p-2 rounded-full shadow-sm">
              <ArrowUpRight className="h-5 w-5 text-status-new-registration" />
            </div>
          </div>
          <div className="mt-2">
            <div className="flex justify-between text-xs mb-1">
              <span>PMKSY Paid</span>
              <span className="font-medium">{formatCurrency(financeSummary.totalPmksyPaid)}</span>
            </div>
          </div>
          <div className="mt-2 text-xs text-blue-600">
            Click to view farmers list
          </div>
        </div>
        
        <div 
          className="bg-gradient-to-r from-status-work-order/10 to-status-work-order/20 p-4 rounded-lg cursor-pointer hover:shadow-md transition-shadow"
          onClick={handleBksyDueClick}
          role="button"
          aria-label="View BKSY Due farmers list"
          tabIndex={0}
        >
          <div className="flex justify-between items-start">
            <div>
              <div className="text-sm text-gray-500 mb-1">BKSY Due</div>
              <div className="text-xl md:text-2xl font-bold">{formatCurrency(financeSummary.totalBksyDue)}</div>
            </div>
            <div className="bg-white p-2 rounded-full shadow-sm">
              <ArrowUpRight className="h-5 w-5 text-status-work-order" />
            </div>
          </div>
          <div className="mt-2">
            <div className="flex justify-between text-xs mb-1">
              <span>BKSY Paid</span>
              <span className="font-medium">{formatCurrency(financeSummary.totalBksyPaid)}</span>
            </div>
          </div>
          <div className="mt-2 text-xs text-blue-600">
            Click to view farmers list
          </div>
        </div>
        
        <div className="bg-gradient-to-r from-status-install-inspected/10 to-status-install-inspected/30 p-4 rounded-lg">
          <div className="flex justify-between items-start">
            <div>
              <div className="text-sm text-gray-500 mb-1">Total Subsidies</div>
              <div className="text-xl md:text-2xl font-bold">{formatCurrency(financeSummary.totalBksyPaid + financeSummary.totalPmksyPaid)}</div>
            </div>
            <div className="bg-white p-2 rounded-full shadow-sm">
              <IndianRupee className="h-5 w-5 text-status-install-inspected" />
            </div>
          </div>
          <div className="mt-3 text-xs text-gray-500">
            Total paid subsidies across all schemes
          </div>
        </div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-6">
        <div>
          <h3 className="text-md font-medium mb-3">PMKSY Subsidy Status</h3>
          <div className="h-[200px] md:h-64">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={pmksyPieData}
                  cx="50%"
                  cy="50%"
                  innerRadius={isMobile ? 30 : 60}
                  outerRadius={isMobile ? 50 : 80}
                  fill="#8884d8"
                  paddingAngle={2}
                  dataKey="value"
                >
                  {pmksyPieData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip formatter={(value) => formatCurrency(value as number)} />
                <Legend verticalAlign={isMobile ? "bottom" : undefined} layout={isMobile ? "horizontal" : undefined} />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>
        <div>
          <h3 className="text-md font-medium mb-3">BKSY Subsidy Status</h3>
          <div className="h-[200px] md:h-64">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={bksyPieData}
                  cx="50%"
                  cy="50%"
                  innerRadius={isMobile ? 30 : 60}
                  outerRadius={isMobile ? 50 : 80}
                  fill="#8884d8"
                  paddingAngle={2}
                  dataKey="value"
                >
                  {bksyPieData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip formatter={(value) => formatCurrency(value as number)} />
                <Legend verticalAlign={isMobile ? "bottom" : undefined} layout={isMobile ? "horizontal" : undefined} />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
      
      {/* PMKSY Due Dialog/Drawer - Responsive based on device */}
      {isMobile ? (
        <Drawer open={showPmksyDueList} onOpenChange={setShowPmksyDueList}>
          <DrawerContent className="h-[90vh] overflow-y-auto pt-10">
            <DrawerHeader className="pb-4">
              <DrawerTitle>PMKSY Due - Farmers List</DrawerTitle>
            </DrawerHeader>
            <div className="px-4 pb-8">
              {renderDuesList('PMKSY')}
            </div>
          </DrawerContent>
        </Drawer>
      ) : (
        <Dialog open={showPmksyDueList} onOpenChange={setShowPmksyDueList}>
          <DialogContent className="max-w-7xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>PMKSY Due - Farmers List</DialogTitle>
            </DialogHeader>
            {renderDuesList('PMKSY')}
          </DialogContent>
        </Dialog>
      )}
      
      {/* BKSY Due Dialog/Drawer - Responsive based on device */}
      {isMobile ? (
        <Drawer open={showBksyDueList} onOpenChange={setShowBksyDueList}>
          <DrawerContent className="h-[90vh] overflow-y-auto pt-10">
            <DrawerHeader className="pb-4">
              <DrawerTitle>BKSY Due - Farmers List</DrawerTitle>
            </DrawerHeader>
            <div className="px-4 pb-8">
              {renderDuesList('BKSY')}
            </div>
          </DrawerContent>
        </Drawer>
      ) : (
        <Dialog open={showBksyDueList} onOpenChange={setShowBksyDueList}>
          <DialogContent className="max-w-7xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>BKSY Due - Farmers List</DialogTitle>
            </DialogHeader>
            {renderDuesList('BKSY')}
          </DialogContent>
        </Dialog>
      )}
      
    </div>
  );
};

export default FinanceReports;
