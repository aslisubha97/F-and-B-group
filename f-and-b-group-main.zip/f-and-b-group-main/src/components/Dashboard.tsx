import React, { useState, useMemo, useEffect } from 'react';
import { useAppContext } from '../context/AppContext';
import { Search, BarChart2, Download, Calendar } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, Cell } from 'recharts';
import { PieChart, Pie } from 'recharts';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogClose } from "@/components/ui/dialog";
import { useIsMobile } from '@/hooks/use-mobile';

const Dashboard = () => {
  const {
    blockSummaries,
    filteredFarmerData,
    loading,
    selectedFinancialYear,
    setSelectedFinancialYear,
    financialYears
  } = useAppContext();
  
  const [searchTerm, setSearchTerm] = useState('');
  const [sortOption, setSortOption] = useState('alphabetical-asc');
  const [selectedDistrict, setSelectedDistrict] = useState('All Districts');
  const [showFarmerList, setShowFarmerList] = useState(false);
  const [dialogTitle, setDialogTitle] = useState('');
  const [farmersList, setFarmersList] = useState<any[]>([]);
  const navigate = useNavigate();
  const isMobile = useIsMobile();

  // Define status colors that match the design
  const STATUS_COLORS = {
    'newRegistration': '#FCD34D', // Yellow
    'jointInspection': '#a0d5a1', // Green
    'workOrder': '#7DE3E1', // Teal
    'install': '#93c2fd', // Blue
    'installAndInspected': '#f5abfc', // Pink/Purple
  };

  // Get all districts
  const allDistricts = useMemo(() => {
    return Array.from(new Set(blockSummaries.map(block => block.districtName ? block.districtName : 'Unknown').filter(Boolean)));
  }, [blockSummaries]);

  // Apply filters (search, district)
  const filteredBlocks = useMemo(() => {
    return blockSummaries.filter(block => block.blockName.toLowerCase().includes(searchTerm.toLowerCase())).filter(block => selectedDistrict === 'All Districts' || block.districtName && block.districtName === selectedDistrict);
  }, [blockSummaries, searchTerm, selectedDistrict]);

  // Apply sorting
  const sortedBlocks = useMemo(() => {
    return [...filteredBlocks].sort((a, b) => {
      switch (sortOption) {
        case 'alphabetical-asc':
          return a.blockName.localeCompare(b.blockName);
        case 'alphabetical-desc':
          return b.blockName.localeCompare(a.blockName);
        case 'most-registered':
          return b.totalRegistered - a.totalRegistered;
        case 'most-work-order':
          return b.workOrder - a.workOrder;
        case 'most-installed':
          return b.install - a.install;
        case 'most-inspected':
          return b.installAndInspected - a.installAndInspected;
        default:
          return a.blockName.localeCompare(b.blockName);
      }
    });
  }, [filteredBlocks, sortOption]);
  
  const handleBlockClick = (blockName: string) => {
    // Pass the current financial year filter as URL state
    navigate(`/block/${encodeURIComponent(blockName)}`, { 
      state: { financialYear: selectedFinancialYear } 
    });
  };

  // Calculate totals for all blocks
  const totalNewRegistration = blockSummaries.reduce((sum, block) => sum + block.newRegistration, 0);
  const totalJointInspection = blockSummaries.reduce((sum, block) => sum + block.jointInspection, 0);
  const totalWorkOrder = blockSummaries.reduce((sum, block) => sum + block.workOrder, 0);
  const totalInstall = blockSummaries.reduce((sum, block) => sum + block.install, 0);
  const totalInstallAndInspected = blockSummaries.reduce((sum, block) => sum + block.installAndInspected, 0);
  const totalRegistered = blockSummaries.reduce((sum, block) => sum + block.totalRegistered, 0);

  // Chart data for all blocks together
  const overallChartData = useMemo(() => {
    return blockSummaries.slice(0, isMobile ? 6 : 12).map(block => ({
      name: block.blockName,
      newRegistration: block.newRegistration,
      jointInspection: block.jointInspection,
      workOrder: block.workOrder,
      install: block.install,
      installAndInspected: block.installAndInspected
    }));
  }, [blockSummaries, isMobile]);

  // Colors that match the theme
  const chartColors = {
    newRegistration: '#FCD34D',
    jointInspection: '#a0d5a1',
    workOrder: '#7DE3E1',
    install: '#93c2fd',
    installAndInspected: '#f5abfc'
  };

  // Handle status card click to show farmers list
  const handleStatusCardClick = (status: string) => {
    let statusFilter: string;
    let statusTitle: string;
    switch (status) {
      case 'newRegistration':
        statusFilter = 'new registration';
        statusTitle = 'New Registration';
        break;
      case 'jointInspection':
        statusFilter = 'joint inspection';
        statusTitle = 'Joint Inspection';
        break;
      case 'workOrder':
        statusFilter = 'work order';
        statusTitle = 'Work Order';
        break;
      case 'install':
        statusFilter = 'install';
        statusTitle = 'Install';
        break;
      case 'installAndInspected':
        statusFilter = 'install';
        statusTitle = 'Install & Inspected';
        break;
      default:
        statusFilter = '';
        statusTitle = 'All Farmers';
    }
    
    // Apply both status and financial year filters
    const filtered = filteredFarmerData.filter(farmer => {
      if (!farmer.currentStatus) return false;
      
      // Apply status filter
      const currentStatusLower = farmer.currentStatus.toLowerCase();
      if (status === 'installAndInspected') {
        return currentStatusLower.includes('install') && currentStatusLower.includes('inspect');
      }
      if (status === 'install') {
        // Only include farmers with 'install' but not 'inspect' in status
        return currentStatusLower.includes('install') && !currentStatusLower.includes('inspect');
      }
      if (status === 'all') {
        return true;
      }
      return currentStatusLower.includes(statusFilter);
    });

    // Sort by block name alphabetically
    const sortedFarmers = [...filtered].sort((a, b) => (a.blockName || '').localeCompare(b.blockName || ''));
    setFarmersList(sortedFarmers);
    setDialogTitle(`${statusTitle} Farmers${selectedFinancialYear !== 'All Years' ? ` (${selectedFinancialYear})` : ''}`);
    setShowFarmerList(true);
  };

  // Export farmers list to CSV with financial year in filename
  const exportToCSV = (farmers: any[], filename: string) => {
    const yearSuffix = selectedFinancialYear !== 'All Years' ? `_${selectedFinancialYear}` : '';
    const headers = ['Name', 'Registration Number', 'Mobile Number', 'Block', 'District', 'Status', 'Irrigation Type', 'Tax Invoice', 'Payment Date', 'Financial Year'].join(',');
    const rows = farmers.map(farmer => [
      `"${farmer.beneficiaryName || ''}"`, 
      `"${farmer.farmerRegistrationNumber || ''}"`, 
      `"${farmer.mobileNumber || farmer.mobileNo || ''}"`, 
      `"${farmer.blockName || ''}"`, 
      `"${farmer.districtName || ''}"`, 
      `"${farmer.currentStatus || ''}"`, 
      `"${farmer.irrigationType || ''}"`, 
      `"${farmer.taxInvNo || ''}"`, 
      `"${farmer.paymentDate || ''}"`,
      `"${farmer.financialYear || ''}"`
    ].join(','));
    const csvContent = [headers, ...rows].join('\n');
    const blob = new Blob([csvContent], {
      type: 'text/csv;charset=utf-8;'
    });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `${filename}${yearSuffix}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="max-w-7xl mx-auto">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 mb-4 md:mb-6">
        <h1 className="text-xl md:text-2xl font-bold text-center md:text-left">Block Wise Data</h1>
        
        <div className="flex flex-wrap gap-2">
          <div className="relative w-full md:w-auto">
            <Input 
              type="text" 
              placeholder="Search blocks..." 
              value={searchTerm} 
              onChange={e => setSearchTerm(e.target.value)} 
              className="w-full pl-10" 
            />
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={16} />
          </div>
          
          {/* Only show these filters when search is empty */}
          {!searchTerm && (
            <>
              <div className="w-full md:w-auto">
                <Select value={sortOption} onValueChange={setSortOption}>
                  <SelectTrigger className="w-full md:w-56">
                    <SelectValue placeholder="Sort by" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="alphabetical-asc">Block Name (A-Z)</SelectItem>
                    <SelectItem value="alphabetical-desc">Block Name (Z-A)</SelectItem>
                    <SelectItem value="most-registered">Most Registered Farmers</SelectItem>
                    <SelectItem value="most-work-order">Most Work Orders</SelectItem>
                    <SelectItem value="most-installed">Most Installed</SelectItem>
                    <SelectItem value="most-inspected">Most Installed & Inspected</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="w-full md:w-auto">
                <Select value={selectedDistrict} onValueChange={setSelectedDistrict}>
                  <SelectTrigger className="w-full md:w-56">
                    <SelectValue placeholder="Filter by district" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="All Districts">All Districts</SelectItem>
                    {allDistricts.map(district => <SelectItem key={district} value={district}>{district}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              
              {/* Financial Year Selector */}
              <div className="w-full md:w-auto">
                <Select value={selectedFinancialYear} onValueChange={value => setSelectedFinancialYear(value)}>
                  <SelectTrigger className="w-full md:w-56">
                    <SelectValue placeholder="Financial Year">
                      <span className="flex items-center">
                        <Calendar className="mr-2 h-4 w-4" />
                        {selectedFinancialYear}
                      </span>
                    </SelectValue>
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="All Years">All Years</SelectItem>
                    {financialYears.map(year => (
                      <SelectItem key={year} value={year}>{year}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </>
          )}
        </div>
      </div>
      
      {/* Only show these cards when search is empty */}
      {!searchTerm && (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-4 mb-4 md:mb-6">
          {/* Registration Stages Summary Cards */}
          <div className="bg-white rounded-lg shadow-sm p-4 hover:shadow-md transition-all cursor-pointer border-l-4 border-sidebar-primary" onClick={() => handleStatusCardClick('all')}>
            <div className="flex flex-col">
              <span className="text-sm text-gray-500">Total Farmers</span>
              <span className="text-xl font-bold">{totalRegistered}</span>
              <Button variant="ghost" size="sm" className="mt-2 text-xs flex items-center justify-center" onClick={e => {
              e.stopPropagation();
              exportToCSV(filteredFarmerData, 'all_farmers');
            }}>
                <Download size={12} className="mr-1" /> Export
              </Button>
            </div>
          </div>
          
          {/* Rest of the status cards */}
          <div className="bg-white rounded-lg shadow-sm p-4 hover:shadow-md transition-all cursor-pointer border-l-4 border-status-new-registration" onClick={() => handleStatusCardClick('newRegistration')}>
            <div className="flex flex-col">
              <span className="text-sm text-gray-500">New Registration</span>
              <span className="text-xl font-bold">{totalNewRegistration}</span>
              <Button variant="ghost" size="sm" className="mt-2 text-xs flex items-center justify-center" onClick={e => {
              e.stopPropagation();
              exportToCSV(filteredFarmerData.filter(f => f.currentStatus && f.currentStatus.toLowerCase().includes('new registration')), 'new_registration');
            }}>
                <Download size={12} className="mr-1" /> Export
              </Button>
            </div>
          </div>
          
          <div className="bg-white rounded-lg shadow-sm p-4 hover:shadow-md transition-all cursor-pointer border-l-4 border-status-joint-inspection" onClick={() => handleStatusCardClick('jointInspection')}>
            <div className="flex flex-col">
              <span className="text-sm text-gray-500">Joint Inspection</span>
              <span className="text-xl font-bold">{totalJointInspection}</span>
              <Button variant="ghost" size="sm" className="mt-2 text-xs flex items-center justify-center" onClick={e => {
              e.stopPropagation();
              exportToCSV(filteredFarmerData.filter(f => f.currentStatus && f.currentStatus.toLowerCase().includes('joint inspection')), 'joint_inspection');
            }}>
                <Download size={12} className="mr-1" /> Export
              </Button>
            </div>
          </div>
          
          <div className="bg-white rounded-lg shadow-sm p-4 hover:shadow-md transition-all cursor-pointer border-l-4 border-status-work-order" onClick={() => handleStatusCardClick('workOrder')}>
            <div className="flex flex-col">
              <span className="text-sm text-gray-500">Work Order</span>
              <span className="text-xl font-bold">{totalWorkOrder}</span>
              <Button variant="ghost" size="sm" className="mt-2 text-xs flex items-center justify-center" onClick={e => {
              e.stopPropagation();
              exportToCSV(filteredFarmerData.filter(f => f.currentStatus && f.currentStatus.toLowerCase().includes('work order')), 'work_order');
            }}>
                <Download size={12} className="mr-1" /> Export
              </Button>
            </div>
          </div>
          
          <div className="bg-white rounded-lg shadow-sm p-4 hover:shadow-md transition-all cursor-pointer border-l-4 border-status-install" onClick={() => handleStatusCardClick('install')}>
            <div className="flex flex-col">
              <span className="text-sm text-gray-500">Installed</span>
              <span className="text-xl font-bold">{totalInstall}</span>
              <Button variant="ghost" size="sm" className="mt-2 text-xs flex items-center justify-center" onClick={e => {
              e.stopPropagation();
              exportToCSV(filteredFarmerData.filter(f => {
                if (!f.currentStatus) return false;
                const status = f.currentStatus.toLowerCase();
                return status.includes('install') && !status.includes('inspect');
              }), 'installed');
            }}>
                <Download size={12} className="mr-1" /> Export
              </Button>
            </div>
          </div>
          
          <div className="bg-white rounded-lg shadow-sm p-4 hover:shadow-md transition-all cursor-pointer border-l-4 border-status-install-inspected" onClick={() => handleStatusCardClick('installAndInspected')}>
            <div className="flex flex-col">
              <span className="text-sm text-gray-500">Installed & Insp.</span>
              <span className="text-xl font-bold">{totalInstallAndInspected}</span>
              <Button variant="ghost" size="sm" className="mt-2 text-xs flex items-center justify-center" onClick={e => {
              e.stopPropagation();
              exportToCSV(filteredFarmerData.filter(f => {
                if (!f.currentStatus) return false;
                const status = f.currentStatus.toLowerCase();
                return status.includes('install') && status.includes('inspect');
              }), 'installed_and_inspected');
            }}>
                <Download size={12} className="mr-1" /> Export
              </Button>
            </div>
          </div>
        </div>
      )}
      
      {/* Only show this chart when search is empty AND not mobile - MODIFIED TO HIDE ON MOBILE */}
      {!searchTerm && !isMobile && (
        <div className="bg-white rounded-lg shadow-sm p-4 mb-4 md:mb-6">
          <h2 className="text-lg font-semibold mb-3 md:mb-4 text-center">Blocks Overview</h2>
          <div className="h-[400px] md:h-80">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart 
                data={overallChartData}
                margin={{ 
                  top: 20, 
                  right: isMobile ? 5 : 20, 
                  left: isMobile ? 0 : 20,
                  bottom: isMobile ? 120 : 60
                }}
                barSize={isMobile ? 6 : 30}
                barGap={isMobile ? 1 : 5}
              >
                <CartesianGrid strokeDasharray="3 3" opacity={0.3} />
                <XAxis 
                  dataKey="name" 
                  angle={-45} 
                  textAnchor="end" 
                  height={isMobile ? 100 : 60} 
                  tick={{ fontSize: isMobile ? 8 : 10 }} 
                  interval={0} 
                />
                <YAxis tick={{ fontSize: isMobile ? 8 : 10 }} />
                <Tooltip 
                  formatter={(value, name) => {
                    const labels = {
                      newRegistration: 'New Registration',
                      jointInspection: 'Joint Inspection',
                      workOrder: 'Work Order',
                      install: 'Install',
                      installAndInspected: 'Install & Inspection'
                    };
                    return [value, labels[name as keyof typeof labels] || name];
                  }}
                  wrapperStyle={{ fontSize: isMobile ? '10px' : '12px' }}
                />
                <Legend 
                  verticalAlign="bottom"
                  wrapperStyle={{
                    paddingTop: "20px",
                    fontSize: isMobile ? "8px" : "12px",
                    marginBottom: isMobile ? "20px" : "0"
                  }}
                  formatter={(value) => {
                    const labels = {
                      newRegistration: 'New Reg.',
                      jointInspection: 'Joint Insp.',
                      workOrder: 'Work Order',
                      install: 'Install',
                      installAndInspected: 'Install & Insp.'
                    };
                    return labels[value as keyof typeof labels] || value;
                  }}
                />
                <Bar 
                  dataKey="newRegistration" 
                  name="newRegistration" 
                  fill={STATUS_COLORS.newRegistration}
                  radius={[4, 4, 0, 0]} 
                />
                <Bar 
                  dataKey="jointInspection" 
                  name="jointInspection" 
                  fill={STATUS_COLORS.jointInspection}
                  radius={[4, 4, 0, 0]}
                />
                <Bar 
                  dataKey="workOrder" 
                  name="workOrder" 
                  fill={STATUS_COLORS.workOrder}
                  radius={[4, 4, 0, 0]}
                />
                <Bar 
                  dataKey="install" 
                  name="install" 
                  fill={STATUS_COLORS.install}
                  radius={[4, 4, 0, 0]}
                />
                <Bar 
                  dataKey="installAndInspected" 
                  name="installAndInspected" 
                  fill={STATUS_COLORS.installAndInspected}
                  radius={[4, 4, 0, 0]}
                />
              </BarChart>
            </ResponsiveContainer>
          </div>
          {isMobile && blockSummaries.length > 6 ? (
            <div className="text-center mt-2 text-xs text-gray-500">
              Showing top 6 of {blockSummaries.length} blocks
            </div>
          ) : blockSummaries.length > 12 && (
            <div className="text-center mt-2 text-sm text-gray-500">
              Showing top 12 of {blockSummaries.length} blocks
            </div>
          )}
        </div>
      )}
      
      {/* Block Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-6">
        {loading ? (
          <div className="col-span-full text-center py-12">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-sidebar-primary mx-auto"></div>
            <p className="mt-4 text-gray-600">Loading block data...</p>
          </div>
        ) : sortedBlocks.length > 0 ? (
          sortedBlocks.map(block => (
            <div key={block.blockName} className="bg-white rounded-lg shadow-sm overflow-hidden hover:shadow-md transition-shadow cursor-pointer" onClick={() => handleBlockClick(block.blockName)}>
              <div className="p-4 border-b">
                <h3 className="text-lg font-semibold text-sidebar-primary">
                  {block.blockName}
                </h3>
                <div className="text-sm text-gray-500">
                  {block.districtName && <span>District: {block.districtName} | </span>}
                  Total Farmers: {block.totalRegistered}
                </div>
              </div>
              
              <div className="p-4">
                <div className="flex items-start">
                  <div className="w-1/2">
                    <h4 className="text-sm font-medium mb-2">Registration & Financial Summary</h4>
                    <div className="space-y-1 text-xs">
                      <div className="flex justify-between">
                        <span>New Registration</span>
                        <span>{block.newRegistration}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Joint Inspection</span>
                        <span>{block.jointInspection}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Work Order</span>
                        <span>{block.workOrder}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Install</span>
                        <span>{block.install}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Install & Inspection</span>
                        <span>{block.installAndInspected}</span>
                      </div>
                    </div>
                  </div>
                  
                  <div className="w-1/2">
                    <div className="h-28">
                      <ResponsiveContainer width="100%" height="100%">
                        <PieChart>
                          <Pie data={[
                            {
                              name: 'New Reg',
                              value: block.newRegistration,
                              fill: chartColors.newRegistration
                            },
                            {
                              name: 'Joint Insp',
                              value: block.jointInspection,
                              fill: chartColors.jointInspection
                            },
                            {
                              name: 'Work Order',
                              value: block.workOrder,
                              fill: chartColors.workOrder
                            },
                            {
                              name: 'Install',
                              value: block.install,
                              fill: chartColors.install
                            },
                            {
                              name: 'Install+Insp',
                              value: block.installAndInspected,
                              fill: chartColors.installAndInspected
                            }
                          ]} 
                          cx="50%" 
                          cy="50%" 
                          innerRadius={25} 
                          outerRadius={40} 
                          dataKey="value" />
                        </PieChart>
                      </ResponsiveContainer>
                    </div>
                  </div>
                </div>
                
                <div className="mt-2 pt-2 border-t">
                  <div className="flex justify-between items-center">
                    <span className="text-xs">Completion Rate</span>
                    <span className="text-xs font-medium">
                      {/* Fix percentage calculation to show proper value */}
                      {block.totalRegistered > 0 
                        ? Math.round((block.installAndInspected / block.totalRegistered) * 100) 
                        : 0}%
                    </span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2 mt-1">
                    <div 
                      style={{
                        width: `${block.totalRegistered > 0 
                          ? Math.round((block.installAndInspected / block.totalRegistered) * 100) 
                          : 0}%`
                      }} 
                      className="h-2 rounded-full bg-emerald-600">
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ))
        ) : (
          <div className="col-span-full text-center py-12">
            <BarChart2 className="h-12 w-12 mx-auto text-gray-400 mb-3" />
            <p className="text-gray-600">No matching blocks found</p>
          </div>
        )}
      </div>
      
      {/* Farmers List Dialog */}
      {showFarmerList && (
        <Dialog open={showFarmerList} onOpenChange={setShowFarmerList}>
          <DialogContent className="max-w-5xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>{dialogTitle}</DialogTitle>
              <DialogDescription>
                Total: {farmersList.length} farmers
                {selectedFinancialYear !== 'All Years' && (
                  <span className="ml-2 px-2 py-1 bg-blue-100 text-blue-800 rounded text-xs">
                    Financial Year: {selectedFinancialYear}
                  </span>
                )}
              </DialogDescription>
            </DialogHeader>
            
            <div className="flex justify-end mb-4">
              <Button 
                variant="outline" 
                size="sm"
                className="flex items-center gap-1" 
                onClick={() => exportToCSV(farmersList, dialogTitle.toLowerCase().replace(/ /g, '_'))}
              >
                <Download size={14} />
                Export to CSV
              </Button>
            </div>
            
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Name</th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Registration No.</th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Block</th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Financial Year</th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {farmersList.map((farmer, index) => (
                    <tr key={index} className="hover:bg-gray-50">
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{farmer.beneficiaryName || 'N/A'}</td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{farmer.farmerRegistrationNumber || 'N/A'}</td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{farmer.blockName || 'N/A'}</td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{farmer.currentStatus || 'N/A'}</td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{farmer.financialYear || 'N/A'}</td>
                    </tr>
                  ))}
                  {farmersList.length === 0 && (
                    <tr>
                      <td colSpan={5} className="px-6 py-4 text-center text-sm text-gray-500">No farmers found with the selected criteria.</td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
            
            <div className="flex justify-end mt-4">
              <DialogClose asChild>
                <Button variant="outline">Close</Button>
              </DialogClose>
            </div>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
};

export default Dashboard;
