import React, { useState, useMemo, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { useAppContext } from '../context/AppContext';
import { ArrowLeft, BarChart2, Download, ChevronUp, ChevronRight, User, UserCheck, Calendar, MapPin } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogClose } from "@/components/ui/dialog";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, PieChart, Pie, Cell, Sector } from 'recharts';
import { useIsMobile } from '@/hooks/use-mobile';
import { Heading } from '../components/ui/heading';

const BlockDetail = ({ blockName }: { blockName: string }) => {
  const { filteredFarmerData, selectedFinancialYear, setSelectedFinancialYear, financialYears } = useAppContext();
  const [showFarmerList, setShowFarmerList] = useState(false);
  const [dialogTitle, setDialogTitle] = useState('');
  const [farmersList, setFarmersList] = useState<any[]>([]);
  const navigate = useNavigate();
  const location = useLocation();
  const isMobile = useIsMobile();

  // Get block specific farmers
  const blockFarmers = useMemo(() => {
    return filteredFarmerData.filter(farmer => farmer.blockName === blockName);
  }, [filteredFarmerData, blockName]);

  // Calculate summary data for the block
  const blockSummary = useMemo(() => {
    let newRegistration = 0;
    let jointInspection = 0;
    let workOrder = 0;
    let install = 0;
    let installAndInspected = 0;
    
    blockFarmers.forEach(farmer => {
      if (!farmer.currentStatus) return;
      
      const status = farmer.currentStatus.toLowerCase();
      if (status.includes('new registration')) {
        newRegistration++;
      } else if (status.includes('joint inspection')) {
        jointInspection++;
      } else if (status.includes('work order')) {
        workOrder++;
      } else if (status.includes('install') && status.includes('inspect')) {
        installAndInspected++;
      } else if (status.includes('install')) {
        install++;
      }
    });
    
    return {
      totalRegistered: blockFarmers.length,
      newRegistration,
      jointInspection,
      workOrder,
      install,
      installAndInspected
    };
  }, [blockFarmers]);

  // Get unique irrigation types and calculate percentages
  const irrigationData = useMemo(() => {
    const typeCounts: Record<string, number> = {};
    
    blockFarmers.forEach(farmer => {
      const type = farmer.irrigationType || 'Not Specified';
      typeCounts[type] = (typeCounts[type] || 0) + 1;
    });
    
    const colors = ['#0EA5E9', '#10B981', '#F59E0B', '#8B5CF6', '#EC4899', '#6366F1', '#F97316'];
    return Object.entries(typeCounts).map(([name, value], index) => ({
      name,
      value,
      color: colors[index % colors.length],
      percent: Math.round((value / blockFarmers.length) * 100)
    }));
  }, [blockFarmers]);

  // Get gram panchayats and calculate counts
  const gramPanchayatData = useMemo(() => {
    const gpCounts: Record<string, number> = {};
    
    blockFarmers.forEach(farmer => {
      const gp = farmer.gramPanchayet || 'Not Specified';
      gpCounts[gp] = (gpCounts[gp] || 0) + 1;
    });
    
    const colors = ['#4DD4AC', '#38BDF8', '#FB7185', '#FACC15', '#C084FC', '#F43F5E', '#0EA5E9'];
    return Object.entries(gpCounts)
      .map(([name, value], index) => ({
        name,
        value,
        color: colors[index % colors.length]
      }))
      .sort((a, b) => b.value - a.value)
      .slice(0, 10); // Take top 10
  }, [blockFarmers]);

  // Calculate financial summary with UPDATED logic based on requirements
  const financialSummary = useMemo(() => {
    let totalPmksySubsidy = 0;
    let totalBksySubsidy = 0;
    let totalPmksyPaid = 0;
    let totalBksyPaid = 0;
    let totalGstSubmitted = 0;
    let totalGstDue = 0;
    
    blockFarmers.forEach(farmer => {
      // PMKSY calculations
      if (farmer.pmksySubsidy) {
        const pmksyAmount = parseFloat(farmer.pmksySubsidy) || 0;
        totalPmksySubsidy += pmksyAmount;
        
        // Check if PMKSY is paid (pmksyAmountPaid > 0)
        if (farmer.pmksyAmountPaid && parseFloat(farmer.pmksyAmountPaid) > 0) {
          const pmksyPaid = parseFloat(farmer.pmksyAmountPaid);
          totalPmksyPaid += pmksyPaid;
        }
      }
      
      // BKSY calculations
      if (farmer.bksySubsidy) {
        const bksyAmount = parseFloat(farmer.bksySubsidy) || 0;
        totalBksySubsidy += bksyAmount;
        
        // Check if BKSY is paid (bksyAmountPaid > 0)
        if (farmer.bksyAmountPaid && parseFloat(farmer.bksyAmountPaid) > 0) {
          const bksyPaid = parseFloat(farmer.bksyAmountPaid);
          totalBksyPaid += bksyPaid;
        }
      }
      
      // GST calculations based on new logic
      if (farmer.gstAmount && parseFloat(farmer.gstAmount) > 0) {
        const gstAmount = parseFloat(farmer.gstAmount);
        
        // If Payment Reference exists, GST is submitted
        if (farmer.paymentReference && farmer.paymentReference.trim() !== '') {
          totalGstSubmitted += gstAmount;
        } else {
          // No payment reference means GST is due
          totalGstDue += gstAmount;
        }
      }
    });
    
    return {
      totalPmksySubsidy,
      totalBksySubsidy,
      totalPmksyPaid,
      totalBksyPaid,
      pmksyPending: totalPmksySubsidy - totalPmksyPaid,
      bksyPending: totalBksySubsidy - totalBksyPaid,
      totalGstSubmitted,
      totalGstDue
    };
  }, [blockFarmers]);

  // Status data for charts
  const statusData = useMemo(() => {
    return [
      { name: 'New Registration', value: blockSummary.newRegistration, color: '#FCD34D' },
      { name: 'Joint Inspection', value: blockSummary.jointInspection, color: '#a0d5a1' },
      { name: 'Work Order', value: blockSummary.workOrder, color: '#7DE3E1' },
      { name: 'Install', value: blockSummary.install, color: '#93c2fd' },
      { name: 'Install & Inspected', value: blockSummary.installAndInspected, color: '#f5abfc' }
    ];
  }, [blockSummary]);

  // Format currency
  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    }).format(amount);
  };

  // Handle status card click to show farmers list
  const handleStatusCardClick = (status: string) => {
    let statusFilter: string;
    let statusTitle: string;
    
    switch (status) {
      case 'newRegistration':
        statusFilter = 'new registration';
        statusTitle = 'New Registration';
        break;
      case 'jointInspection':
        statusFilter = 'joint inspection';
        statusTitle = 'Joint Inspection';
        break;
      case 'workOrder':
        statusFilter = 'work order';
        statusTitle = 'Work Order';
        break;
      case 'install':
        statusFilter = 'install';
        statusTitle = 'Install';
        break;
      case 'installAndInspected':
        statusFilter = 'install';
        statusTitle = 'Install & Inspected';
        break;
      case 'pmksyPending':
        statusTitle = 'PMKSY Pending Payment';
        break;
      case 'bksyPending':
        statusTitle = 'BKSY Pending Payment';
        break;
      case 'gstPending':
        statusTitle = 'GST Pending';
        break;
      default:
        statusFilter = '';
        statusTitle = 'All Farmers';
    }
    
    // Apply filters based on status with UPDATED logic
    let filtered = blockFarmers;
    if (status === 'pmksyPending') {
      filtered = blockFarmers.filter(farmer => {
        const hasPmksySubsidy = farmer.pmksySubsidy && parseFloat(farmer.pmksySubsidy) > 0;
        const hasNoPmksyPaid = !farmer.pmksyAmountPaid || parseFloat(farmer.pmksyAmountPaid) <= 0;
        return hasPmksySubsidy && hasNoPmksyPaid;
      });
    } else if (status === 'bksyPending') {
      filtered = blockFarmers.filter(farmer => {
        const hasBksySubsidy = farmer.bksySubsidy && parseFloat(farmer.bksySubsidy) > 0;
        const hasNoBksyPaid = !farmer.bksyAmountPaid || parseFloat(farmer.bksyAmountPaid) <= 0;
        return hasBksySubsidy && hasNoBksyPaid;
      });
    } else if (status === 'gstPending') {
      filtered = blockFarmers.filter(farmer => {
        const hasGstAmount = farmer.gstAmount && parseFloat(farmer.gstAmount) > 0;
        const noPaymentReference = !farmer.paymentReference || farmer.paymentReference.trim() === '';
        return hasGstAmount && noPaymentReference;
      });
    } else if (status !== 'all') {
      filtered = blockFarmers.filter(farmer => {
        if (!farmer.currentStatus) return false;
        
        const currentStatusLower = farmer.currentStatus.toLowerCase();
        if (status === 'installAndInspected') {
          return currentStatusLower.includes('install') && currentStatusLower.includes('inspect');
        }
        if (status === 'install') {
          return currentStatusLower.includes('install') && !currentStatusLower.includes('inspect');
        }
        return currentStatusLower.includes(statusFilter);
      });
    }
    
    setFarmersList(filtered);
    setDialogTitle(`${statusTitle} Farmers in ${blockName}`);
    setShowFarmerList(true);
  };

  // Export farmers list to CSV
  const exportToCSV = (farmers: any[], filename: string) => {
    const headers = ['Name', 'Registration Number', 'Mobile Number', 'Status', 'Irrigation Type', 'PMKSY Subsidy', 'BKSY Subsidy'].join(',');
    const rows = farmers.map(farmer => [
      `"${farmer.beneficiaryName || ''}"`,
      `"${farmer.farmerRegistrationNumber || ''}"`,
      `"${farmer.mobileNumber || farmer.mobileNo || ''}"`,
      `"${farmer.currentStatus || ''}"`,
      `"${farmer.irrigationType || ''}"`,
      `"${farmer.pmksySubsidy || 0}"`,
      `"${farmer.bksySubsidy || 0}"`
    ].join(','));
    
    const csvContent = [headers, ...rows].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `${blockName}_${filename}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="animate-fade-in">
      <div className="mb-6 flex flex-col md:flex-row md:justify-between md:items-center">
        <div className="flex items-center">
          <Button variant="ghost" onClick={() => navigate(-1)} className="mr-2">
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <Heading
            title={blockName}
            description={`Block data ${selectedFinancialYear !== 'All Years' ? `for ${selectedFinancialYear}` : ''}`}
          />
        </div>
        
        <div className="mt-4 md:mt-0">
          <Select value={selectedFinancialYear} onValueChange={setSelectedFinancialYear}>
            <SelectTrigger className="w-full md:w-48">
              <SelectValue placeholder="Financial Year">
                <span className="flex items-center">
                  <Calendar className="mr-2 h-4 w-4" />
                  {selectedFinancialYear}
                </span>
              </SelectValue>
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="All Years">All Years</SelectItem>
              {financialYears.map(year => (
                <SelectItem key={year} value={year}>{year}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>
      
      {/* Total Farmers and Registration Tiles - 2 per row on mobile */}
      <div className="grid grid-cols-2 md:grid-cols-6 gap-4 mb-6">
        {/* Total Farmers Card */}
        <div className="bg-white rounded-lg shadow-sm p-4 hover:shadow-md transition-all cursor-pointer border-l-4 border-sidebar-primary" onClick={() => handleStatusCardClick('all')}>
          <div className="flex flex-col">
            <span className="text-sm text-gray-500">Total Farmers</span>
            <span className="text-xl font-bold">{blockSummary.totalRegistered}</span>
            <Button variant="ghost" size="sm" className="mt-2 text-xs flex items-center justify-center" onClick={(e) => {
              e.stopPropagation();
              exportToCSV(blockFarmers, 'all_farmers');
            }}>
              <Download size={12} className="mr-1" /> Export
            </Button>
          </div>
        </div>
        
        {/* Registration Status Cards */}
        <div className="bg-white rounded-lg shadow-sm p-4 hover:shadow-md transition-all cursor-pointer border-l-4 border-status-new-registration" onClick={() => handleStatusCardClick('newRegistration')}>
          <div className="flex flex-col">
            <span className="text-sm text-gray-500">New Registration</span>
            <span className="text-xl font-bold">{blockSummary.newRegistration}</span>
          </div>
        </div>
        
        <div className="bg-white rounded-lg shadow-sm p-4 hover:shadow-md transition-all cursor-pointer border-l-4 border-status-joint-inspection" onClick={() => handleStatusCardClick('jointInspection')}>
          <div className="flex flex-col">
            <span className="text-sm text-gray-500">Joint Inspection</span>
            <span className="text-xl font-bold">{blockSummary.jointInspection}</span>
          </div>
        </div>
        
        <div className="bg-white rounded-lg shadow-sm p-4 hover:shadow-md transition-all cursor-pointer border-l-4 border-status-work-order" onClick={() => handleStatusCardClick('workOrder')}>
          <div className="flex flex-col">
            <span className="text-sm text-gray-500">Work Order</span>
            <span className="text-xl font-bold">{blockSummary.workOrder}</span>
          </div>
        </div>
        
        <div className="bg-white rounded-lg shadow-sm p-4 hover:shadow-md transition-all cursor-pointer border-l-4 border-status-install" onClick={() => handleStatusCardClick('install')}>
          <div className="flex flex-col">
            <span className="text-sm text-gray-500">Installed</span>
            <span className="text-xl font-bold">{blockSummary.install}</span>
          </div>
        </div>
        
        <div className="bg-white rounded-lg shadow-sm p-4 hover:shadow-md transition-all cursor-pointer border-l-4 border-status-install-inspected" onClick={() => handleStatusCardClick('installAndInspected')}>
          <div className="flex flex-col">
            <span className="text-sm text-gray-500">Installed & Insp.</span>
            <span className="text-xl font-bold">{blockSummary.installAndInspected}</span>
          </div>
        </div>
      </div>
      
      {/* Merged Overview and Financial Content - No more tabs */}
      <div className="space-y-6">
        {/* First Row - Financial Cards from Financial tab */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
          <Card className="bg-gradient-to-br from-status-new-registration/10 to-status-new-registration/20" onClick={() => handleStatusCardClick('pmksyPending')}>
            <CardContent className="p-5 cursor-pointer">
              <h3 className="text-sm font-medium text-gray-700">PMKSY Pending</h3>
              <p className="text-xl font-bold mt-1">{formatCurrency(financialSummary.pmksyPending)}</p>
              <p className="text-xs text-gray-500 mt-2">Click for details</p>
            </CardContent>
          </Card>
          
          <Card className="bg-gradient-to-br from-status-joint-inspection/10 to-status-joint-inspection/20">
            <CardContent className="p-5">
              <h3 className="text-sm font-medium text-gray-700">PMKSY Paid</h3>
              <p className="text-xl font-bold mt-1">{formatCurrency(financialSummary.totalPmksyPaid)}</p>
              <p className="text-xs text-gray-500 mt-2">
                {(financialSummary.totalPmksySubsidy > 0 ? 
                  (financialSummary.totalPmksyPaid / financialSummary.totalPmksySubsidy) * 100 : 0).toFixed(1)}% of total
              </p>
            </CardContent>
          </Card>
          
          <Card className="bg-gradient-to-br from-status-work-order/10 to-status-work-order/20" onClick={() => handleStatusCardClick('bksyPending')}>
            <CardContent className="p-5 cursor-pointer">
              <h3 className="text-sm font-medium text-gray-700">BKSY Pending</h3>
              <p className="text-xl font-bold mt-1">{formatCurrency(financialSummary.bksyPending)}</p>
              <p className="text-xs text-gray-500 mt-2">Click for details</p>
            </CardContent>
          </Card>
          
          <Card className="bg-gradient-to-br from-status-install/10 to-status-install/20">
            <CardContent className="p-5">
              <h3 className="text-sm font-medium text-gray-700">BKSY Paid</h3>
              <p className="text-xl font-bold mt-1">{formatCurrency(financialSummary.totalBksyPaid)}</p>
              <p className="text-xs text-gray-500 mt-2">
                {(financialSummary.totalBksySubsidy > 0 ? 
                  (financialSummary.totalBksyPaid / financialSummary.totalBksySubsidy) * 100 : 0).toFixed(1)}% of total
              </p>
            </CardContent>
          </Card>
        </div>
        
        {/* Second Row - GST Section from Financial tab */}
        <div className="grid grid-cols-2 md:grid-cols-2 gap-4 mb-6">
          <Card className="bg-gradient-to-br from-emerald-50 to-white" onClick={() => handleStatusCardClick('gstPending')}>
            <CardContent className="p-5 cursor-pointer">
              <h3 className="text-sm font-medium text-gray-700">GST Due</h3>
              <p className="text-xl font-bold mt-1 text-red-600">{formatCurrency(financialSummary.totalGstDue)}</p>
              <p className="text-xs text-gray-500 mt-2">Click for details</p>
            </CardContent>
          </Card>
          
          <Card className="bg-gradient-to-br from-blue-50 to-white">
            <CardContent className="p-5">
              <h3 className="text-sm font-medium text-gray-700">GST Submitted</h3>
              <p className="text-xl font-bold mt-1">{formatCurrency(financialSummary.totalGstSubmitted)}</p>
              <p className="text-xs text-gray-500 mt-2">
                {(financialSummary.totalGstSubmitted + financialSummary.totalGstDue) > 0 ? 
                  Math.round((financialSummary.totalGstSubmitted / (financialSummary.totalGstSubmitted + financialSummary.totalGstDue)) * 100) : 0}% submitted
              </p>
            </CardContent>
          </Card>
        </div>
        
        {/* Third Row - Financial Summary Card */}
        <Card>
          <CardHeader>
            <CardTitle>Financial Summary</CardTitle>
            <CardDescription>Subsidy allocation and payments</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div>
                <h4 className="font-medium mb-2">PMKSY</h4>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <p className="text-sm text-gray-500">Total Subsidy</p>
                    <p className="font-medium">{formatCurrency(financialSummary.totalPmksySubsidy)}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-500">Total Paid</p>
                    <p className="font-medium">{formatCurrency(financialSummary.totalPmksyPaid)}</p>
                  </div>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2.5 mt-2">
                  <div 
                    className="bg-emerald-500 h-2.5 rounded-full" 
                    style={{ width: `${financialSummary.totalPmksySubsidy > 0 ? (financialSummary.totalPmksyPaid / financialSummary.totalPmksySubsidy) * 100 : 0}%` }}
                  ></div>
                </div>
              </div>
              
              <div>
                <h4 className="font-medium mb-2">BKSY</h4>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <p className="text-sm text-gray-500">Total Subsidy</p>
                    <p className="font-medium">{formatCurrency(financialSummary.totalBksySubsidy)}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-500">Total Paid</p>
                    <p className="font-medium">{formatCurrency(financialSummary.totalBksyPaid)}</p>
                  </div>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2.5 mt-2">
                  <div 
                    className="bg-emerald-500 h-2.5 rounded-full" 
                    style={{ width: `${financialSummary.totalBksySubsidy > 0 ? (financialSummary.totalBksyPaid / financialSummary.totalBksySubsidy) * 100 : 0}%` }}
                  ></div>
                </div>
              </div>
              
              <div>
                <h4 className="font-medium mb-2">GST</h4>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <p className="text-sm text-gray-500">Total Due</p>
                    <p className="font-medium">{formatCurrency(financialSummary.totalGstDue)}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-500">Total Submitted</p>
                    <p className="font-medium">{formatCurrency(financialSummary.totalGstSubmitted)}</p>
                  </div>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2.5 mt-2">
                  <div 
                    className="bg-emerald-500 h-2.5 rounded-full" 
                    style={{ width: `${(financialSummary.totalGstSubmitted + financialSummary.totalGstDue) > 0 ? 
                      (financialSummary.totalGstSubmitted / (financialSummary.totalGstSubmitted + financialSummary.totalGstDue)) * 100 : 0}%` }}
                  ></div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
        
        {/* MOVED: Irrigation Types chart now second from bottom */}
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg">Irrigation Types</CardTitle>
            <CardDescription>Distribution of irrigation systems</CardDescription>
          </CardHeader>
          <CardContent className={`${isMobile ? "h-80" : "h-64"}`}>
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={irrigationData}
                  cx="50%"
                  cy="50%"
                  innerRadius={isMobile ? 40 : 60}
                  outerRadius={isMobile ? 80 : 90}
                  paddingAngle={2}
                  dataKey="value"
                  nameKey="name"
                  label={({ name, percent }) => 
                    isMobile ? `${percent}%` : `${name.substring(0, 10)}${name.length > 10 ? '...' : ''}: ${percent}%`
                  }
                  labelLine={false}
                >
                  {irrigationData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip 
                  formatter={(value, name) => [
                    `${value} farmers (${irrigationData.find(item => item.name === name)?.percent || 0}%)`, 
                    name
                  ]} 
                />
                <Legend 
                  layout={isMobile ? "vertical" : "horizontal"}
                  verticalAlign={isMobile ? "bottom" : "bottom"}
                  align="center"
                  wrapperStyle={isMobile ? { fontSize: '10px', paddingTop: '10px' } : {}}
                />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
        
        {/* MOVED: Gram Panchayat Distribution now at bottom */}
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg flex items-center">
              <MapPin className="h-5 w-5 mr-2 text-gray-500" />
              Gram Panchayat Distribution
            </CardTitle>
            <CardDescription>Farmers by Gram Panchayat</CardDescription>
          </CardHeader>
          <CardContent className={`${isMobile ? "h-80" : "h-64"} overflow-x-auto`}>
            <ResponsiveContainer width="100%" height="100%">
              <BarChart 
                data={gramPanchayatData} 
                layout="vertical" 
                margin={{ top: 5, right: 30, left: isMobile ? 80 : 100, bottom: 5 }}
              >
                <CartesianGrid strokeDasharray="3 3" horizontal={true} vertical={false} />
                <XAxis type="number" />
                <YAxis 
                  dataKey="name" 
                  type="category" 
                  width={isMobile ? 80 : 100}
                  tick={{ fontSize: isMobile ? 10 : 12 }}
                />
                <Tooltip formatter={(value) => [`${value} farmers`, 'Count']} />
                <Bar dataKey="value" name="Farmers">
                  {gramPanchayatData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>
      
      {/* Farmers List Dialog */}
      <Dialog open={showFarmerList} onOpenChange={setShowFarmerList}>
        <DialogContent className="max-w-5xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{dialogTitle}</DialogTitle>
            <DialogDescription>
              Total: {farmersList.length} farmers
            </DialogDescription>
          </DialogHeader>
          
          <div className="flex justify-end mb-4">
            <Button 
              variant="outline" 
              size="sm"
              className="flex items-center gap-1" 
              onClick={() => exportToCSV(farmersList, dialogTitle.toLowerCase().replace(/ /g, '_'))}
            >
              <Download size={14} />
              Export to CSV
            </Button>
          </div>
          
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Name</th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Registration No.</th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Irrigation Type</th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {farmersList.map((farmer, index) => (
                  <tr key={index} className="hover:bg-gray-50">
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{farmer.beneficiaryName || 'N/A'}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{farmer.farmerRegistrationNumber || 'N/A'}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{farmer.currentStatus || 'N/A'}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{farmer.irrigationType || 'N/A'}</td>
                  </tr>
                ))}
                {farmersList.length === 0 && (
                  <tr>
                    <td colSpan={4} className="px-6 py-4 text-center text-sm text-gray-500">No farmers found with the selected criteria.</td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
          
          <DialogClose asChild>
            <Button variant="outline">Close</Button>
          </DialogClose>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default BlockDetail;
