
import React, { useMemo, useState } from 'react';
import { useAppContext } from '../context/AppContext';
import { Loader, IndianRupee, Calendar, FileText, ArrowUpRight } from 'lucide-react';
import { formatDistance } from 'date-fns';
import { Button } from '@/components/ui/button';
import { useIsMobile } from '@/hooks/use-mobile';

const InvoiceDashboard = () => {
  const { filteredFarmerData, loading, selectedFinancialYear } = useAppContext();
  const [billsToShow, setBillsToShow] = useState(3);
  const isMobile = useIsMobile();
  
  const invoiceStats = useMemo(() => {
    if (!filteredFarmerData || filteredFarmerData.length === 0) {
      return {
        totalInvoice: 0,
        totalPaid: 0,
        totalPending: 0,
        avgDaysToPay: 0,
        pmksyDue: 0,
        bksyDue: 0,
        recentInvoices: []
      };
    }
    
    // Log the financial year filter being applied
    console.log(`InvoiceDashboard: Processing ${filteredFarmerData.length} farmers with financial year filter: ${selectedFinancialYear}`);
    
    // Filter farmers with invoice data
    const farmersWithInvoice = filteredFarmerData.filter(farmer => 
      farmer.taxInvNo && farmer.taxInvNo.trim() !== ''
    );
    
    // Filter farmers with payment data
    const farmersWithPayment = filteredFarmerData.filter(farmer => 
      farmer.paymentReference && farmer.paymentReference.trim() !== ''
    );
    
    // Calculate PMKSY due - farmers with PMKSY subsidy > 0 but PMKSY paid = 0
    const pmksyDue = filteredFarmerData.reduce((total, farmer) => {
      const hasPmksySubsidy = farmer.pmksySubsidy && parseFloat(farmer.pmksySubsidy) > 0;
      const hasNoPmksyPaid = !farmer.pmksyAmountPaid || parseFloat(farmer.pmksyAmountPaid) === 0;
      
      if (hasPmksySubsidy && hasNoPmksyPaid) {
        return total + parseFloat(farmer.pmksySubsidy);
      }
      return total;
    }, 0);
    
    // Calculate BKSY due - farmers with BKSY subsidy > 0 but BKSY paid = 0
    const bksyDue = filteredFarmerData.reduce((total, farmer) => {
      const hasBksySubsidy = farmer.bksySubsidy && parseFloat(farmer.bksySubsidy) > 0;
      const hasNoBksyPaid = !farmer.bksyAmountPaid || parseFloat(farmer.bksyAmountPaid) === 0;
      
      if (hasBksySubsidy && hasNoBksyPaid) {
        return total + parseFloat(farmer.bksySubsidy);
      }
      return total;
    }, 0);
    
    // Calculate average days to pay
    let totalDays = 0;
    let farmersWithBothDates = 0;
    
    farmersWithPayment.forEach(farmer => {
      const invoiceDate = farmer.billDate ? new Date(farmer.billDate) : null;
      const paymentDate = farmer.paymentDate ? new Date(farmer.paymentDate) : null;
      
      if (invoiceDate && paymentDate && invoiceDate < paymentDate) {
        const daysDiff = Math.round((paymentDate.getTime() - invoiceDate.getTime()) / (1000 * 60 * 60 * 24));
        totalDays += daysDiff;
        farmersWithBothDates++;
      }
    });
    
    const avgDaysToPay = farmersWithBothDates > 0 ? Math.round(totalDays / farmersWithBothDates) : 0;
    
    // Get recent invoices (all of them, we'll handle pagination in the component)
    const recentInvoices = [...farmersWithInvoice]
      .sort((a, b) => {
        const dateA = a.billDate ? new Date(a.billDate).getTime() : 0;
        const dateB = b.billDate ? new Date(b.billDate).getTime() : 0;
        return dateB - dateA;
      });
    
    return {
      totalInvoice: farmersWithInvoice.length,
      totalPaid: farmersWithPayment.length,
      totalPending: farmersWithInvoice.length - farmersWithPayment.length,
      avgDaysToPay,
      pmksyDue,
      bksyDue,
      recentInvoices
    };
  }, [filteredFarmerData, selectedFinancialYear]);
  
  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    }).format(amount);
  };
  
  const formatDate = (dateString: string | undefined) => {
    if (!dateString) return 'N/A';
    
    try {
      const date = new Date(dateString);
      return date.toLocaleDateString('en-IN', {
        day: '2-digit',
        month: 'short', 
        year: 'numeric'
      });
    } catch (e) {
      return dateString;
    }
  };
  
  const getTimeAgo = (dateString: string | undefined) => {
    if (!dateString) return '';
    
    try {
      const date = new Date(dateString);
      return formatDistance(date, new Date(), { addSuffix: true });
    } catch (e) {
      return '';
    }
  };
  
  const handleLoadMore = () => {
    setBillsToShow(prevCount => prevCount + 5);
  };
  
  if (loading) {
    return (
      <div className="bg-white rounded-lg shadow-sm p-4 md:p-6 flex justify-center items-center h-64">
        <Loader className="h-8 w-8 text-sidebar-primary animate-spin" />
      </div>
    );
  }
  
  return (
    <div className="bg-white rounded-lg shadow-sm p-4 md:p-6">
      <h2 className="text-lg md:text-xl font-semibold mb-4 text-left">
        Invoice Dashboard
        {selectedFinancialYear !== 'All Years' && (
          <span className="ml-2 text-sm font-normal text-gray-500">
            {selectedFinancialYear}
          </span>
        )}
      </h2>
      
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-gradient-to-r from-sidebar-accent/20 to-sidebar-accent/40 p-4 rounded-lg">
          <div className="flex justify-between items-start">
            <div>
              <div className="text-sm text-gray-500 mb-1 text-left">Total Invoices</div>
              <div className="text-xl md:text-2xl font-bold text-left">{invoiceStats.totalInvoice}</div>
            </div>
            <div className="bg-white p-2 rounded-full shadow-sm">
              <FileText className="h-5 w-5 text-sidebar-primary" />
            </div>
          </div>
          <div className="mt-2 flex justify-between text-xs">
            <span className="text-status-joint-inspection">{invoiceStats.totalPaid} Paid</span>
            <span className="text-status-new-registration">{invoiceStats.totalPending} Pending</span>
          </div>
        </div>
        
        <div className="bg-gradient-to-r from-status-install-inspected/10 to-status-install-inspected/20 p-4 rounded-lg">
          <div className="flex justify-between items-start">
            <div>
              <div className="text-sm text-gray-500 mb-1 text-left">Avg. Days to Pay</div>
              <div className="text-xl md:text-2xl font-bold text-left">{invoiceStats.avgDaysToPay}</div>
            </div>
            <div className="bg-white p-2 rounded-full shadow-sm">
              <Calendar className="h-5 w-5 text-status-install-inspected" />
            </div>
          </div>
          <div className="mt-3 text-xs text-gray-500">
            Based on {invoiceStats.totalPaid} paid invoices
          </div>
        </div>
        
        <div className="bg-gradient-to-r from-status-new-registration/20 to-status-new-registration/30 p-4 rounded-lg">
          <div className="flex justify-between items-start">
            <div>
              <div className="text-sm text-gray-500 mb-1 text-left">PMKSY Due</div>
              <div className="text-xl md:text-2xl font-bold text-left">{formatCurrency(invoiceStats.pmksyDue)}</div>
            </div>
            <div className="bg-white p-2 rounded-full shadow-sm">
              <IndianRupee className="h-5 w-5 text-status-new-registration" />
            </div>
          </div>
          <div className="mt-3 text-xs text-gray-500">
            Farmers with subsidy but no payment
          </div>
        </div>
        
        <div className="bg-gradient-to-r from-status-work-order/10 to-status-work-order/20 p-4 rounded-lg">
          <div className="flex justify-between items-start">
            <div>
              <div className="text-sm text-gray-500 mb-1 text-left">BKSY Due</div>
              <div className="text-xl md:text-2xl font-bold text-left">{formatCurrency(invoiceStats.bksyDue)}</div>
            </div>
            <div className="bg-white p-2 rounded-full shadow-sm">
              <IndianRupee className="h-5 w-5 text-status-work-order" />
            </div>
          </div>
          <div className="mt-3 text-xs text-gray-500">
            Farmers with subsidy but no payment
          </div>
        </div>
      </div>
      
      <div className="mt-6 text-left">
        <h3 className="text-md font-medium mb-3">Recent Invoices</h3>
        
        {invoiceStats.recentInvoices.length > 0 ? (
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Invoice
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Farmer
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Block
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Date
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Amount
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Status
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {invoiceStats.recentInvoices.slice(0, billsToShow).map((invoice, index) => (
                  <tr key={index} className={index % 2 === 0 ? 'bg-white' : 'bg-gray-50'}>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                      {invoice.taxInvNo || 'N/A'}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {invoice.beneficiaryName}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {invoice.blockName || 'N/A'}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      <div>{formatDate(invoice.billDate)}</div>
                      <div className="text-xs text-gray-400">{getTimeAgo(invoice.billDate)}</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {invoice.totalAmount ? formatCurrency(parseFloat(invoice.totalAmount)) : 'N/A'}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                        invoice.paymentReference ? 'bg-status-joint-inspection/30 text-green-800' : 'bg-status-new-registration/30 text-yellow-800'
                      }`}>
                        {invoice.paymentReference ? 'Paid' : 'Pending'}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
            
            {billsToShow < invoiceStats.recentInvoices.length && (
              <div className="text-center mt-4">
                <Button 
                  variant="outline"
                  onClick={handleLoadMore}
                  className="text-sidebar-primary border-sidebar-primary/30 hover:bg-sidebar-primary/10"
                >
                  Show More
                </Button>
              </div>
            )}
          </div>
        ) : (
          <div className="text-center py-8 text-gray-500">
            No recent invoices found
          </div>
        )}
      </div>
    </div>
  );
};

export default InvoiceDashboard;
