
import React, { useState, useMemo } from 'react';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Download, ChevronDown, ChevronUp, FileText } from 'lucide-react';
import { Badge } from "@/components/ui/badge";
import { formatToDisplayDate, formatToMonthYear, getSortedMonthsInRange } from '../utils/dateUtils';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

interface MonthlyInvoiceSummaryProps {
  farmerData: any[];
  selectedFinancialYear?: string;
}

const MonthlyInvoiceSummary: React.FC<MonthlyInvoiceSummaryProps> = ({
  farmerData,
  selectedFinancialYear = 'All'
}) => {
  const [selectedMonth, setSelectedMonth] = useState<string | null>(null);
  const [expandedDistricts, setExpandedDistricts] = useState<string[]>([]);
  const [activeTab, setActiveTab] = useState<string>("not-uploaded");

  // We'll use all farmer data now that we've removed financial year filtering
  const filteredByYear = useMemo(() => {
    return farmerData;
  }, [farmerData]);

  const notUploadedFarmers = useMemo(() => {
    return filteredByYear.filter(farmer => farmer.taxInvNo && farmer.docUploadStatus !== 'Uploaded');
  }, [filteredByYear]);

  const inspFileMissingFarmers = useMemo(() => {
    return filteredByYear.filter(farmer => farmer.taxInvNo && farmer.docUploadStatus === 'Insp. File Missing');
  }, [filteredByYear]);

  const currentFarmers = useMemo(() => {
    if (activeTab === "inspection-missing") {
      return inspFileMissingFarmers;
    }
    return notUploadedFarmers;
  }, [activeTab, notUploadedFarmers, inspFileMissingFarmers]);

  const districts = useMemo(() => {
    const districtSet = new Set<string>();
    currentFarmers.forEach(farmer => {
      if (farmer.districtName) {
        districtSet.add(farmer.districtName);
      }
    });
    return Array.from(districtSet).sort();
  }, [currentFarmers]);

  const months = useMemo(() => {
    return getSortedMonthsInRange(currentFarmers);
  }, [currentFarmers]);

  const summaryData = useMemo(() => {
    const data: Record<string, Record<string, number>> = {};
    districts.forEach(district => {
      data[district] = {};
      months.forEach(month => {
        data[district][month] = 0;
      });
    });
    currentFarmers.forEach(farmer => {
      if (farmer.districtName && farmer.paymentDate) {
        const monthYear = formatToMonthYear(farmer.paymentDate);
        if (months.includes(monthYear)) {
          data[farmer.districtName][monthYear] = (data[farmer.districtName][monthYear] || 0) + 1;
        }
      }
    });
    return data;
  }, [districts, months, currentFarmers]);

  const districtTotals = useMemo(() => {
    const totals: Record<string, number> = {};
    districts.forEach(district => {
      totals[district] = months.reduce((sum, month) => {
        return sum + (summaryData[district][month] || 0);
      }, 0);
    });
    return totals;
  }, [districts, months, summaryData]);

  const monthTotals = useMemo(() => {
    const totals: Record<string, number> = {};
    months.forEach(month => {
      totals[month] = districts.reduce((sum, district) => {
        return sum + (summaryData[district][month] || 0);
      }, 0);
    });
    return totals;
  }, [districts, months, summaryData]);

  const grandTotal = useMemo(() => {
    return districts.reduce((sum, district) => {
      return sum + districtTotals[district];
    }, 0);
  }, [districts, districtTotals]);

  const selectedMonthFarmers = useMemo(() => {
    if (!selectedMonth) return [];
    return currentFarmers.filter(farmer => {
      const monthYear = formatToMonthYear(farmer.paymentDate);
      return monthYear === selectedMonth;
    }).sort((a, b) => {
      return a.districtName.localeCompare(b.districtName) || a.beneficiaryName.localeCompare(b.beneficiaryName);
    });
  }, [selectedMonth, currentFarmers]);

  const handleMonthClick = (month: string) => {
    setSelectedMonth(month === selectedMonth ? null : month);
  };

  const toggleDistrictExpansion = (district: string) => {
    setExpandedDistricts(prev => prev.includes(district) ? prev.filter(d => d !== district) : [...prev, district]);
  };

  const exportToCSV = (data: any[], filename: string) => {
    const headers = ['Name', 'District', 'Payment Date', 'Tax Invoice No.', 'Current Status'].join(',');
    const rows = data.map(farmer => [`"${farmer.beneficiaryName || ''}"`, `"${farmer.districtName || ''}"`, `"${formatToDisplayDate(farmer.paymentDate) || ''}"`, `"${farmer.taxInvNo || ''}"`, `"${farmer.currentStatus || ''}"`].join(','));
    const csvContent = [headers, ...rows].join('\n');
    const blob = new Blob([csvContent], {
      type: 'text/csv;charset=utf-8;'
    });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `${filename}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const getTabTitle = () => {
    if (activeTab === "inspection-missing") {
      return "Inspection File Missing";
    }
    return "Invoiced but not Uploaded";
  };

  if (currentFarmers.length === 0) {
    return <Card>
        <CardHeader>
          <CardTitle>{getTabTitle()}</CardTitle>
          <CardDescription>
            Check if Beneficiary has Tax Inv. No.
          </CardDescription>
        </CardHeader>
        <CardContent className="text-center py-8">
          <FileText className="h-12 w-12 mx-auto text-gray-400 mb-3" />
          <p className="text-gray-600">No records found with the selected criteria</p>
        </CardContent>
      </Card>;
  }

  return <Card>
      <CardHeader>
        <CardTitle>{getTabTitle()}</CardTitle>
        <CardDescription>
          Beneficiaries with Tax Inv. No. but incomplete documentation
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="mb-4">
          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="not-uploaded">Not Uploaded</TabsTrigger>
              <TabsTrigger value="inspection-missing">Inspection Missing</TabsTrigger>
            </TabsList>
          </Tabs>
        </div>
        
        {currentFarmers.length > 0 && (
          <div className="overflow-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-1/3">District</TableHead>
                  {months.map(month => (
                    <TableHead key={month} className="text-center cursor-pointer" onClick={() => handleMonthClick(month)}>
                      {month} {selectedMonth === month && <ChevronDown className="inline h-4 w-4" />}
                    </TableHead>
                  ))}
                  <TableHead className="text-center">Total</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {districts.map(district => (
                  <TableRow key={district} className="hover:bg-gray-50">
                    <TableCell 
                      className="font-medium cursor-pointer" 
                      onClick={() => toggleDistrictExpansion(district)}
                    >
                      <div className="flex items-center">
                        {expandedDistricts.includes(district) ? 
                          <ChevronDown className="h-4 w-4 mr-1" /> : 
                          <ChevronUp className="h-4 w-4 mr-1" />
                        }
                        {district}
                      </div>
                    </TableCell>
                    {months.map(month => (
                      <TableCell key={`${district}-${month}`} className="text-center">
                        {summaryData[district][month] > 0 ? (
                          <Badge 
                            variant="outline" 
                            className="cursor-pointer hover:bg-blue-50"
                            onClick={() => handleMonthClick(month)}
                          >
                            {summaryData[district][month]}
                          </Badge>
                        ) : "0"}
                      </TableCell>
                    ))}
                    <TableCell className="text-center font-bold">
                      {districtTotals[district]}
                    </TableCell>
                  </TableRow>
                ))}
                <TableRow className="bg-gray-50 font-bold">
                  <TableCell>Total</TableCell>
                  {months.map(month => (
                    <TableCell key={`total-${month}`} className="text-center">
                      {monthTotals[month]}
                    </TableCell>
                  ))}
                  <TableCell className="text-center">{grandTotal}</TableCell>
                </TableRow>
              </TableBody>
            </Table>
          </div>
        )}
        
        {selectedMonth && selectedMonthFarmers.length > 0 && (
          <div className="mt-6">
            <div className="flex items-center justify-between mb-3">
              <h3 className="font-semibold text-lg">
                Beneficiaries for {selectedMonth} 
                <span className="ml-2 text-sm font-normal text-gray-500">
                  ({selectedMonthFarmers.length} records)
                </span>
              </h3>
              <TooltipProvider>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <Button
                      size="sm"
                      variant="outline"
                      className="flex items-center"
                      onClick={() => exportToCSV(selectedMonthFarmers, `${getTabTitle()}-${selectedMonth}`)}
                    >
                      <Download className="h-4 w-4 mr-1" />
                      Export
                    </Button>
                  </TooltipTrigger>
                  <TooltipContent>
                    <p>Export this list as CSV</p>
                  </TooltipContent>
                </Tooltip>
              </TooltipProvider>
            </div>
            
            <div className="overflow-auto max-h-64 border rounded">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Name</TableHead>
                    <TableHead>District</TableHead>
                    <TableHead>Payment Date</TableHead>
                    <TableHead>Tax Invoice No.</TableHead>
                    <TableHead>Current Status</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {selectedMonthFarmers.map((farmer, idx) => (
                    <TableRow key={idx}>
                      <TableCell className="font-medium">{farmer.beneficiaryName}</TableCell>
                      <TableCell>{farmer.districtName}</TableCell>
                      <TableCell>{formatToDisplayDate(farmer.paymentDate)}</TableCell>
                      <TableCell>{farmer.taxInvNo}</TableCell>
                      <TableCell>{farmer.currentStatus}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </div>
        )}
      </CardContent>
    </Card>;
};

export default MonthlyInvoiceSummary;
