import React from 'react';
import { Link } from 'react-router-dom';
import { Facebook, Instagram, Twitter, Github, Code } from 'lucide-react';
import logoImage from '../assets/logo.png';

const Footer = () => {
  const currentYear = new Date().getFullYear();
  
  return (
    <footer className="bg-[#F3F4F6] text-gray-600 w-full py-4 mt-auto">
      <div className="max-w-7xl mx-auto px-4">
        <div className="flex flex-col md:flex-row items-center justify-between gap-4">
          {/* PMKSY and BKSY Links - Now on left */}
          <div className="flex space-x-4 text-sm order-1 md:order-1">
            <a href="https://pmksy.gov.in/" target="_blank" rel="noopener noreferrer" className="text-gray-600 hover:text-gray-800 transition-colors">
              PMKSY
            </a>
            <a href="https://pmksy.gov.in/microirrigation/" target="_blank" rel="noopener noreferrer" className="text-gray-600 hover:text-gray-800 transition-colors">
              BKSY
            </a>
          </div>
          
          {/* Logo & Copyright - Now in center */}
          <div className="flex items-center space-x-2 order-2 md:order-2 mx-auto md:mx-0">
            <span className="text-sm">
              © {currentYear} Portal
            </span>
          </div>
          
          {/* Social Media Links - Keep on right */}
          <div className="flex items-center space-x-3 order-3 md:order-3">
            <a href="https://facebook.com/agritech-solutions" target="_blank" rel="noopener noreferrer" className="bg-gray-200/50 p-1.5 rounded-full hover:bg-gray-300 transition-colors" aria-label="Facebook">
              <Facebook className="h-4 w-4" />
            </a>
            <a href="https://instagram.com/agritech-solutions" target="_blank" rel="noopener noreferrer" className="bg-gray-200/50 p-1.5 rounded-full hover:bg-gray-300 transition-colors" aria-label="Instagram">
              <Instagram className="h-4 w-4" />
            </a>
            <a href="https://twitter.com/agritech-solutions" target="_blank" rel="noopener noreferrer" className="bg-gray-200/50 p-1.5 rounded-full hover:bg-gray-300 transition-colors" aria-label="Twitter">
              <Twitter className="h-4 w-4" />
            </a>
            <a href="https://github.com/agritech-solutions" target="_blank" rel="noopener noreferrer" className="bg-gray-200/50 p-1.5 rounded-full hover:bg-gray-300 transition-colors" aria-label="GitHub">
              <Github className="h-4 w-4" />
            </a>
            <Link to="/developer-portfolio" className="bg-gray-200/50 p-1.5 rounded-full hover:bg-gray-300 transition-colors" aria-label="Developer Portfolio">
              <Code className="h-4 w-4" />
            </Link>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
