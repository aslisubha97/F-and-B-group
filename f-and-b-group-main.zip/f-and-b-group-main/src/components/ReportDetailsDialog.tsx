
import React from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import {
  Drawer,
  DrawerContent,
  DrawerHeader,
  DrawerTitle,
  DrawerDescription
} from "@/components/ui/drawer";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Download } from 'lucide-react';
import { formatToDisplayDate } from '../utils/dateUtils';
import { useIsMobile } from '@/hooks/use-mobile';
import { ScrollArea } from '@/components/ui/scroll-area';

interface BillData {
  count: number;
  amount: number;
  date: string;
}

interface IrrigationTypeData {
  count: number;
  amount: number;
}

interface ReportDetailsDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  title: string;
  description: string;
  farmers: any[];
  schemeType: 'pmksy' | 'bksy';
  onExport: () => void;
}

const ReportDetailsDialog = ({
  open,
  onOpenChange,
  title,
  description,
  farmers,
  schemeType,
  onExport
}: ReportDetailsDialogProps) => {
  const isMobile = useIsMobile();
  
  // Find the appropriate payment field based on scheme type
  const getPaymentField = (farmer: any): string => {
    if (schemeType === 'pmksy') {
      return farmer.pmksyAmountPaid || '0';
    } else {
      return farmer.bksyAmountPaid || '0';
    }
  };
  
  // Calculate total amount by iterating through each farmer and getting the correct payment field
  const totalAmount = farmers.reduce((sum, farmer) => {
    const amount = parseFloat(getPaymentField(farmer));
    return sum + (isNaN(amount) ? 0 : amount);
  }, 0);

  const totalFarmers = farmers.length;
  
  // Group farmers by irrigation type
  const byIrrigationType = farmers.reduce((acc, farmer) => {
    const type = farmer.irrigationType || 'Unknown';
    if (!acc[type]) {
      acc[type] = {
        count: 0,
        amount: 0
      };
    }
    
    acc[type].count++;
    const amount = parseFloat(getPaymentField(farmer));
    acc[type].amount += isNaN(amount) ? 0 : amount;
    
    return acc;
  }, {} as Record<string, IrrigationTypeData>);
  
  // Group farmers by bill number
  const byBillNumber = farmers.reduce((acc, farmer) => {
    const billNo = farmer.billNo || 'Unknown';
    if (!acc[billNo]) {
      acc[billNo] = {
        count: 0,
        amount: 0,
        date: farmer.billDate || 'N/A'
      };
    }
    
    acc[billNo].count++;
    const amount = parseFloat(getPaymentField(farmer));
    acc[billNo].amount += isNaN(amount) ? 0 : amount;
    
    return acc;
  }, {} as Record<string, BillData>);

  const renderContent = () => (
    <div className="mt-4 space-y-6">
      <div className="bg-gray-50 p-4 rounded-lg">
        <h3 className="text-sm font-semibold mb-2">Summary</h3>
        <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
          <div className="bg-white p-3 rounded shadow-sm">
            <div className="text-xs text-gray-500">Total Farmers</div>
            <div className="text-lg font-semibold">{totalFarmers}</div>
          </div>
          <div className="bg-white p-3 rounded shadow-sm">
            <div className="text-xs text-gray-500">Total Amount</div>
            <div className="text-lg font-semibold">₹ {totalAmount.toLocaleString('en-IN')}</div>
          </div>
          <div className="bg-white p-3 rounded shadow-sm">
            <div className="text-xs text-gray-500">Average per Farmer</div>
            <div className="text-lg font-semibold">
              ₹ {(totalAmount / totalFarmers || 0).toLocaleString('en-IN', {maximumFractionDigits: 2})}
            </div>
          </div>
        </div>
      </div>
      
      <div>
        <div className="flex justify-between items-center mb-2">
          <h3 className="text-sm font-semibold">Payment by Bill Number</h3>
          <Button 
            variant="outline" 
            size="sm" 
            onClick={onExport} 
            className="text-emerald-700 hover:text-emerald-800 hover:bg-emerald-50"
          >
            <Download className="h-3 w-3 mr-1" />
            Export All Data
          </Button>
        </div>
        
        <div className="overflow-x-auto">
          <ScrollArea className="h-[30vh] md:h-[250px]">
            <Table>
              <TableHeader className="bg-gray-50">
                <TableRow>
                  <TableHead>Bill No.</TableHead>
                  <TableHead>Bill Date</TableHead>
                  <TableHead>Farmers Count</TableHead>
                  <TableHead>Total Amount</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {Object.entries(byBillNumber).map(([billNo, data]: [string, BillData]) => (
                  <TableRow key={billNo}>
                    <TableCell className="font-medium">{billNo}</TableCell>
                    <TableCell>{formatToDisplayDate(data.date)}</TableCell>
                    <TableCell>{data.count}</TableCell>
                    <TableCell>₹ {data.amount.toLocaleString('en-IN')}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </ScrollArea>
        </div>
      </div>
      
      <div>
        <h3 className="text-sm font-semibold mb-2">Payment by Irrigation Type</h3>
        <div className="overflow-x-auto">
          <ScrollArea className="h-[30vh] md:h-[200px]">
            <Table>
              <TableHeader className="bg-gray-50">
                <TableRow>
                  <TableHead>Irrigation Type</TableHead>
                  <TableHead>Farmers Count</TableHead>
                  <TableHead>Total Amount</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {Object.entries(byIrrigationType)
                  .sort((a: [string, IrrigationTypeData], b: [string, IrrigationTypeData]) => b[1].amount - a[1].amount)
                  .map(([type, data]: [string, IrrigationTypeData]) => (
                  <TableRow key={type}>
                    <TableCell className="font-medium">{type}</TableCell>
                    <TableCell>{data.count}</TableCell>
                    <TableCell>₹ {data.amount.toLocaleString('en-IN')}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </ScrollArea>
        </div>
      </div>
    </div>
  );

  return isMobile ? (
    <Drawer open={open} onOpenChange={onOpenChange}>
      <DrawerContent className="h-[90vh] overflow-y-auto pt-10">
        <DrawerHeader className="pb-4">
          <DrawerTitle>{title}</DrawerTitle>
          <DrawerDescription>{description}</DrawerDescription>
        </DrawerHeader>
        <div className="px-4 pb-8">
          {renderContent()}
        </div>
      </DrawerContent>
    </Drawer>
  ) : (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-6xl max-h-[80vh] overflow-y-auto bg-white">
        <DialogHeader>
          <DialogTitle>{title}</DialogTitle>
          <DialogDescription>
            {description}
          </DialogDescription>
        </DialogHeader>
        {renderContent()}
      </DialogContent>
    </Dialog>
  );
};

export default ReportDetailsDialog;
