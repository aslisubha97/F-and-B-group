
import React, { useState, useEffect } from 'react';
import { useAppContext, FarmerData } from '../context/AppContext';
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { Search, User, MapPin, Phone, DropletIcon, Users, FileText, CalendarClock, BadgeDollarSign } from 'lucide-react';
import { Card, CardContent, CardHeader } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { formatToDisplayDate } from '../utils/dateUtils';
import { Separator } from '@/components/ui/separator';

const SearchableFarmers = () => {
  const { filteredFarmerData, selectedFinancialYear } = useAppContext();
  const [searchTerm, setSearchTerm] = useState('');
  const [filteredFarmers, setFilteredFarmers] = useState<FarmerData[]>([]);
  const [searchField, setSearchField] = useState('all');

  // Perform search when searchTerm or filters change
  useEffect(() => {
    if (!searchTerm.trim()) {
      setFilteredFarmers([]);
      return;
    }

    const lowercaseSearch = searchTerm.toLowerCase();
    
    // Use filteredFarmerData which respects the financial year filter
    let results = filteredFarmerData;
    console.log(`SearchableFarmers: Searching within ${filteredFarmerData.length} records (Financial Year: ${selectedFinancialYear})`);
    
    // Regular search based on selected field
    results = results.filter(farmer => {
      switch(searchField) {
        case 'name':
          return farmer.beneficiaryName && farmer.beneficiaryName.toLowerCase().includes(lowercaseSearch);
        case 'registration':
          return farmer.farmerRegistrationNumber && farmer.farmerRegistrationNumber.toLowerCase().includes(lowercaseSearch);
        case 'mobile':
          return (farmer.mobileNo && farmer.mobileNo.toLowerCase().includes(lowercaseSearch)) || 
                (farmer.mobileNumber && farmer.mobileNumber.toLowerCase().includes(lowercaseSearch));
        case 'bill':
          return farmer.billNo && farmer.billNo.toLowerCase().includes(lowercaseSearch);
        case 'block':
          return farmer.blockName && farmer.blockName.toLowerCase().includes(lowercaseSearch);
        case 'all':
        default:
          return (
            (farmer.beneficiaryName && farmer.beneficiaryName.toLowerCase().includes(lowercaseSearch)) ||
            (farmer.farmerRegistrationNumber && farmer.farmerRegistrationNumber.toLowerCase().includes(lowercaseSearch)) ||
            (farmer.mobileNo && farmer.mobileNo.toLowerCase().includes(lowercaseSearch)) ||
            (farmer.mobileNumber && farmer.mobileNumber.toLowerCase().includes(lowercaseSearch)) ||
            (farmer.billNo && farmer.billNo.toLowerCase().includes(lowercaseSearch)) ||
            (farmer.blockName && farmer.blockName.toLowerCase().includes(lowercaseSearch))
          );
      }
    });
    
    setFilteredFarmers(results);
  }, [searchTerm, filteredFarmerData, searchField, selectedFinancialYear]);

  // Get the appropriate status color
  const getStatusColor = (status: string | undefined) => {
    if (!status) return 'bg-gray-100 text-gray-800';
    
    const statusLower = status.toLowerCase();
    if (statusLower.includes('new registration')) return 'bg-blue-100 text-blue-800';
    if (statusLower.includes('joint inspection')) return 'bg-purple-100 text-purple-800';
    if (statusLower.includes('work order')) return 'bg-amber-100 text-amber-800';
    if (statusLower.includes('install') && statusLower.includes('inspect')) return 'bg-pink-100 text-pink-800';
    if (statusLower.includes('install')) return 'bg-emerald-100 text-emerald-800';
    return 'bg-gray-100 text-gray-800';
  };

  return (
    <div className="space-y-4">
      <div className="flex flex-col md:flex-row gap-4 items-start">
        <div className="w-full md:w-1/2 relative">
          <Search className="absolute left-3 top-2.5 h-4 w-4 text-gray-400" />
          <Input
            type="text"
            placeholder="Search farmers..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-9"
          />
        </div>
        
        <div className="w-full md:w-1/4">
          <Select value={searchField} onValueChange={setSearchField}>
            <SelectTrigger className="w-full">
              <SelectValue placeholder="All Fields" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Fields</SelectItem>
              <SelectItem value="name">Name</SelectItem>
              <SelectItem value="registration">Registration No.</SelectItem>
              <SelectItem value="mobile">Mobile Number</SelectItem>
              <SelectItem value="bill">Bill Number</SelectItem>
              <SelectItem value="block">Block</SelectItem>
            </SelectContent>
          </Select>
        </div>
        
        <Button 
          onClick={() => setSearchTerm('')} 
          variant="outline" 
          className="md:mt-0"
          disabled={!searchTerm}
        >
          Clear
        </Button>
      </div>

      {/* Display results */}
      {searchTerm.trim() && (
        <div>
          <h3 className="text-lg font-medium mb-3">Search Results ({filteredFarmers.length})</h3>
          
          {filteredFarmers.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {filteredFarmers.slice(0, 30).map((farmer, index) => (
                <Card key={index} className="overflow-hidden hover:shadow-md transition-shadow border-l-4 border-l-emerald-500">
                  <CardHeader className="p-4 pb-2 flex flex-row items-center gap-3">
                    <div className="h-12 w-12 bg-emerald-100 rounded-full flex items-center justify-center text-emerald-600 flex-shrink-0">
                      <User size={20} />
                    </div>
                    <div className="flex flex-col">
                      <h4 className="font-semibold text-base line-clamp-1">{farmer.beneficiaryName || "N/A"}</h4>
                      <p className="text-sm text-gray-500">{farmer.farmerRegistrationNumber}</p>
                    </div>
                  </CardHeader>
                  
                  <CardContent className="p-4 pt-2">
                    <div className="grid grid-cols-1 gap-2 mt-2">
                      <div className="flex items-start gap-2">
                        <MapPin size={16} className="text-gray-500 flex-shrink-0 mt-0.5" />
                        <div className="text-sm">
                          <span className="font-medium">{farmer.blockName || 'N/A'}</span>
                          <div className="text-xs text-gray-500">
                            {farmer.gramPanchayet && <span>GP: {farmer.gramPanchayet}</span>}
                            {farmer.mouzaName && <span> • {farmer.mouzaName}</span>}
                          </div>
                        </div>
                      </div>

                      <div className="flex items-center gap-2">
                        <Phone size={16} className="text-gray-500 flex-shrink-0" />
                        <span className="text-sm">{farmer.mobileNo || farmer.mobileNumber || 'N/A'}</span>
                      </div>

                      <div className="flex items-center gap-2">
                        <DropletIcon size={16} className="text-gray-500 flex-shrink-0" />
                        <span className="text-sm">{farmer.irrigationType || 'N/A'}</span>
                      </div>

                      <div className="flex items-center gap-2">
                        <Users size={16} className="text-gray-500 flex-shrink-0" />
                        <span className="text-sm">{farmer.farmerCategory || 'General'}</span>
                      </div>

                      <Separator className="my-1" />

                      {farmer.installDate && (
                        <div className="flex items-center gap-2">
                          <CalendarClock size={16} className="text-gray-500 flex-shrink-0" />
                          <div className="text-sm">
                            <span className="text-xs text-gray-500">Installation Date:</span>
                            <div>{formatToDisplayDate(farmer.installDate)}</div>
                          </div>
                        </div>
                      )}

                      <div className="flex items-center justify-between gap-2 mt-1">
                        <div className="flex flex-col">
                          <span className="text-xs text-gray-500">PMKSY</span>
                          <span className="font-medium text-sm">{farmer.pmksyAmount ? `₹${farmer.pmksyAmount}` : 'N/A'}</span>
                        </div>
                        <div className="flex flex-col">
                          <span className="text-xs text-gray-500">BKSY</span>
                          <span className="font-medium text-sm">{farmer.bksyAmount ? `₹${farmer.bksyAmount}` : 'N/A'}</span>
                        </div>
                        {farmer.gstAmount && (
                          <div className="flex flex-col">
                            <span className="text-xs text-gray-500">GST</span>
                            <span className="font-medium text-sm">₹{farmer.gstAmount}</span>
                          </div>
                        )}
                      </div>

                      {/* Additional details */}
                      <div className="mt-2">
                        <div className="flex flex-wrap gap-1">
                          <Badge className={getStatusColor(farmer.currentStatus)}>
                            {farmer.currentStatus || 'Unknown'}
                          </Badge>
                          
                          {farmer.billNo && (
                            <Badge variant="outline" className="text-xs">
                              Bill: {farmer.billNo}
                            </Badge>
                          )}
                          
                          {farmer.taxInvNo && (
                            <Badge variant="outline" className="text-xs">
                              Inv: {farmer.taxInvNo}
                            </Badge>
                          )}
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : (
            <div className="bg-white p-8 text-center rounded-lg shadow">
              <p>No farmers found matching your search criteria</p>
            </div>
          )}
          
          {filteredFarmers.length > 30 && (
            <div className="text-center mt-4">
              <p className="text-sm text-gray-500">
                Showing 30 of {filteredFarmers.length} results
              </p>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default SearchableFarmers;
