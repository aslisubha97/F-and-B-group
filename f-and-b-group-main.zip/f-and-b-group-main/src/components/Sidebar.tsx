
import React, { useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Home, ExternalLink, LogIn, BarChart4, FileText, PieChart, CalendarDays } from 'lucide-react';
import { useAppContext } from '../context/AppContext';
import logoImage from '../assets/logo.png';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from '@/components/ui/use-toast';

const Sidebar = () => {
  const location = useLocation();
  const { setShowLoginModal, isLoggedIn, selectedFinancialYear, setSelectedFinancialYear, financialYears, refreshData } = useAppContext();

  // Use a common active class for all navigation items
  const getNavItemClass = (path: string) => {
    const isActive = location.pathname === path || 
                     (path !== '/' && location.pathname.includes(path));
    
    return `flex items-center p-3 md:p-3 rounded-lg transition-colors ${
      isActive 
        ? 'bg-emerald-600 text-white' 
        : 'text-gray-700 hover:bg-gray-100'
    }`;
  };

  // Handle financial year change
  const handleFinancialYearChange = (year: string) => {
    console.log(`Changing financial year to: ${year}`);
    
    // Display a toast notification about the filter change
    toast({
      title: `Financial Year: ${year}`,
      description: year === 'All Years' 
        ? 'Showing data from all financial years'
        : `Filtered to show data from ${year} only`,
      duration: 3000,
    });
    
    setSelectedFinancialYear(year);
  };

  // Refresh data when the component mounts to ensure data is properly initialized
  useEffect(() => {
    // Ensure we have the latest data with the financial year filter applied
    if (financialYears.length === 0) {
      refreshData();
    }
  }, []);

  return (
    <div className="bg-white h-screen overflow-y-auto p-4 flex flex-col w-full">
      <div className="flex items-center justify-center mb-6 mt-2">
        <img src={logoImage} alt="PMKSY-BKSY Logo" className="h-12 md:h-16" />
      </div>
      
      <div className="text-lg md:text-xl font-semibold text-center mb-4 text-gray-800">PMKSY-BKSY</div>
      
      {/* Financial Year selector */}
      <div className="mb-6 px-1">
        <div className="flex items-center gap-2 mb-1">
          <CalendarDays className="h-4 w-4 text-emerald-600" />
          <label className="block text-sm font-medium text-gray-700">Financial Year</label>
        </div>
        <Select 
          value={selectedFinancialYear} 
          onValueChange={handleFinancialYearChange}
        >
          <SelectTrigger className="w-full bg-gray-50 border border-gray-200 focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500">
            <SelectValue placeholder="Financial Year" />
          </SelectTrigger>
          <SelectContent>
            {['All Years', ...financialYears].map((year) => (
              <SelectItem key={year} value={year}>{year}</SelectItem>
            ))}
          </SelectContent>
        </Select>
        {selectedFinancialYear !== 'All Years' && (
          <p className="text-xs text-emerald-600 mt-1">
            Viewing data for {selectedFinancialYear}
          </p>
        )}
      </div>
      
      <nav className="space-y-2 flex-1">
        <Link 
          to="/" 
          className={getNavItemClass('/')}
        >
          <Home className="mr-3 h-5 w-5" />
          <span className="text-base">Dashboard</span>
        </Link>
        
        <Link 
          to="/finance" 
          className={getNavItemClass('/finance')}
        >
          <BarChart4 className="mr-3 h-5 w-5" />
          <span className="text-base">Finance</span>
        </Link>
        
        <Link 
          to="/invoice" 
          className={getNavItemClass('/invoice')}
        >
          <FileText className="mr-3 h-5 w-5" />
          <span className="text-base">Invoice</span>
        </Link>
        
        <Link 
          to="/farmers" 
          className={getNavItemClass('/farmers')}
        >
          <PieChart className="mr-3 h-5 w-5" />
          <span className="text-base">Analytics</span>
        </Link>
        
        <a 
          href="http://portal.microirrigation.site" 
          target="_blank" 
          rel="noopener noreferrer"
          className="flex items-center p-3 rounded-lg text-gray-700 hover:bg-gray-100 transition-colors"
        >
          <ExternalLink className="mr-3 h-5 w-5" />
          <span className="text-base">PIAL</span>
        </a>
        
        <a 
          href="http://portal.microirrigation.site/admin" 
          target="_blank" 
          rel="noopener noreferrer"
          className="flex items-center p-3 rounded-lg text-gray-700 hover:bg-gray-100 transition-colors"
        >
          <LogIn className="mr-3 h-5 w-5" />
          <span className="text-base">Admin Login</span>
        </a>
      </nav>
      
      <div className="mt-auto pt-4 text-xs text-center text-gray-500">
        © 2025 PMKSY-BKSY Portal
      </div>
    </div>
  );
};

export default Sidebar;
