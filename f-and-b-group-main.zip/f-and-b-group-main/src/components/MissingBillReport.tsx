
import React, { useMemo } from 'react';
import { useAppContext } from '../context/AppContext';
import { Download } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Drawer, DrawerContent, DrawerHeader, DrawerTitle } from '@/components/ui/drawer';
import { useIsMobile } from '@/hooks/use-mobile';
import { Table, TableHeader, TableBody, TableHead, TableRow, TableCell } from '@/components/ui/table';
import { ScrollArea } from '@/components/ui/scroll-area';

const MissingBillReport = ({
  isOpen,
  onClose
}) => {
  const {
    filteredFarmerData,
    selectedFinancialYear
  } = useAppContext();
  const isMobile = useIsMobile();

  // Filter farmers with "installed & inspected" status with payment reference but missing bill number
  const missingBillFarmers = useMemo(() => {
    // Log the financial year filter being applied
    console.log(`MissingBillReport: Filtering with financial year: ${selectedFinancialYear}`);
    
    return filteredFarmerData.filter(farmer => {
      const isInstalledAndInspected = farmer.currentStatus?.toLowerCase().includes('installed & inspected');
      const hasPaymentReference = !!farmer.paymentReference;
      const noBillNumber = !farmer.billNo || farmer.billNo.trim() === '';
      
      return isInstalledAndInspected && hasPaymentReference && noBillNumber;
    });
  }, [filteredFarmerData, selectedFinancialYear]);
  
  const exportToCSV = () => {
    const headers = ['Name', 'Registration Number', 'Mobile Number', 'Block', 'Gender', 'Category', 'Irrigation Type', 'Payment Reference', 'Financial Year'].join(',');
    const rows = missingBillFarmers.map(farmer => [
      `"${farmer.beneficiaryName || ''}"`, 
      `"${farmer.farmerRegistrationNumber || ''}"`, 
      `"${farmer.mobileNumber || farmer.mobileNo || ''}"`, 
      `"${farmer.blockName || ''}"`, 
      `"${farmer.sex || ''}"`, 
      `"${farmer.farmerCategory || ''}"`, 
      `"${farmer.irrigationType || ''}"`, 
      `"${farmer.paymentReference || ''}"`,
      `"${farmer.financialYear || ''}"`
    ].join(','));
    
    const csvContent = [headers, ...rows].join('\n');
    const blob = new Blob([csvContent], {
      type: 'text/csv;charset=utf-8;'
    });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    const yearSuffix = selectedFinancialYear !== 'All Years' ? `_${selectedFinancialYear}` : '';
    link.setAttribute('download', `missing_bill_farmers${yearSuffix}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };
  
  const renderContent = () => (
    <>
      <div className="flex justify-between items-center mb-4 flex-wrap gap-2">
        <div className="w-full md:w-auto">
          <p className="text-sm font-medium">
            Financial Year: <span className="font-semibold">{selectedFinancialYear}</span>
          </p>
        </div>
        
        {missingBillFarmers.length > 0 && (
          <Button onClick={exportToCSV} variant="outline" className="flex items-center gap-2">
            <Download className="h-4 w-4" />
            Export CSV
          </Button>
        )}
      </div>

      <div className="bg-white rounded-lg shadow-sm p-4 mb-6 overflow-hidden border px-[16px]">
        {missingBillFarmers.length > 0 ? (
          <ScrollArea className="h-[60vh] md:h-[500px]">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Name</TableHead>
                  <TableHead>Registration Number</TableHead>
                  <TableHead>Block</TableHead>
                  <TableHead>Financial Year</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {missingBillFarmers.map((farmer, index) => (
                  <TableRow key={index}>
                    <TableCell className="font-medium">{farmer.beneficiaryName || 'N/A'}</TableCell>
                    <TableCell>{farmer.farmerRegistrationNumber || 'N/A'}</TableCell>
                    <TableCell>{farmer.blockName || 'N/A'}</TableCell>
                    <TableCell>{farmer.financialYear || 'N/A'}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </ScrollArea>
        ) : (
          <div className="text-center py-10">
            <p className="text-gray-500">No farmers found with missing bill numbers{selectedFinancialYear !== 'All Years' ? ` in ${selectedFinancialYear}` : ''}.</p>
          </div>
        )}
        {missingBillFarmers.length > 0 && (
          <div className="mt-4 text-right">
            <span className="text-sm text-gray-500">Showing {missingBillFarmers.length} farmers</span>
          </div>
        )}
      </div>
    </>
  );
  
  return isMobile ? (
    <Drawer open={isOpen} onOpenChange={onClose}>
      <DrawerContent className="h-[90vh] overflow-y-auto pt-10">
        <DrawerHeader className="pb-4">
          <DrawerTitle>Missing Bill Numbers Report</DrawerTitle>
        </DrawerHeader>
        <div className="px-4 pb-8">
          {renderContent()}
        </div>
      </DrawerContent>
    </Drawer>
  ) : (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-7xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Missing Bill Numbers Report</DialogTitle>
        </DialogHeader>
        {renderContent()}
      </DialogContent>
    </Dialog>
  );
};

export default MissingBillReport;
