
import React, { useState, useMemo } from 'react';
import { useAppContext } from '../context/AppContext';
import { User, AlertTriangle, FileText, Download, BarChart as BarChartIcon, PieChart as PieChartIcon, Filter, Info } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useNavigate } from 'react-router-dom';
import { PieChart as RechartsPieChart, Pie, Cell, ResponsiveContainer, Tooltip, Legend, BarChart as RechartsBarChart, Bar, XAxis, YAxis, CartesianGrid } from 'recharts';
import { useIsMobile } from '@/hooks/use-mobile';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";

// Define status colors for consistency
const STATUS_COLORS = {
  'new registration': '#FCD34D',
  // Yellow
  'joint inspection': '#a0d5a1',
  // Green
  'work order': '#7DE3E1',
  // Teal
  'installed & inspected': '#f5abfc',
  // Pink/Purple
  'installed': '#93c2fd',
  // Blue
  'default': '#6B7280' // Gray
};

// Get status color based on status text
const getStatusColor = status => {
  const statusLower = status.toLowerCase();
  if (statusLower.includes('new registration')) return STATUS_COLORS['new registration'];
  if (statusLower.includes('joint inspection')) return STATUS_COLORS['joint inspection'];
  if (statusLower.includes('work order')) return STATUS_COLORS['work order'];
  if (statusLower.includes('installed') && statusLower.includes('inspected')) return STATUS_COLORS['installed & inspected'];
  if (statusLower.includes('installed') || statusLower.includes('install')) return STATUS_COLORS['installed'];
  return STATUS_COLORS['default'];
};

// Define components for various sections of the analytics page
const ChartCard = ({
  title,
  subtitle = "",
  data = [],
  renderChart,
  icon,
  height = "h-64"
}) => {
  return <Card className="shadow-sm hover:shadow-md transition-shadow">
      <CardHeader className="pb-2">
        <div className="flex justify-between items-center">
          <CardTitle className="text-lg font-medium flex items-center">
            {icon && React.cloneElement(icon, {
            className: "h-5 w-5 mr-2 text-emerald-600"
          })}
            {title}
          </CardTitle>
        </div>
        {subtitle && <CardDescription>{subtitle}</CardDescription>}
      </CardHeader>
      <CardContent className={`${height} pt-0`}>
        {renderChart()}
      </CardContent>
    </Card>;
};

const renderChartComponent = (data, chartType) => {
  if (!data || data.length === 0) {
    return <div className="flex flex-col items-center justify-center h-full">
        <PieChartIcon className="h-12 w-12 text-gray-300 mb-2" />
        <p className="text-gray-500">No data available</p>
      </div>;
  }
  if (chartType === 'pie') {
    return <ResponsiveContainer width="100%" height="100%">
        <RechartsPieChart>
          <Pie data={data} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={80} labelLine={false} label={({
          name,
          percent
        }) => `${name}: ${(percent * 100).toFixed(0)}%`}>
            {data.map((entry, index) => <Cell key={`cell-${index}`} fill={entry.color} stroke="#fff" strokeWidth={2} />)}
          </Pie>
          <Tooltip formatter={value => [`${value} farmers`, 'Count']} />
          <Legend verticalAlign="bottom" layout="horizontal" />
        </RechartsPieChart>
      </ResponsiveContainer>;
  } else {
    return <ResponsiveContainer width="100%" height="100%">
        <RechartsBarChart data={data} margin={{
        top: 5,
        right: 20,
        left: 20,
        bottom: 40
      }} barSize={chartType === 'horizontal' ? 15 : 30}>
          <CartesianGrid strokeDasharray="3 3" opacity={0.1} />
          <XAxis dataKey="name" angle={-45} textAnchor="end" height={60} tick={{
          fontSize: 12
        }} interval={0} />
          <YAxis />
          <Tooltip formatter={value => [`${value} farmers`, 'Count']} />
          <Bar dataKey="value" name="Number of Farmers" radius={[4, 4, 0, 0]}>
            {data.map((entry, index) => <Cell key={`cell-${index}`} fill={entry.color} />)}
          </Bar>
        </RechartsBarChart>
      </ResponsiveContainer>;
  }
};

// Component for Analytics Dashboard
const Farmers = () => {
  const navigate = useNavigate();
  const {
    farmerData,
    filteredFarmerData,
    isLoggedIn,
    setShowLoginModal,
    selectedFinancialYear
  } = useAppContext();
  const isMobile = useIsMobile();

  // State for tabs and filters
  const [activeTab, setActiveTab] = useState('overview');
  const [blockFilter, setBlockFilter] = useState('all');
  const [irrigationFilter, setIrrigationFilter] = useState('all');

  // Compute unique blocks and irrigation types for filters
  const blocks = useMemo(() => {
    const uniqueBlocks = Array.from(new Set(filteredFarmerData.map(farmer => farmer.blockName))).filter(Boolean).sort();
    return ['all', ...uniqueBlocks];
  }, [filteredFarmerData]);
  const irrigationTypes = useMemo(() => {
    const uniqueTypes = Array.from(new Set(filteredFarmerData.map(farmer => farmer.irrigationType))).filter(Boolean).sort();
    return ['all', ...uniqueTypes];
  }, [filteredFarmerData]);

  // Filter data based on current selections
  const displayData = useMemo(() => {
    return filteredFarmerData.filter(farmer => {
      const matchesBlock = blockFilter === 'all' || farmer.blockName === blockFilter;
      const matchesIrrigation = irrigationFilter === 'all' || farmer.irrigationType === irrigationFilter;
      return matchesBlock && matchesIrrigation;
    });
  }, [filteredFarmerData, blockFilter, irrigationFilter]);

  // Status count data for charts
  const statusData = useMemo(() => {
    const statusCounts = {};
    displayData.forEach(farmer => {
      const status = farmer.currentStatus || 'Unknown Status';
      statusCounts[status] = (statusCounts[status] || 0) + 1;
    });
    return Object.entries(statusCounts).map(([name, value]) => ({
      name: name.length > 20 ? name.substring(0, 20) + '...' : name,
      value: Number(value),
      color: getStatusColor(name)
    })).sort((a, b) => b.value - a.value);
  }, [displayData]);

  // District count data with consistent colors
  const districtData = useMemo(() => {
    const districtCounts = {};
    displayData.forEach(farmer => {
      const district = farmer.districtName || 'Unknown District';
      districtCounts[district] = (districtCounts[district] || 0) + 1;
    });
    const colors = ['#34D399', '#60A5FA', '#F472B6', '#FBBF24', '#A78BFA', '#FB7185', '#38BDF8'];
    return Object.entries(districtCounts).map(([name, value], index) => ({
      name,
      value: Number(value),
      color: colors[index % colors.length]
    })).sort((a, b) => b.value - a.value);
  }, [displayData]);

  // Block count data
  const blockData = useMemo(() => {
    const blockCounts = {};
    displayData.forEach(farmer => {
      const block = farmer.blockName || 'Unknown Block';
      blockCounts[block] = (blockCounts[block] || 0) + 1;
    });
    const colors = ['#4DD4AC', '#38BDF8', '#FB7185', '#FACC15', '#C084FC', '#F43F5E', '#0EA5E9', '#8B5CF6', '#F59E0B', '#EC4899'];
    return Object.entries(blockCounts).map(([name, value], index) => ({
      name,
      value: Number(value),
      color: colors[index % colors.length]
    })).sort((a, b) => b.value - a.value).slice(0, 10); // Take top 10
  }, [displayData]);

  // Irrigation type data
  const irrigationData = useMemo(() => {
    const typeCounts = {};
    displayData.forEach(farmer => {
      const type = farmer.irrigationType || 'Unknown Type';
      typeCounts[type] = (typeCounts[type] || 0) + 1;
    });
    const colors = ['#0EA5E9', '#10B981', '#F59E0B', '#8B5CF6', '#EC4899', '#6366F1', '#F97316'];
    return Object.entries(typeCounts).map(([name, value], index) => ({
      name: name.length > 15 ? name.substring(0, 15) + '...' : name,
      value: Number(value),
      color: colors[index % colors.length]
    }));
  }, [displayData]);

  // Gender distribution data
  const genderData = useMemo(() => {
    const maleCount = displayData.filter(farmer => farmer.sex?.toLowerCase() === 'male').length;
    const femaleCount = displayData.filter(farmer => farmer.sex?.toLowerCase() === 'female').length;
    const otherCount = displayData.length - maleCount - femaleCount;
    return [{
      name: 'Male',
      value: Number(maleCount),
      color: '#0369A1'
    }, {
      name: 'Female',
      value: Number(femaleCount),
      color: '#DB2777'
    }, {
      name: 'Not Specified',
      value: Number(otherCount),
      color: '#9CA3AF'
    }].filter(item => item.value > 0);
  }, [displayData]);

  // Export CSV data
  const handleExportCSV = () => {
    const headers = ['Name', 'Registration Number', 'Mobile Number', 'Block', 'District', 'Status', 'Irrigation Type'].join(',');
    const rows = displayData.map(farmer => [`"${farmer.beneficiaryName || ''}"`, `"${farmer.farmerRegistrationNumber || ''}"`, `"${farmer.mobileNumber || farmer.mobileNo || ''}"`, `"${farmer.blockName || ''}"`, `"${farmer.districtName || ''}"`, `"${farmer.currentStatus || ''}"`, `"${farmer.irrigationType || ''}"`].join(','));
    const csvContent = [headers, ...rows].join('\n');
    const blob = new Blob([csvContent], {
      type: 'text/csv;charset=utf-8;'
    });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `farmer_analysis_${selectedFinancialYear.replace(/\//g, '-')}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };
  return <div className="max-w-7xl mx-auto animate-fade-in">
      <div className="mb-4">
        <div className="flex flex-col md:flex-row gap-4 mb-4 items-end">
          <div className="w-full md:w-1/3">
            <label className="text-xs font-medium text-gray-500 mb-1 block">Block Filter</label>
            <Select value={blockFilter} onValueChange={setBlockFilter}>
              <SelectTrigger className="w-full">
                <SelectValue placeholder="Select Block" />
              </SelectTrigger>
              <SelectContent>
                {blocks.map(block => <SelectItem key={block} value={block}>
                    {block === 'all' ? 'All Blocks' : block}
                  </SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          
          <div className="w-full md:w-1/3">
            <label className="text-xs font-medium text-gray-500 mb-1 block">Irrigation Type</label>
            <Select value={irrigationFilter} onValueChange={setIrrigationFilter}>
              <SelectTrigger className="w-full">
                <SelectValue placeholder="Select Irrigation Type" />
              </SelectTrigger>
              <SelectContent>
                {irrigationTypes.map(type => <SelectItem key={type} value={type}>
                    {type === 'all' ? 'All Types' : type}
                  </SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          
          <Button variant="outline" size="sm" onClick={() => {
          setBlockFilter('all');
          setIrrigationFilter('all');
        }} className="mb-px">
            <Filter className="h-4 w-4 mr-1" />
            Clear Filters
          </Button>
        </div>
      </div>
      
      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full mb-6">
        <TabsList className="grid grid-cols-1 mb-6 w-full md:w-[200px]">
          <TabsTrigger value="overview">Overview</TabsTrigger>
        </TabsList>
        
        <TabsContent value="overview" className="animate-fadeIn space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
            <ChartCard title="Status Distribution" subtitle={`${statusData.length} different statuses`} data={statusData} renderChart={() => renderChartComponent(statusData, 'bar')} icon={<BarChartIcon />} height="h-80" />
            
            <ChartCard title="Gender Distribution" data={genderData} renderChart={() => renderChartComponent(genderData, 'pie')} icon={<PieChartIcon />} />
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
            <ChartCard title="Top 10 Blocks" subtitle="Blocks with most farmers" data={blockData} renderChart={() => renderChartComponent(blockData, 'bar')} icon={<BarChartIcon />} height="h-80" />
            
            <ChartCard title="Irrigation Type Distribution" subtitle={`${irrigationData.length} different types`} data={irrigationData} renderChart={() => renderChartComponent(irrigationData, 'bar')} icon={<PieChartIcon />} height="h-80" />
          </div>
          
          <ChartCard title="District Distribution" subtitle="Farmers by district" data={districtData} renderChart={() => renderChartComponent(districtData, 'bar')} icon={<BarChartIcon />} height="h-80" />
        </TabsContent>
      </Tabs>
    </div>;
};
export default Farmers;
