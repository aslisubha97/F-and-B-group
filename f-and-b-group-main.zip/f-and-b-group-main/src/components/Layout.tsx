
import React, { useState, useEffect } from 'react';
import Sidebar from './Sidebar';
import { useAppContext } from '../context/AppContext';
import LoginModal from './LoginModal';
import { Menu } from 'lucide-react';
import { useIsMobile } from '../hooks/use-mobile';
import { Button } from '@/components/ui/button';
import { useLocation, Link } from 'react-router-dom';
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet';
import logoImage from '../assets/logo.png';
import Footer from './Footer';

interface LayoutProps {
  children: React.ReactNode;
}

const Layout: React.FC<LayoutProps> = ({
  children
}) => {
  const {
    showLoginModal
  } = useAppContext();
  const isMobile = useIsMobile();
  const location = useLocation();
  const [sidebarOpen, setSidebarOpen] = useState(false);

  // Close sidebar on route change and scroll to top
  useEffect(() => {
    if (isMobile) {
      setSidebarOpen(false);
    }
    // Scroll to top on route change
    window.scrollTo(0, 0);
  }, [location.pathname, isMobile]);

  // Navigation items for desktop top nav
  const navItems = [{
    title: "Dashboard",
    path: "/"
  }, {
    title: "Finance",
    path: "/finance"
  }, {
    title: "Invoice",
    path: "/invoice"
  }, {
    title: "Analytics",
    path: "/farmers"
  }];
  
  const isActive = (path: string) => location.pathname === path || path !== '/' && location.pathname.startsWith(path);
  
  return <div className="flex flex-col min-h-screen bg-gray-100 w-full">
      {/* Header with hamburger menu and top navigation for desktop */}
      <header className="fixed top-0 left-0 right-0 h-14 z-40 bg-white border-b flex items-center px-4 shadow-sm">
        <div className="flex items-center justify-between w-full">
          <div className={`flex items-center ${isMobile ? 'w-full' : ''}`}>
            {isMobile ? (
              <>
                <Sheet open={sidebarOpen} onOpenChange={setSidebarOpen}>
                  <SheetTrigger asChild>
                    <Button variant="ghost" size="icon" className="mr-2">
                      <Menu className="h-5 w-5" />
                      <span className="sr-only">Toggle menu</span>
                    </Button>
                  </SheetTrigger>
                  <SheetContent side="left" className="p-0 w-[280px] sm:max-w-xs">
                    <Sidebar />
                  </SheetContent>
                </Sheet>
                
                <div className="flex justify-center items-center w-full">
                  <img src={logoImage} alt="PMKSY-BKSY Logo" className="h-8" />
                </div>
              </>
            ) : (
              <div className="flex items-center">
                <img src={logoImage} alt="PMKSY-BKSY Logo" className="h-8 mr-2" />
              </div>
            )}
          </div>

          {/* Desktop Navigation - shifted to the right */}
          <div className="hidden md:flex items-center space-x-6 py-0">
            {navItems.map(item => <Link key={item.path} to={item.path} className={`text-sm font-medium transition-colors py-2 ${isActive(item.path) ? 'text-emerald-600 border-b-2 border-emerald-600' : 'text-gray-600 hover:text-gray-900'}`}>
                {item.title}
              </Link>)}
            <div className="ml-4">
              <a href="http://portal.microirrigation.site" target="_blank" rel="noopener noreferrer" className="text-sm font-medium text-gray-600 hover:text-gray-900">
                PIAL
              </a>
            </div>
            <div>
              <a href="http://portal.microirrigation.site/admin" target="_blank" rel="noopener noreferrer" className="text-sm font-medium text-gray-600 hover:text-gray-900">
                Admin Login
              </a>
            </div>
          </div>
        </div>
      </header>
      
      {/* Main content - ensuring full width (removed max-w-full) */}
      <main className="flex-1 p-4 md:p-6 overflow-auto mt-14 w-full">
        {children}
      </main>
      
      {/* Footer */}
      <Footer />
      
      {showLoginModal && <LoginModal />}
    </div>;
};

export default Layout;
