import React, { useCallback, useState } from 'react';
import { useDropzone } from 'react-dropzone';
import { useAppContext } from '../context/AppContext';
import * as XLSX from 'xlsx';
import { UploadCloud, FileText, CheckCircle, AlertCircle, Loader } from 'lucide-react';
import { formatCsvData } from '../utils/formatCsvData';
import { toast } from '@/components/ui/use-toast';
import { supabase } from "@/integrations/supabase/client";
import { Progress } from "@/components/ui/progress";
import { FarmerData } from '../context/AppContext';
import { useNavigate } from 'react-router-dom';
import { Tables } from '@/integrations/supabase/types';
import { formatToISODate } from '../utils/dateUtils';

// Define a type for the farmer record based on the Supabase schema
type FarmerRecord = Tables<'farmers'>;
// Define a type for mandatory insert operation
type FarmerInsert = Required<Pick<FarmerRecord, 'beneficiary_name'>> & Partial<Omit<FarmerRecord, 'beneficiary_name'>>;
const BATCH_SIZE = 25; // Smaller batch size for better error handling and progress updates

// Define a type for invoice record fields
type InvoiceInsert = {
  farmer_id: string;
  [key: string]: any;
};
const CsvUpload = () => {
  const {
    setFarmerData,
    isLoggedIn,
    setShowLoginModal,
    setLoading,
    refreshData
  } = useAppContext();
  const [file, setFile] = useState<File | null>(null);
  const [uploadStatus, setUploadStatus] = useState<'idle' | 'uploading' | 'processing' | 'success' | 'error'>('idle');
  const [errorMessage, setErrorMessage] = useState<string>('');
  const [progress, setProgress] = useState<number>(0);
  const [uploadErrors, setUploadErrors] = useState<{
    farmer: string;
    error: string;
    row?: number;
  }[]>([]);
  const [uploadStats, setUploadStats] = useState<{
    parsed: number;
    inserted: number;
    failed: number;
    emptyNames: number;
  }>({
    parsed: 0,
    inserted: 0,
    failed: 0,
    emptyNames: 0
  });
  const navigate = useNavigate();
  const onDrop = useCallback((acceptedFiles: File[]) => {
    if (!isLoggedIn) {
      setShowLoginModal(true);
      return;
    }
    const file = acceptedFiles[0];
    if (!file) return;
    setFile(file);
    setUploadStatus('idle');
    setErrorMessage('');
    setProgress(0);
    setUploadErrors([]);
    setUploadStats({
      parsed: 0,
      inserted: 0,
      failed: 0,
      emptyNames: 0
    });
  }, [isLoggedIn, setShowLoginModal]);
  const {
    getRootProps,
    getInputProps,
    isDragActive
  } = useDropzone({
    onDrop,
    accept: {
      'text/csv': ['.csv'],
      'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet': ['.xlsx'],
      'application/vnd.ms-excel': ['.xls']
    },
    maxFiles: 1
  });
  const saveToSupabase = async (data: any[]) => {
    try {
      const totalRows = data.length;
      let processedRows = 0;
      let insertedRows = 0;
      let failedRows = 0;
      let emptyNameRows = 0;
      const errors: {
        farmer: string;
        error: string;
        row?: number;
      }[] = [];
      setProgress(5);

      // Check connection to Supabase first
      try {
        const {
          error: pingError
        } = await supabase.from('farmers').select('count').limit(1);
        if (pingError) {
          throw new Error(`Could not connect to database: ${pingError.message}`);
        }
      } catch (connectionError: any) {
        toast({
          title: 'Connection Error',
          description: 'Could not connect to the database. Please check your internet connection.',
          variant: 'destructive'
        });
        throw new Error(`Connection error: ${connectionError.message}`);
      }

      // First, clear existing data to prevent duplicates
      try {
        const {
          error: deleteError
        } = await supabase.from('farmers').delete().neq('id', '00000000-0000-0000-0000-000000000000');
        if (deleteError) {
          console.error("Error deleting existing farmer data:", deleteError);
          toast({
            title: 'Warning',
            description: 'Could not clear previous data. Proceeding with update.',
            variant: 'destructive'
          });
        }
        const {
          error: deleteInvoiceError
        } = await supabase.from('invoices').delete().neq('id', '00000000-0000-0000-0000-000000000000');
        if (deleteInvoiceError) {
          console.error("Error deleting existing invoice data:", deleteInvoiceError);
        }
      } catch (deleteError: any) {
        console.error("Error during delete operation:", deleteError);
        toast({
          title: 'Warning',
          description: 'Error clearing previous data. Will attempt to proceed with upload.',
          variant: 'destructive'
        });
      }
      setProgress(10);
      console.log(`Processing ${totalRows} farmers from Excel file`);

      // Process data in batches
      for (let i = 0; i < data.length; i += BATCH_SIZE) {
        const batch = data.slice(i, i + BATCH_SIZE);
        for (const [rowIndex, farmer] of batch.entries()) {
          try {
            const currentRow = i + rowIndex + 1; // For error reporting

            // Enhanced validation for beneficiary name
            if (!farmer.beneficiaryName) {
              console.warn(`Row ${currentRow}: Empty beneficiary name found. Data:`, farmer);
              emptyNameRows++;
              failedRows++;
              errors.push({
                farmer: `Row ${currentRow}`,
                error: 'Beneficiary name is required but was empty. Check column header "Name of Beneficiary" or similar.',
                row: currentRow
              });
              continue;
            }

            // Create farmer record with required fields guaranteed for Supabase schema
            const farmerRecord: FarmerInsert = {
              beneficiary_name: farmer.beneficiaryName,
              // Must have a value
              registration_number: farmer.farmerRegistrationNumber || null,
              mobile_number: farmer.mobileNo || farmer.mobileNumber || null,
              block_name: farmer.blockName || null,
              district_name: farmer.districtName || null,
              current_status: farmer.currentStatus || null,
              irrigation_type: farmer.irrigationType || null,
              doc_upload_status: farmer.docUploadStatus || null,
              beneficiary_type: farmer.beneficiaryType || null,
              farmer_category: farmer.farmerCategory || null,
              sex: farmer.sex || null,
              farmer_status: farmer.farmerStatus || null,
              epic_number: farmer.epicNumber || null,
              aadhar_number: farmer.aadharNumber || null,
              enrollment_number: farmer.enrollmentNumber || null,
              gram_panchayet: farmer.gramPanchayet || null,
              mouza_name: farmer.mouzaName || null,
              police_station: farmer.policeStation || null,
              post_office: farmer.postOffice || null,
              sub_division: farmer.subDivision || null,
              pincode: farmer.pincode || null,
              crop_type: farmer.cropType || null,
              crop_spacing: farmer.cropSpacing || null,
              is_pump_available: farmer.isPumpAvailable || null,
              pump_type: farmer.pumpType || null,
              pump_capacity: farmer.pumpCapacity || null,
              indicative_cost: farmer.indicativeCost || null,
              water_source: farmer.waterSource || null,
              other_water_source: farmer.otherWaterSource || null,
              registration_date: formatToISODate(farmer.registrationDate) || null,
              irrigation_area: farmer.irrigationArea || null,
              dealer_name: farmer.dealerName || null,
              financial_year: farmer.financialYear || null
            };
            console.log(`Inserting farmer (row ${currentRow}): ${farmerRecord.beneficiary_name}`);

            // Insert farmer record and get back the ID
            const {
              data: newFarmer,
              error
            } = await supabase.from('farmers').insert(farmerRecord).select('id').single();
            if (error) {
              console.error(`Row ${currentRow}: Error creating farmer:`, error, farmerRecord);
              failedRows++;
              errors.push({
                farmer: farmer.beneficiaryName || `Row ${currentRow}`,
                error: error.message,
                row: currentRow
              });
            } else if (newFarmer) {
              // Create invoice record with all available fields
              const invoiceRecord: InvoiceInsert = {
                farmer_id: newFarmer.id,
                financial_year: farmer.financialYear || null,
                payment_date: formatToISODate(farmer.paymentDate) || null,
                amount: isNaN(parseFloat(farmer.totalAmount)) ? null : parseFloat(farmer.totalAmount),
                bill_date: formatToISODate(farmer.billDate) || null,
                approved_on: formatToISODate(farmer.approvedOn) || null,
                pmksy_amount_paid: isNaN(parseFloat(farmer.pmksyAmountPaid)) ? null : parseFloat(farmer.pmksyAmountPaid),
                pmksy_cgst: isNaN(parseFloat(farmer.pmksyCGST)) ? null : parseFloat(farmer.pmksyCGST),
                pmksy_sgst: isNaN(parseFloat(farmer.pmksySGST)) ? null : parseFloat(farmer.pmksySGST),
                pmksy_tds: isNaN(parseFloat(farmer.pmksyTDS)) ? null : parseFloat(farmer.pmksyTDS),
                pmksy_released_on: formatToISODate(farmer.pmksyReleasedOn) || null,
                pmksy_transaction_date: formatToISODate(farmer.pmksyTransactionDate) || null,
                bksy_amount_paid: isNaN(parseFloat(farmer.bksyAmountPaid)) ? null : parseFloat(farmer.bksyAmountPaid),
                bksy_cgst: isNaN(parseFloat(farmer.bksyCGST)) ? null : parseFloat(farmer.bksyCGST),
                bksy_sgst: isNaN(parseFloat(farmer.bksySGST)) ? null : parseFloat(farmer.bksySGST),
                bksy_tds: isNaN(parseFloat(farmer.bksyTDS)) ? null : parseFloat(farmer.bksyTDS),
                bksy_released_on: formatToISODate(farmer.bksyReleasedOn) || null,
                bksy_transaction_date: formatToISODate(farmer.bksyTransactionDate) || null,
                dlic_date: formatToISODate(farmer.dlicDate) || null,
                quotation_date: formatToISODate(farmer.quotationDate) || null,
                joint_insp_date: formatToISODate(farmer.jointInspDate) || null,
                quot_approval_date: formatToISODate(farmer.quotApprovalDate) || null,
                work_order_date: formatToISODate(farmer.workOrderDate) || null,
                inspection_date: formatToISODate(farmer.inspectionDate) || null,
                installation_date: formatToISODate(farmer.installationDate) || null,
                // Invoice specific fields
                pmksy_subsidy: isNaN(parseFloat(farmer.pmksySubsidy)) ? null : parseFloat(farmer.pmksySubsidy),
                bksy_subsidy: isNaN(parseFloat(farmer.bksySubsidy)) ? null : parseFloat(farmer.bksySubsidy),
                gst_amount: isNaN(parseFloat(farmer.gstAmount)) ? null : parseFloat(farmer.gstAmount),
                farmers_share: isNaN(parseFloat(farmer.farmersShare)) ? null : parseFloat(farmer.farmersShare),
                pmksy_subsidy_addl: isNaN(parseFloat(farmer.pmksySubsidyAddl)) ? null : parseFloat(farmer.pmksySubsidyAddl),
                bksy_subsidy_addl: isNaN(parseFloat(farmer.bksySubsidyAddl)) ? null : parseFloat(farmer.bksySubsidyAddl),
                gst_amount_addl: isNaN(parseFloat(farmer.gstAmountAddl)) ? null : parseFloat(farmer.gstAmountAddl),
                farmers_share_addl: isNaN(parseFloat(farmer.farmersShareAddl)) ? null : parseFloat(farmer.farmersShareAddl),
                total_subsidy: isNaN(parseFloat(farmer.totalSubsidy)) ? null : parseFloat(farmer.totalSubsidy),
                total_farmer_share: isNaN(parseFloat(farmer.totalFarmerShare)) ? null : parseFloat(farmer.totalFarmerShare),
                paid_by_farmer: isNaN(parseFloat(farmer.paidByFarmer)) ? null : parseFloat(farmer.paidByFarmer),
                // Text fields - ensure these are saved correctly
                type_of_payment: farmer.typeOfPayment || null,
                bill_no: farmer.billNo || null,
                tax_inv_no: farmer.taxInvNo || null,
                dlic_number: farmer.dlicNumber || null,
                work_order_memo: farmer.workOrderMemo || null,
                quotation_no: farmer.quotationNo || null,
                pmksy_transaction_ref: farmer.pmksyTransactionRef || null,
                payment_reference: farmer.paymentReference || null,
                pmksy_paid_by: farmer.pmksyPaidBy || null,
                bksy_transaction_ref: farmer.bksyTransactionRef || null,
                bksy_paid_by: farmer.bksyPaidBy || null
              };
              const {
                error: invoiceError
              } = await supabase.from('invoices').insert(invoiceRecord);
              if (invoiceError) {
                console.error(`Row ${currentRow}: Error creating invoice:`, invoiceError, invoiceRecord);
                errors.push({
                  farmer: farmer.beneficiaryName || `Row ${currentRow}`,
                  error: `Invoice error: ${invoiceError.message}`,
                  row: currentRow
                });
              }
              insertedRows++;
            }
          } catch (error: any) {
            console.error(`Row ${i + rowIndex + 1}: Error saving to Supabase:`, error);
            failedRows++;
            errors.push({
              farmer: farmer.beneficiaryName || `Row ${i + rowIndex + 1}`,
              error: error.message || 'Unknown error',
              row: i + rowIndex + 1
            });
          }
        }
        processedRows += batch.length;
        setProgress(Math.round(10 + processedRows / totalRows * 90));
        setUploadStats({
          parsed: totalRows,
          inserted: insertedRows,
          failed: failedRows,
          emptyNames: emptyNameRows
        });
        setUploadErrors(errors);
      }
      console.log(`Saved ${insertedRows} farmers to Supabase with ${failedRows} failures (${emptyNameRows} empty names)`);
      return {
        insertedRows,
        failedRows,
        errors,
        emptyNames: emptyNameRows
      };
    } catch (error) {
      console.error("Error in batch processing:", error);
      throw error;
    }
  };
  const processFile = async () => {
    if (!file || !isLoggedIn) return;
    try {
      setLoading(true);
      setUploadStatus('processing');
      setProgress(5);
      const fileExtension = file.name.split('.').pop()?.toLowerCase();
      let data: any[] = [];
      if (fileExtension === 'csv') {
        const text = await file.text();
        const workbook = XLSX.read(text, {
          type: 'string'
        });
        const sheetName = workbook.SheetNames[0];
        const worksheet = workbook.Sheets[sheetName];
        data = XLSX.utils.sheet_to_json(worksheet, {
          defval: ''
        }); // Use defval to avoid undefined values
      } else if (fileExtension === 'xlsx' || fileExtension === 'xls') {
        const arrayBuffer = await file.arrayBuffer();
        const workbook = XLSX.read(arrayBuffer, {
          type: 'array'
        });
        const sheetName = workbook.SheetNames[0];
        const worksheet = workbook.Sheets[sheetName];
        data = XLSX.utils.sheet_to_json(worksheet, {
          defval: ''
        }); // Use defval to avoid undefined values
      }
      if (data.length === 0) {
        throw new Error('No data found in the file');
      }
      console.log(`Excel file contains ${data.length} records`);
      console.log('Sample data from first row:', data[0]); // Log first row to see structure
      console.log('Available columns:', Object.keys(data[0])); // Log available column names

      // Check if "Name of Beneficiary" column exists (the most common header for the name field)
      if (data[0] && !data[0]['Name of Beneficiary'] && !data[0]['BENEFICIARY NAME'] && !data[0]['Beneficiary Name']) {
        console.log('Warning: Could not find "Name of Beneficiary" column. Available columns are:', Object.keys(data[0]));
        toast({
          title: 'Warning',
          description: 'Could not find "Name of Beneficiary" column. Please check your Excel headers.',
          variant: 'destructive'
        });
      }
      setProgress(20);
      setUploadStatus('uploading');
      setUploadStats({
        parsed: data.length,
        inserted: 0,
        failed: 0,
        emptyNames: 0
      });
      const formattedData = formatCsvData(data);
      console.log(`Formatted ${formattedData.length} records`);
      console.log('Sample formatted data:', formattedData[0]); // Log first formatted row

      // Check for empty beneficiary names before upload
      const emptyNames = formattedData.filter(f => !f.beneficiaryName || f.beneficiaryName.trim() === '').length;
      if (emptyNames > 0) {
        console.warn(`Found ${emptyNames} records with empty beneficiary names that will be skipped`);
        if (emptyNames === formattedData.length) {
          throw new Error('All rows have empty beneficiary names. Check if the column header is "Name of Beneficiary" or a similar variation.');
        }
      }
      setProgress(40);

      // Save to Supabase first, then update the local state
      const {
        insertedRows,
        failedRows,
        errors,
        emptyNames: emptyNameCount
      } = await saveToSupabase(formattedData);

      // After saving to Supabase, reload the data using the refreshData function
      await refreshData();
      if (emptyNameCount > 0) {
        toast({
          title: 'Warning',
          description: `${emptyNameCount} records had empty beneficiary names and were skipped.`,
          variant: 'destructive'
        });
      }
      setUploadStatus('success');
      toast({
        title: 'Upload Successful',
        description: `Processed ${data.length} records: ${insertedRows} inserted, ${failedRows} failed (${emptyNameCount} had empty names).`
      });

      // Delay navigation to allow context to update
      setTimeout(() => {
        navigate('/?reload=' + new Date().getTime());
      }, 2000);
    } catch (error: any) {
      console.error('Error processing file:', error);
      setUploadStatus('error');
      setErrorMessage(error.message || 'Error processing file');
      toast({
        title: 'Upload Failed',
        description: error.message || 'Error processing file',
        variant: 'destructive'
      });
    } finally {
      setLoading(false);
    }
  };
  return <div className="bg-white rounded-lg shadow-md p-6">
      <h2 className="text-2xl font-semibold mb-6 text-gray-800">Upload Data</h2>
      
      {!isLoggedIn && <div className="bg-yellow-50 p-4 mb-6 rounded-lg border border-yellow-200">
          <p className="text-yellow-800">
            You can view data without logging in, but you need to login to upload new data.
          </p>
        </div>}
      
      <div {...getRootProps()} className={`border-2 border-dashed rounded-lg p-8 text-center cursor-pointer transition-colors ${isDragActive ? 'bg-blue-50 border-blue-300' : 'border-gray-300 hover:bg-gray-50'}`}>
        <input {...getInputProps()} />
        <UploadCloud className="h-12 w-12 mx-auto text-blue-500 mb-3" />
        <p className="text-gray-600 mb-2">
          {isDragActive ? "Drop the file here..." : "Drag & drop a CSV or Excel file here, or click to select"}
        </p>
        <p className="text-sm text-gray-500">
          Only .csv, .xlsx, or .xls files are supported
        </p>
        {!isLoggedIn && <button onClick={e => {
        e.stopPropagation();
        setShowLoginModal(true);
      }} className="mt-4 px-4 py-2 text-white rounded-md transition-colors bg-emerald-700 hover:bg-emerald-600">
            Login to Upload
          </button>}
      </div>
      
      {file && <div className="mt-6 w-full">
          <div className="flex flex-col sm:flex-row sm:items-center p-4 bg-gray-50 rounded-lg">
            <div className="flex items-center flex-grow mb-3 sm:mb-0">
              <FileText className="h-6 w-6 text-blue-500 mr-3 flex-shrink-0" />
              <div className="min-w-0">
                <p className="font-medium text-gray-800 truncate">{file.name}</p>
                <p className="text-sm text-gray-500">
                  {(file.size / 1024).toFixed(2)} KB
                </p>
              </div>
            </div>
            {uploadStatus === 'idle' && isLoggedIn && <button onClick={processFile} className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors w-full sm:w-auto">
                Process File
              </button>}
            {uploadStatus === 'processing' && <span className="flex items-center text-amber-600">
                <Loader className="h-5 w-5 mr-1 animate-spin" />
                Processing...
              </span>}
            {uploadStatus === 'uploading' && <span className="flex items-center text-blue-600">
                <Loader className="h-5 w-5 mr-1 animate-spin" />
                Uploading...
              </span>}
            {uploadStatus === 'success' && <span className="flex items-center text-green-600">
                <CheckCircle className="h-5 w-5 mr-1" />
                Success
              </span>}
            {uploadStatus === 'error' && <span className="flex items-center text-red-600">
                <AlertCircle className="h-5 w-5 mr-1" />
                Error
              </span>}
          </div>
          
          {(uploadStatus === 'processing' || uploadStatus === 'uploading') && <div className="mt-3">
              <p className="text-sm text-gray-600 mb-1">Upload progress: {progress}%</p>
              <Progress value={progress} className="h-2" />
              {uploadStats.parsed > 0 && <div className="mt-2 text-sm text-gray-600">
                  <p>Processed: {uploadStats.parsed} records</p>
                  <p>Inserted: {uploadStats.inserted} records</p>
                  {uploadStats.failed > 0 && <p className="text-red-500">Failed: {uploadStats.failed} records</p>}
                  {uploadStats.emptyNames > 0 && <p className="text-orange-500">Empty names: {uploadStats.emptyNames} records</p>}
                </div>}
            </div>}
          
          {uploadStatus === 'success' && <div className="mt-3 p-3 bg-green-50 text-green-700 rounded-lg text-sm">
              <p className="font-medium">Upload complete!</p>
              <p>Successfully processed {uploadStats.parsed} records</p>
              <p>Redirecting to dashboard...</p>
            </div>}
          
          {uploadStatus === 'error' && errorMessage && <div className="mt-3 p-3 bg-red-50 text-red-700 rounded-lg text-sm">
              {errorMessage}
            </div>}
          
          {uploadErrors.length > 0 && <div className="mt-4">
              <h3 className="text-md font-medium mb-2">Upload Errors ({uploadErrors.length})</h3>
              <div className="max-h-60 overflow-y-auto border rounded">
                <table className="min-w-full divide-y divide-gray-200">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="px-4 py-2 text-left text-xs font-medium text-gray-500">Row</th>
                      <th className="px-4 py-2 text-left text-xs font-medium text-gray-500">Farmer</th>
                      <th className="px-4 py-2 text-left text-xs font-medium text-gray-500">Error</th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {uploadErrors.map((error, index) => <tr key={index}>
                        <td className="px-4 py-2 text-sm text-gray-500">{error.row || '-'}</td>
                        <td className="px-4 py-2 text-sm text-gray-900">{error.farmer}</td>
                        <td className="px-4 py-2 text-sm text-red-600">{error.error}</td>
                      </tr>)}
                  </tbody>
                </table>
              </div>
            </div>}
        </div>}
      
      <div className="mt-8">
        <h3 className="text-lg font-medium mb-3 text-gray-800">Instructions</h3>
        <ul className="list-disc pl-5 space-y-2 text-gray-600">
          <li>Make sure your CSV or Excel file contains all required fields.</li>
          <li>The first row should contain column headers.</li>
          
          <li>Uploading a new file will <strong>clear all existing data</strong> and add the new records.</li>
          <li>Data is securely stored in our database and synchronized across all devices.</li>
          <li>After uploading, you'll be redirected to the Dashboard to verify your data.</li>
          <li>If upload fails, check the error messages and try again.</li>
        </ul>
      </div>
    </div>;
};
export default CsvUpload;