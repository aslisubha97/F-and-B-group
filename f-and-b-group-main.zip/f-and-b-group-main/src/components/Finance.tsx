import React, { useState, useMemo, useEffect } from 'react';
import { useAppContext } from '../context/AppContext';
import { FileText, Download, ArrowRight, AlertCircle, CheckCircle, XCircle } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, Cell } from 'recharts';
import { PieChart, Pie } from 'recharts';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { format } from 'date-fns';
import { Badge } from "@/components/ui/badge";
import { toast } from "@/components/ui/use-toast";
import ReportDetailsDialog from './ReportDetailsDialog';
import { Pagination, PaginationContent, PaginationEllipsis, PaginationItem } from "@/components/ui/pagination";
import { usePagination } from '@/hooks/use-pagination';
import { ChevronLeft, ChevronRight } from 'lucide-react';
interface FinanceProps {
  selectedFinancialYear?: string;
  billNumberSearch?: string;
}

// Helper function for extracting financial year from reg number
const getFinancialYearFromRegNumber = (regNumber?: string): string => {
  if (!regNumber) return '';
  const match = regNumber.match(/\/(\d{4}-\d{4})$/);
  if (match && match[1]) {
    return match[1];
  }
  return '';
};
const Finance: React.FC<FinanceProps> = ({
  billNumberSearch = ''
}) => {
  const {
    filteredFarmerData,
    blockSummaries,
    selectedFinancialYear
  } = useAppContext();
  
  const [selectedDistrict, setSelectedDistrict] = useState('All Districts');
  const [selectedBlock, setSelectedBlock] = useState('All Blocks');
  const [activeTab, setActiveTab] = useState('pmksy');
  const [showSchemeDetail, setShowSchemeDetail] = useState(false);
  const [schemeDetailData, setSchemeDetailData] = useState<{
    type: 'pmksy' | 'bksy';
    title: string;
    farmers: any[];
  }>({
    type: 'pmksy',
    title: '',
    farmers: []
  });

  // Bill summary pagination
  const [billSummaryPage, setBillSummaryPage] = useState(1);
  const billsPerPage = 5;

  // Bill Detail Dialog
  const [showBillDetail, setShowBillDetail] = useState(false);
  const [selectedBill, setSelectedBill] = useState<{
    billNo: string;
    farmers: any[];
  }>({
    billNo: '',
    farmers: []
  });

  // Log data on component mount
  useEffect(() => {
    console.log(`Finance component rendered with ${filteredFarmerData.length} farmer records`);
    console.log(`Finance component has ${blockSummaries.length} block summaries`);
    console.log(`Applied financial year filter: ${selectedFinancialYear}`);
    if (filteredFarmerData.length > 0) {
      // Log a sample farmer to check data structure
      console.log("Sample farmer data:", filteredFarmerData[0]);
    } else {
      console.log("No farmer data available in Finance component");
    }
  }, [filteredFarmerData, blockSummaries, selectedFinancialYear]);

  // Reset pagination when financial year changes
  useEffect(() => {
    setBillSummaryPage(1);
  }, [selectedFinancialYear]);
  
  const allDistricts = useMemo(() => Array.from(new Set(filteredFarmerData.map(farmer => farmer.districtName).filter(Boolean))), [filteredFarmerData]);
  
  const filteredBlocks = useMemo(() => {
    return Array.from(new Set(
      filteredFarmerData
        .filter(farmer => selectedDistrict === 'All Districts' || farmer.districtName === selectedDistrict)
        .map(farmer => farmer.blockName)
        .filter(Boolean)
    ));
  }, [filteredFarmerData, selectedDistrict]);
  
  const filteredData = useMemo(() => {
    let filtered = filteredFarmerData.filter(farmer => 
      (selectedDistrict === 'All Districts' || farmer.districtName === selectedDistrict) && 
      (selectedBlock === 'All Blocks' || farmer.blockName === selectedBlock)
    );

    if (billNumberSearch) {
      filtered = filtered.filter(farmer => farmer.billNo && farmer.billNo.includes(billNumberSearch));
    }
    
    return filtered;
  }, [filteredFarmerData, selectedDistrict, selectedBlock, billNumberSearch]);
  
  const formatDate = (dateString: string | undefined) => {
    if (!dateString) return '-';
    
    // Check if the dateString is a number (Excel serial date)
    if (!isNaN(Number(dateString))) {
      // Convert Excel serial date to JavaScript date
      // Excel dates start from December 30, 1899
      const excelStartDate = new Date(1899, 11, 30);
      const msPerDay = 24 * 60 * 60 * 1000;
      const date = new Date(excelStartDate.getTime() + Number(dateString) * msPerDay);
      return format(date, 'dd/MM/yyyy');
    }
    
    // Try to parse the date string
    try {
      const date = new Date(dateString);
      if (!isNaN(date.getTime())) {
        return format(date, 'dd/MM/yyyy');
      }
    } catch (error) {
      console.error("Error parsing date:", error);
    }
    return dateString;
  };
  
  const handleDistrictChange = (value: string) => {
    setSelectedDistrict(value);
    setSelectedBlock('All Blocks');
  };

  // Updated logic for determining subsidy release status and calculating due amounts
  const subsidyStatus = useMemo(() => {
    const status = {
      pmksyReleased: 0,
      pmksyNotReleased: 0,
      pmksyTotalAmount: 0,
      pmksyTotalDue: 0,
      bksyReleased: 0,
      bksyNotReleased: 0,
      bksyTotalAmount: 0,
      bksyTotalDue: 0
    };
    
    filteredData.forEach(farmer => {
      // For PMKSY
      if (farmer.pmksyAmountPaid && parseFloat(farmer.pmksyAmountPaid) > 0) {
        status.pmksyReleased++;
        status.pmksyTotalAmount += parseFloat(farmer.pmksyAmountPaid) || 0;
      }
      // For PMKSY Due - Bill exists but no payment, and has subsidy value
      else if (farmer.billNo && farmer.billNo.trim() !== '') {
        status.pmksyNotReleased++;

        // If there's a subsidy amount defined, add it to the due amount
        if (farmer.pmksySubsidy && parseFloat(farmer.pmksySubsidy) > 0) {
          status.pmksyTotalDue += parseFloat(farmer.pmksySubsidy) || 0;
        }
      }

      // For BKSY
      if (farmer.bksyAmountPaid && parseFloat(farmer.bksyAmountPaid) > 0) {
        status.bksyReleased++;
        status.bksyTotalAmount += parseFloat(farmer.bksyAmountPaid) || 0;
      }
      // For BKSY Due - Bill exists but no payment, and has subsidy value
      else if (farmer.billNo && farmer.billNo.trim() !== '') {
        status.bksyNotReleased++;

        // If there's a subsidy amount defined, add it to the due amount
        if (farmer.bksySubsidy && parseFloat(farmer.bksySubsidy) > 0) {
          status.bksyTotalDue += parseFloat(farmer.bksySubsidy) || 0;
        }
      }
    });
    return status;
  }, [filteredData]);

  // Updated finance metrics calculation using the new logic
  const financeMetrics = useMemo(() => {
    const metrics = {
      pmksyTotalPaid: 0,
      pmksyTotalCGST: 0,
      pmksyTotalSGST: 0,
      pmksyTotalTDS: 0,
      pmksyTotalDue: 0,
      bksyTotalPaid: 0,
      bksyTotalCGST: 0,
      bksyTotalSGST: 0,
      bksyTotalTDS: 0,
      bksyTotalDue: 0,
      gstSubmitted: 0,
      gstDue: 0
    };
    filteredData.forEach(farmer => {
      // New logic: If PMKSY Amount Paid > 0, include in calculations
      if (farmer.pmksyAmountPaid && parseFloat(farmer.pmksyAmountPaid) > 0) {
        metrics.pmksyTotalPaid += parseFloat(farmer.pmksyAmountPaid) || 0;
        metrics.pmksyTotalCGST += parseFloat(farmer.pmksyCGST) || 0;
        metrics.pmksyTotalSGST += parseFloat(farmer.pmksySGST) || 0;
        metrics.pmksyTotalTDS += parseFloat(farmer.pmksyTDS) || 0;
        metrics.pmksyTotalDue += parseFloat(farmer.pmksySubsidy) || 0;

        // Calculate GST submitted for PMKSY (assuming if Amount Paid > 0, GST is submitted)
        metrics.gstSubmitted += parseFloat(farmer.pmksyCGST) || 0;
        metrics.gstSubmitted += parseFloat(farmer.pmksySGST) || 0;
      } else if (farmer.billNo && farmer.billNo.trim() !== '') {
        // If bill exists but amount not paid, GST is due
        metrics.gstDue += parseFloat(farmer.pmksyCGST) || 0;
        metrics.gstDue += parseFloat(farmer.pmksySGST) || 0;
      }

      // New logic: If BKSY Amount Paid > 0, include in calculations
      if (farmer.bksyAmountPaid && parseFloat(farmer.bksyAmountPaid) > 0) {
        metrics.bksyTotalPaid += parseFloat(farmer.bksyAmountPaid) || 0;
        metrics.bksyTotalCGST += parseFloat(farmer.bksyCGST) || 0;
        metrics.bksyTotalSGST += parseFloat(farmer.bksySGST) || 0;
        metrics.bksyTotalTDS += parseFloat(farmer.bksyTDS) || 0;
        metrics.bksyTotalDue += parseFloat(farmer.bksySubsidy) || 0;

        // Calculate GST submitted for BKSY
        metrics.gstSubmitted += parseFloat(farmer.bksyCGST) || 0;
        metrics.gstSubmitted += parseFloat(farmer.bksySGST) || 0;
      } else if (farmer.billNo && farmer.billNo.trim() !== '') {
        // If bill exists but amount not paid, GST is due
        metrics.gstDue += parseFloat(farmer.bksyCGST) || 0;
        metrics.gstDue += parseFloat(farmer.bksySGST) || 0;
      }
    });
    return metrics;
  }, [filteredData]);
  
  const paymentsNotReceived = useMemo(() => {
    // PMKSY not received: Bill No exists but PMKSY Amount Paid ≤ 0
    const pmksyNotReceived = filteredData.filter(farmer => farmer.billNo && farmer.billNo.trim() !== '' && (!farmer.pmksyAmountPaid || parseFloat(farmer.pmksyAmountPaid) <= 0));

    // BKSY not received: Bill No exists but BKSY Amount Paid ≤ 0
    const bksyNotReceived = filteredData.filter(farmer => farmer.billNo && farmer.billNo.trim() !== '' && (!farmer.bksyAmountPaid || parseFloat(farmer.bksyAmountPaid) <= 0));
    return {
      pmksy: pmksyNotReceived,
      bksy: bksyNotReceived
    };
  }, [filteredData]);
  
  const blockFundDistribution = useMemo(() => {
    const distribution: {
      [key: string]: {
        pmksy: number;
        bksy: number;
      };
    } = {};
    filteredData.forEach(farmer => {
      if (farmer.blockName) {
        if (!distribution[farmer.blockName]) {
          distribution[farmer.blockName] = {
            pmksy: 0,
            bksy: 0
          };
        }

        // Apply the updated logic:
        // If PMKSY Amount Paid > 0, include in distribution
        if (farmer.pmksyAmountPaid && parseFloat(farmer.pmksyAmountPaid) > 0) {
          distribution[farmer.blockName].pmksy += parseFloat(farmer.pmksyAmountPaid) || 0;
        }

        // If BKSY Amount Paid > 0, include in distribution
        if (farmer.bksyAmountPaid && parseFloat(farmer.bksyAmountPaid) > 0) {
          distribution[farmer.blockName].bksy += parseFloat(farmer.bksyAmountPaid) || 0;
        }
      }
    });
    return distribution;
  }, [filteredData]);
  
  const blockFundChartData = useMemo(() => {
    return Object.entries(blockFundDistribution).sort((a, b) => b[1].pmksy + b[1].bksy - (a[1].pmksy + a[1].bksy)).slice(0, 10).map(([block, funds]) => ({
      name: block,
      pmksy: funds.pmksy,
      bksy: funds.bksy
    }));
  }, [blockFundDistribution]);
  
  const billSummaryData = useMemo(() => {
    const billGroups: {
      [key: string]: {
        billNo: string;
        farmerCount: number;
        pmksyReleasedCount: number;
        bksyReleasedCount: number;
        totalPmksySubsidy: number;
        totalBksySubsidy: number;
        farmers: any[];
      };
    } = {};
    filteredData.forEach(farmer => {
      if (farmer.billNo && farmer.billNo.trim() !== '') {
        if (!billGroups[farmer.billNo]) {
          billGroups[farmer.billNo] = {
            billNo: farmer.billNo,
            farmerCount: 0,
            pmksyReleasedCount: 0,
            bksyReleasedCount: 0,
            totalPmksySubsidy: 0,
            totalBksySubsidy: 0,
            farmers: []
          };
        }
        billGroups[farmer.billNo].farmerCount += 1;

        // Check if PMKSY released (updated logic)
        if (farmer.pmksyAmountPaid && parseFloat(farmer.pmksyAmountPaid) > 0) {
          billGroups[farmer.billNo].pmksyReleasedCount += 1;
          billGroups[farmer.billNo].totalPmksySubsidy += parseFloat(farmer.pmksyAmountPaid) || 0;
        }

        // Check if BKSY released (updated logic)
        if (farmer.bksyAmountPaid && parseFloat(farmer.bksyAmountPaid) > 0) {
          billGroups[farmer.billNo].bksyReleasedCount += 1;
          billGroups[farmer.billNo].totalBksySubsidy += parseFloat(farmer.bksyAmountPaid) || 0;
        }
        billGroups[farmer.billNo].farmers.push(farmer);
      }
    });
    return Object.values(billGroups).sort((a, b) => b.farmerCount - a.farmerCount);
  }, [filteredData]);
  
  const pmksyPieData = [{
    name: 'Amount Paid',
    value: financeMetrics.pmksyTotalPaid - financeMetrics.pmksyTotalCGST - financeMetrics.pmksyTotalSGST - financeMetrics.pmksyTotalTDS,
    color: '#2563EB'
  }, {
    name: 'CGST',
    value: financeMetrics.pmksyTotalCGST,
    color: '#10B981'
  }, {
    name: 'SGST',
    value: financeMetrics.pmksyTotalSGST,
    color: '#F59E0B'
  }, {
    name: 'TDS',
    value: financeMetrics.pmksyTotalTDS,
    color: '#EF4444'
  }];
  
  const bksyPieData = [{
    name: 'Amount Paid',
    value: financeMetrics.bksyTotalPaid - financeMetrics.bksyTotalCGST - financeMetrics.bksyTotalSGST - financeMetrics.bksyTotalTDS,
    color: '#2563EB'
  }, {
    name: 'CGST',
    value: financeMetrics.bksyTotalCGST,
    color: '#10B981'
  }, {
    name: 'SGST',
    value: financeMetrics.bksyTotalSGST,
    color: '#F59E0B'
  }, {
    name: 'TDS',
    value: financeMetrics.bksyTotalTDS,
    color: '#EF4444'
  }];
  
  const handleExportReport = () => {
    window.print();
  };
  
  const handleShowSchemeDetail = (type: 'pmksy' | 'bksy') => {
    // Only include farmers with released subsidies
    const farmers = filteredData.filter(farmer => {
      if (type === 'pmksy') {
        return farmer.billNo && farmer.pmksyTransactionRef && parseFloat(farmer.pmksyAmountPaid) > 0;
      } else {
        return farmer.billNo && farmer.bksyTransactionRef && parseFloat(farmer.bksyAmountPaid) > 0;
      }
    });
    setSchemeDetailData({
      type,
      title: type === 'pmksy' ? 'PMKSY Payment Details' : 'BKSY Payment Details',
      farmers
    });
    setShowSchemeDetail(true);
  };
  
  const exportSchemeDetails = (farmers: any[], type: string) => {
    const headers = ['Name', 'Registration Number', 'Mobile Number', 'Bill No', 'Bill Date', 'Block', 'Irrigation Type', 'Amount Paid', 'CGST', 'SGST', 'TDS', 'Released On', 'Transaction Ref'].join(',');
    const rows = farmers.map(farmer => [`"${farmer.beneficiaryName || ''}"`, `"${farmer.farmerRegistrationNumber || ''}"`, `"${farmer.mobileNumber || farmer.mobileNo || ''}"`, `"${farmer.billNo || ''}"`, `"${formatDate(farmer.billDate) || ''}"`, `"${farmer.blockName || ''}"`, `"${farmer.irrigationType || ''}"`, `"${type === 'pmksy' ? farmer.pmksyAmountPaid || '0' : farmer.bksyAmountPaid || '0'}"`, `"${type === 'pmksy' ? farmer.pmksyCGST || '0' : farmer.bksyCGST || '0'}"`, `"${type === 'pmksy' ? farmer.pmksySGST || '0' : farmer.bksySGST || '0'}"`, `"${type === 'pmksy' ? farmer.pmksyTDS || '0' : farmer.bksyTDS || '0'}"`, `"${type === 'pmksy' ? farmer.pmksyReleasedOn || 'N/A' : farmer.bksyReleasedOn || 'N/A'}"`, `"${type === 'pmksy' ? farmer.pmksyTransactionRef || 'N/A' : farmer.bksyTransactionRef || 'N/A'}"`].join(','));
    const csvContent = [headers, ...rows].join('\n');
    const blob = new Blob([csvContent], {
      type: 'text/csv;charset=utf-8;'
    });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `${type}_payment_details.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };
  
  // Group farmers by bill number for search results
  const billNumberGroups = useMemo(() => {
    if (!billNumberSearch) return [];
    const groups: {
      [key: string]: any[];
    } = {};
    filteredData.forEach(farmer => {
      if (farmer.billNo && farmer.billNo.includes(billNumberSearch)) {
        if (!groups[farmer.billNo]) {
          groups[farmer.billNo] = [];
        }
        groups[farmer.billNo].push(farmer);
      }
    });
    return Object.entries(groups).map(([billNo, farmers]) => ({
      billNo,
      farmers: farmers.sort((a, b) => (a.beneficiaryName || '').localeCompare(b.beneficiaryName || ''))
    }));
  }, [filteredData, billNumberSearch]);
  
  // Paginated bill summary data
  const paginatedBillSummaryData = useMemo(() => {
    const startIndex = (billSummaryPage - 1) * billsPerPage;
    const endIndex = startIndex + billsPerPage;
    return billSummaryData.slice(startIndex, endIndex);
  }, [billSummaryData, billSummaryPage, billsPerPage]);
  
  // Calculate total pages for bill summary pagination
  const totalBillSummaryPages = Math.ceil(billSummaryData.length / billsPerPage);
  
  // Use the pagination hook to generate pagination controls
  const {
    pages,
    showLeftEllipsis,
    showRightEllipsis
  } = usePagination({
    currentPage: billSummaryPage,
    totalPages: totalBillSummaryPages,
    paginationItemsToDisplay: 5
  });
  
  // Handle load more bills - modified to increment loadMoreCount
  const handleLoadMoreBills = () => {
    setBillSummaryPage(prev => prev + 1);
  };
  
  // Handle view bill details
  const handleViewBillDetails = (billNo: string) => {
    const bill = billSummaryData.find(b => b.billNo === billNo);
    if (bill) {
      setSelectedBill({
        billNo: bill.billNo,
        farmers: bill.farmers
      });
      setShowBillDetail(true);
    }
  };
  return <div className="max-w-7xl mx-auto">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 mb-4 md:mb-6">
        <h1 className="text-xl md:text-2xl font-bold">Finance Reports</h1>
        
        <div className="flex flex-wrap gap-2">
          <Select value={selectedDistrict} onValueChange={handleDistrictChange}>
            <SelectTrigger className="w-full md:w-auto">
              <SelectValue placeholder="Select District" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="All Districts">All Districts</SelectItem>
              {allDistricts.map(district => <SelectItem key={district} value={district}>{district}</SelectItem>)}
            </SelectContent>
          </Select>
          
          <Select value={selectedBlock} onValueChange={setSelectedBlock}>
            <SelectTrigger className="w-full md:w-auto">
              <SelectValue placeholder="Select Block" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="All Blocks">All Blocks</SelectItem>
              {filteredBlocks.map(block => <SelectItem key={block} value={block}>{block}</SelectItem>)}
            </SelectContent>
          </Select>
          
          <Button onClick={handleExportReport} className="w-full md:w-auto text-slate-50 bg-emerald-600 hover:bg-emerald-500">
            <Download className="h-4 w-4 mr-2" />
            Export Report
          </Button>
        </div>
      </div>
      
      {filteredFarmerData.length === 0 ? <div className="bg-white rounded-lg shadow-sm p-8 text-center">
          <AlertCircle className="h-12 w-12 mx-auto text-amber-500 mb-4" />
          <h3 className="text-lg font-medium mb-2">No Data Available</h3>
          <p className="text-gray-600 mb-4">There is no farmer data available to display financial reports.</p>
          <p className="text-sm text-gray-500">Please make sure data is loaded correctly or upload farmer data.</p>
        </div> : <>
          {/* Subsidy Release Status Summary */}
          
          
          {billNumberSearch && <div className="bg-white rounded-lg shadow-sm p-4 md:p-5 mb-4 md:mb-6">
              <h2 className="text-lg font-semibold mb-4">Search Results for Bill Number: {billNumberSearch}</h2>
              
              {billNumberGroups.length > 0 ? <div className="space-y-6">
                  {billNumberGroups.map((group, groupIndex) => <div key={groupIndex} className="border rounded-lg p-4">
                      <h3 className="text-md font-semibold mb-3">Bill No: {group.billNo} ({group.farmers.length} farmers)</h3>
                      
                      <div className="overflow-x-auto">
                        <Table>
                          <TableHeader>
                            <TableRow>
                              <TableHead>Beneficiary Name</TableHead>
                              <TableHead>Registration No.</TableHead>
                              <TableHead>Bill No.</TableHead>
                              <TableHead>Tax Inv. No.</TableHead>
                              <TableHead>PMKSY Status</TableHead>
                              <TableHead>PMKSY Amount</TableHead>
                              <TableHead>PMKSY Trans. Ref.</TableHead>
                              <TableHead>BKSY Status</TableHead>
                              <TableHead>BKSY Amount</TableHead>
                              <TableHead>BKSY Trans. Ref.</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {group.farmers.map((farmer, index) => <TableRow key={index}>
                                <TableCell>{farmer.beneficiaryName || 'N/A'}</TableCell>
                                <TableCell>{farmer.farmerRegistrationNumber || 'N/A'}</TableCell>
                                <TableCell>{farmer.billNo || 'N/A'}</TableCell>
                                <TableCell>{farmer.taxInvNo || 'N/A'}</TableCell>
                                <TableCell>
                                  {farmer.pmksyAmountPaid && parseFloat(farmer.pmksyAmountPaid) > 0 ? <Badge className="bg-green-100 text-green-800">Released</Badge> : <Badge className="bg-red-100 text-red-800">Not Released</Badge>}
                                </TableCell>
                                <TableCell>₹ {farmer.pmksyAmountPaid || '0'}</TableCell>
                                <TableCell>{farmer.pmksyTransactionRef || 'N/A'}</TableCell>
                                <TableCell>
                                  {farmer.bksyAmountPaid && parseFloat(farmer.bksyAmountPaid) > 0 ? <Badge className="bg-green-100 text-green-800">Released</Badge> : <Badge className="bg-red-100 text-red-800">Not Released</Badge>}
                                </TableCell>
                                <TableCell>₹ {farmer.bksyAmountPaid || '0'}</TableCell>
                                <TableCell>{farmer.bksyTransactionRef || 'N/A'}</TableCell>
                              </TableRow>)}
                          </TableBody>
                        </Table>
                      </div>
                      
                      <div className="flex justify-end mt-4">
                        <Button onClick={() => exportSchemeDetails(group.farmers, 'bill')} className="mt-2">
                          <Download className="h-4 w-4 mr-2" />
                          Export to CSV
                        </Button>
                      </div>
                    </div>)}
                </div> : <div className="text-center py-8">
                  <p className="text-gray-600">No farmers found with bill number containing "{billNumberSearch}"</p>
                </div>}
            </div>}
          
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-4 md:mb-6">
            <div className="bg-white rounded-lg shadow-sm p-4 border-l-4 border-blue-400 hover:shadow-md transition-shadow cursor-pointer text-left" onClick={() => handleShowSchemeDetail('pmksy')}>
              <div className="text-sm text-gray-500">PMKSY Total Amount</div>
              <div className="text-xl font-bold">₹ {financeMetrics.pmksyTotalPaid.toLocaleString('en-IN')}</div>
              <div className="flex items-center text-xs text-blue-600 mt-1">
                <span>View Details</span>
                <ArrowRight size={12} className="ml-1" />
              </div>
            </div>
            
            <div className="bg-white rounded-lg shadow-sm p-4 border-l-4 border-green-400 hover:shadow-md transition-shadow cursor-pointer text-left" onClick={() => handleShowSchemeDetail('bksy')}>
              <div className="text-sm text-gray-500">BKSY Total Amount</div>
              <div className="text-xl font-bold">₹ {financeMetrics.bksyTotalPaid.toLocaleString('en-IN')}</div>
              <div className="flex items-center text-xs text-green-600 mt-1">
                <span>View Details</span>
                <ArrowRight size={12} className="ml-1" />
              </div>
            </div>
            
            {/* Replace GST tiles with PMKSY Due and BKSY Due */}
            <div className="bg-white rounded-lg shadow-sm p-4 border-l-4 border-yellow-400 hover:shadow-md transition-shadow text-left">
              <div className="text-sm text-gray-500">PMKSY Due</div>
              <div className="text-xl font-bold">₹ {subsidyStatus.pmksyTotalDue.toLocaleString('en-IN')}</div>
              <div className="text-xs text-gray-500 mt-1">
                {subsidyStatus.pmksyNotReleased} farmers waiting for payment
              </div>
            </div>
            
            <div className="bg-white rounded-lg shadow-sm p-4 border-l-4 border-red-400 hover:shadow-md transition-shadow text-left">
              <div className="text-sm text-gray-500">BKSY Due</div>
              <div className="text-xl font-bold">₹ {subsidyStatus.bksyTotalDue.toLocaleString('en-IN')}</div>
              <div className="text-xs text-gray-500 mt-1">
                {subsidyStatus.bksyNotReleased} farmers waiting for payment
              </div>
            </div>
          </div>
          
          
          
          <div className="bg-white rounded-lg shadow-sm p-4 md:p-5 mb-6">
            <h2 className="text-lg font-semibold mb-4">Bill Summary</h2>
            
            {billSummaryData.length > 0 ? <>
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Bill No</TableHead>
                        <TableHead>Farmer Count</TableHead>
                        <TableHead>PMKSY Released</TableHead>
                        <TableHead>BKSY Released</TableHead>
                        <TableHead>Total PMKSY Amount</TableHead>
                        <TableHead>Total BKSY Amount</TableHead>
                        <TableHead>Grand Total</TableHead>
                        <TableHead>Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {paginatedBillSummaryData.map((bill, index) => <TableRow key={index}>
                          <TableCell className="font-medium">{bill.billNo}</TableCell>
                          <TableCell>{bill.farmerCount}</TableCell>
                          <TableCell>{bill.pmksyReleasedCount}/{bill.farmerCount}</TableCell>
                          <TableCell>{bill.bksyReleasedCount}/{bill.farmerCount}</TableCell>
                          <TableCell>₹ {bill.totalPmksySubsidy.toLocaleString('en-IN')}</TableCell>
                          <TableCell>₹ {bill.totalBksySubsidy.toLocaleString('en-IN')}</TableCell>
                          <TableCell>₹ {(bill.totalPmksySubsidy + bill.totalBksySubsidy).toLocaleString('en-IN')}</TableCell>
                          <TableCell>
                            <Button variant="ghost" size="sm" onClick={() => handleViewBillDetails(bill.billNo)}>
                              <FileText className="h-4 w-4 mr-2" />
                              View Details
                            </Button>
                          </TableCell>
                        </TableRow>)}
                    </TableBody>
                  </Table>
                </div>
                
                {/* Replace "Show More" with proper pagination controls */}
                {totalBillSummaryPages > 1 && <div className="flex items-center justify-center mt-4">
                    <Pagination>
                      <PaginationContent>
                        {/* Previous page button */}
                        <PaginationItem>
                          <Button size="icon" variant="outline" className="disabled:pointer-events-none disabled:opacity-50" onClick={() => setBillSummaryPage(curr => Math.max(1, curr - 1))} disabled={billSummaryPage === 1} aria-label="Go to previous page">
                            <ChevronLeft size={16} strokeWidth={2} aria-hidden="true" />
                          </Button>
                        </PaginationItem>

                        {/* Left ellipsis (...) */}
                        {showLeftEllipsis && <PaginationItem>
                            <PaginationEllipsis />
                          </PaginationItem>}

                        {/* Page number buttons */}
                        {pages.map(page => {
                  const isActive = page === billSummaryPage;
                  return <PaginationItem key={page}>
                              <Button size="icon" variant={`${isActive ? "outline" : "ghost"}`} onClick={() => setBillSummaryPage(page)} aria-current={isActive ? "page" : undefined}>
                                {page}
                              </Button>
                            </PaginationItem>;
                })}

                        {/* Right ellipsis (...) */}
                        {showRightEllipsis && <PaginationItem>
                            <PaginationEllipsis />
                          </PaginationItem>}

                        {/* Next page button */}
                        <PaginationItem>
                          <Button size="icon" variant="outline" className="disabled:pointer-events-none disabled:opacity-50" onClick={() => setBillSummaryPage(curr => Math.min(totalBillSummaryPages, curr + 1))} disabled={billSummaryPage === totalBillSummaryPages} aria-label="Go to next page">
                            <ChevronRight size={16} strokeWidth={2} aria-hidden="true" />
                          </Button>
                        </PaginationItem>
                      </PaginationContent>
                    </Pagination>
                  </div>}
              </> : <div className="text-center py-8">
                <p className="text-gray-600">No bill summary data available</p>
              </div>}
          </div>
          
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 md:gap-6 mb-6">
            <div className="bg-white rounded-lg shadow-sm p-4 lg:col-span-1 hover:shadow-md transition-shadow">
              <h2 className="text-lg font-semibold mb-3 md:mb-4">Block-wise Fund Distribution</h2>
              {blockFundChartData.length > 0 ? <div className="h-60 md:h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={blockFundChartData} layout="vertical" margin={{
                top: 5,
                right: 30,
                left: 90,
                bottom: 5
              }}>
                      <CartesianGrid strokeDasharray="3 3" horizontal={true} vertical={false} />
                      <XAxis type="number" />
                      <YAxis type="category" dataKey="name" tick={{
                  fontSize: 10
                }} />
                      <Tooltip />
                      <Legend />
                      <Bar dataKey="pmksy" name="PMKSY Amount" fill="#2563EB" barSize={10} />
                      <Bar dataKey="bksy" name="BKSY Amount" fill="#10B981" barSize={10} />
                    </BarChart>
                  </ResponsiveContainer>
                </div> : <div className="h-60 md:h-80 flex items-center justify-center">
                  <p className="text-gray-500">No block fund distribution data available</p>
                </div>}
            </div>
            
            <div className="bg-white rounded-lg shadow-sm p-4 lg:col-span-2 hover:shadow-md transition-shadow">
              <Tabs defaultValue="pmksy" onValueChange={setActiveTab}>
                <TabsList className="w-full grid grid-cols-2 mb-4">
                  <TabsTrigger value="pmksy">PMKSY Breakdown</TabsTrigger>
                  <TabsTrigger value="bksy">BKSY Breakdown</TabsTrigger>
                </TabsList>
                <TabsContent value="pmksy">
                  {pmksyPieData.some(item => item.value > 0) ? <div className="h-60 md:h-80">
                      <ResponsiveContainer width="100%" height="100%">
                        <PieChart>
                          <Pie data={pmksyPieData} cx="50%" cy="50%" labelLine={false} outerRadius={80} fill="#8884d8" dataKey="value">
                            {pmksyPieData.map((entry, index) => <Cell key={`cell-${index}`} fill={entry.color} />)}
                          </Pie>
                          <Tooltip />
                          <Legend />
                        </PieChart>
                      </ResponsiveContainer>
                    </div> : <div className="h-60 md:h-80 flex items-center justify-center">
                      <p className="text-gray-500">No PMKSY payment data available</p>
                    </div>}
                </TabsContent>
                <TabsContent value="bksy">
                  {bksyPieData.some(item => item.value > 0) ? <div className="h-60 md:h-80">
                      <ResponsiveContainer width="100%" height="100%">
                        <PieChart>
                          <Pie data={bksyPieData} cx="50%" cy="50%" labelLine={false} outerRadius={80} fill="#8884d8" dataKey="value">
                            {bksyPieData.map((entry, index) => <Cell key={`cell-${index}`} fill={entry.color} />)}
                          </Pie>
                          <Tooltip />
                          <Legend />
                        </PieChart>
                      </ResponsiveContainer>
                    </div> : <div className="h-60 md:h-80 flex items-center justify-center">
                      <p className="text-gray-500">No BKSY payment data available</p>
                    </div>}
                </TabsContent>
              </Tabs>
            </div>
          </div>
        </>}
      
      <Dialog open={showSchemeDetail} onOpenChange={setShowSchemeDetail}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-auto">
          <DialogHeader>
            <DialogTitle>{schemeDetailData.title}</DialogTitle>
            <DialogDescription>
              List of all farmers who received payments under this scheme
            </DialogDescription>
          </DialogHeader>
          
          <div className="mt-4">
            <Button onClick={() => exportSchemeDetails(schemeDetailData.farmers, schemeDetailData.type)} className="mb-4 bg-emerald-600 hover:bg-emerald-500">
              <Download className="h-4 w-4 mr-2" />
              Export to CSV
            </Button>
            
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Name</TableHead>
                    <TableHead>Registration No.</TableHead>
                    <TableHead>Block</TableHead>
                    <TableHead>Bill No.</TableHead>
                    <TableHead>Irrigation Type</TableHead>
                    <TableHead>Amount</TableHead>
                    
                    
                    
                    
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {schemeDetailData.farmers.map((farmer, index) => <TableRow key={index}>
                      <TableCell className="font-medium">{farmer.beneficiaryName}</TableCell>
                      <TableCell>{farmer.farmerRegistrationNumber}</TableCell>
                      <TableCell>{farmer.blockName}</TableCell>
                      <TableCell>{farmer.billNo}</TableCell>
                      <TableCell>{farmer.irrigationType}</TableCell>
                      <TableCell>
                        ₹ {schemeDetailData.type === 'pmksy' ? farmer.pmksyAmountPaid || '0' : farmer.bksyAmountPaid || '0'}
                      </TableCell>
                      
                      
                      
                      
                    </TableRow>)}
                </TableBody>
              </Table>
            </div>
          </div>
        </DialogContent>
      </Dialog>
      
      {/* New Bill Detail Dialog */}
      <Dialog open={showBillDetail} onOpenChange={setShowBillDetail}>
        <DialogContent className="max-w-5xl max-h-[90vh] overflow-auto">
          <DialogHeader>
            <DialogTitle>Bill Details: {selectedBill.billNo}</DialogTitle>
            <DialogDescription>
              Detailed information about farmers associated with this bill
            </DialogDescription>
          </DialogHeader>
          
          <div className="mt-4">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-md font-medium">Total Farmers: {selectedBill.farmers.length}</h3>
              <Button onClick={() => exportSchemeDetails(selectedBill.farmers, 'bill')} variant="outline" size="sm" className="bg-emerald-600 hover:bg-emerald-500 text-slate-50">
                <Download className="h-4 w-4 mr-2" />
                Export to CSV
              </Button>
            </div>
            
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Name</TableHead>
                    <TableHead>Registration No.</TableHead>
                    <TableHead>Block</TableHead>
                    <TableHead>Irrigation Type</TableHead>
                    <TableHead>Farmer Category</TableHead>
                    <TableHead>PMKSY Amount</TableHead>
                    <TableHead>BKSY Amount</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {selectedBill.farmers.map((farmer, index) => <TableRow key={index}>
                      <TableCell className="font-medium">{farmer.beneficiaryName || 'N/A'}</TableCell>
                      <TableCell>{farmer.farmerRegistrationNumber || 'N/A'}</TableCell>
                      <TableCell>{farmer.blockName || 'N/A'}</TableCell>
                      <TableCell>{farmer.irrigationType || 'N/A'}</TableCell>
                      <TableCell>{farmer.farmerCategory || 'N/A'}</TableCell>
                      <TableCell>
                        {parseFloat(farmer.pmksyAmountPaid || '0') > 0 ? `₹ ${farmer.pmksyAmountPaid}` : `₹ ${farmer.pmksySubsidy || '0'}`}
                      </TableCell>
                      <TableCell>
                        {parseFloat(farmer.bksyAmountPaid || '0') > 0 ? `₹ ${farmer.bksyAmountPaid}` : `₹ ${farmer.bksySubsidy || '0'}`}
                      </TableCell>
                    </TableRow>)}
                </TableBody>
              </Table>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>;
};
export default Finance;
