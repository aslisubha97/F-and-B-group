
// Utility to format CSV data consistently
import { FarmerData } from "../context/AppContext";
import { formatToDisplayDate } from "./dateUtils";

export const formatCsvData = (data: any[]): FarmerData[] => {
  // Log the headers from the first row to help with debugging
  if (data.length > 0) {
    console.log("Available columns in Excel:", Object.keys(data[0]));
  }

  return data.map((row, index) => {
    // Format date fields for display consistency
    const processDateField = (fieldValue: any): string => {
      if (!fieldValue) return '';
      return formatToDisplayDate(fieldValue);
    };
    
    // Enhanced search for beneficiary name across many possible column names
    const possibleNameColumns = [
      'Name of Beneficiary', 
      'beneficiaryName',
      'Name', 
      'BENEFICIARY NAME',
      'Beneficiary_Name',
      'name',
      'beneficiary_name',
      'FARMER NAME',
      'Farmer Name',
      'farmer_name',
      'Name of Beneficiary',
      'NAME OF BENEFICIARY',
      'name of beneficiary',
      'BENEFICIARY',
      'Beneficiary',
      'beneficiary'
    ];
    
    // Try each possible column name and use the first one that exists and has a value
    let beneficiaryName = '';
    for (const colName of possibleNameColumns) {
      if (row[colName] && String(row[colName]).trim() !== '') {
        beneficiaryName = String(row[colName]).trim();
        break;
      }
    }
    
    if (!beneficiaryName) {
      console.warn(`Row ${index + 1} has no beneficiary name. Available fields:`, Object.keys(row));
    }
    
    // Create an optimized mapping function for accessing field values with multiple possible names
    const getFieldValue = (possibleNames: string[]): string => {
      for (const name of possibleNames) {
        if (row[name] !== undefined && row[name] !== null) {
          return String(row[name]).trim();
        }
      }
      return '';
    };
    
    // Get registration number and detect financial year from it
    const registrationNumber = getFieldValue(['Farmer Registration Number', 'Registration Number', 'farmerRegistrationNumber', 'registration_number', 'REGISTRATION NUMBER']);
    
    // Detect financial year from registration number if it ends with /YYYY-YYYY pattern
    let detectedFinancialYear = '';
    if (registrationNumber) {
      const financialYearMatch = registrationNumber.match(/\/(\d{4}-\d{4})$/);
      if (financialYearMatch && financialYearMatch[1]) {
        detectedFinancialYear = financialYearMatch[1];
        console.log(`Detected financial year ${detectedFinancialYear} from registration number ${registrationNumber}`);
      }
    }
    
    // Use detected financial year if available, otherwise use the one from the data
    const financialYear = detectedFinancialYear || getFieldValue(['Financial Year', 'financialYear', 'FINANCIAL YEAR', 'financial_year']);
    
    // Create a standardized object with all possible fields using the mapping function
    const formattedData: FarmerData = {
      // Required fields - check various column name possibilities
      beneficiaryName,
      farmerRegistrationNumber: registrationNumber,
      mobileNo: getFieldValue(['Mobile No', 'mobileNo', 'Mobile', 'Mobile Number', 'mobileNumber', 'MOBILE NO', 'MOBILE NUMBER']),
      mobileNumber: getFieldValue(['Mobile No', 'mobileNo', 'Mobile', 'Mobile Number', 'mobileNumber', 'MOBILE NO', 'MOBILE NUMBER']),
      blockName: getFieldValue(['Block', 'blockName', 'Block Name', 'BLOCK', 'BLOCK NAME', 'block_name']),
      districtName: getFieldValue(['District', 'districtName', 'District Name', 'DISTRICT', 'DISTRICT NAME', 'district_name']),
      currentStatus: getFieldValue(['Status', 'currentStatus', 'Current Status', 'CURRENT STATUS', 'STATUS', 'current_status']),
      irrigationType: getFieldValue(['Irrigation Type', 'irrigationType', 'IRRIGATION TYPE', 'irrigation_type']),
      
      // Additional fields - also check for various column name possibilities
      id: '',
      docUploadStatus: getFieldValue(['Doc. Upload Status', 'Doc Upload Status', 'docUploadStatus', 'DOC UPLOAD STATUS', 'doc_upload_status']),
      taxInvNo: getFieldValue(['Tax Inv. No.', 'Tax Inv No', 'Tax Invoice', 'taxInvNo', 'Tax Invoice No', 'TAX INVOICE', 'tax_inv_no']),
      paymentDate: processDateField(getFieldValue(['Payment Date', 'paymentDate', 'PAYMENT DATE', 'payment_date'])),
      totalAmount: getFieldValue(['Total Amount', 'totalAmount', 'Amount', 'TOTAL AMOUNT', 'total_amount']),
      paymentReference: getFieldValue(['Payment Reference', 'paymentReference', 'PAYMENT REFERENCE', 'payment_reference']),
      financialYear: financialYear,
      beneficiaryType: getFieldValue(['Beneficiary Type', 'beneficiaryType', 'BENEFICIARY TYPE', 'beneficiary_type']),
      farmerCategory: getFieldValue(['Farmer Category', 'farmerCategory', 'FARMER CATEGORY', 'farmer_category']),
      sex: getFieldValue(['Sex', 'Gender', 'SEX', 'GENDER']),
      farmerStatus: getFieldValue(['Farmer Status', 'farmerStatus', 'FARMER STATUS', 'farmer_status']),
      epicNumber: getFieldValue(['Epic Number', 'epicNumber', 'EPIC NUMBER', 'epic_number']),
      aadharNumber: getFieldValue(['Aadhar Number', 'aadharNumber', 'AADHAR NUMBER', 'aadhar_number']),
      enrollmentNumber: getFieldValue(['Enrollment Number', 'enrollmentNumber', 'ENROLLMENT NUMBER', 'enrollment_number']),
      gramPanchayet: getFieldValue(['Gram Panchayet', 'Gram Panchayat', 'gramPanchayet', 'GRAM PANCHAYAT', 'gram_panchayet']),
      mouzaName: getFieldValue(['Mouza Name', 'mouzaName', 'MOUZA NAME', 'mouza_name']),
      policeStation: getFieldValue(['Police Station', 'policeStation', 'POLICE STATION', 'police_station']),
      postOffice: getFieldValue(['Post Office', 'postOffice', 'POST OFFICE', 'post_office']),
      subDivision: getFieldValue(['Sub Division', 'subDivision', 'SUB DIVISION', 'sub_division']),
      pincode: getFieldValue(['Pincode', 'Pin Code', 'pincode', 'PIN CODE', 'PINCODE']),
      cropType: getFieldValue(['Crop Type', 'cropType', 'CROP TYPE', 'crop_type']),
      cropSpacing: getFieldValue(['Crop Spacing', 'cropSpacing', 'CROP SPACING', 'crop_spacing']),
      isPumpAvailable: getFieldValue(['Is Pump Available', 'isPumpAvailable', 'IS PUMP AVAILABLE', 'is_pump_available']),
      pumpType: getFieldValue(['Pump Type', 'pumpType', 'PUMP TYPE', 'pump_type']),
      pumpCapacity: getFieldValue(['Pump Capacity', 'pumpCapacity', 'PUMP CAPACITY', 'pump_capacity']),
      indicativeCost: getFieldValue(['Indicative Cost', 'indicativeCost', 'INDICATIVE COST', 'indicative_cost']),
      waterSource: getFieldValue(['Water Source', 'waterSource', 'WATER SOURCE', 'water_source']),
      otherWaterSource: getFieldValue(['Other Water Source', 'otherWaterSource', 'OTHER WATER SOURCE', 'other_water_source']),
      registrationDate: processDateField(getFieldValue(['Registration Date', 'registrationDate', 'REGISTRATION DATE', 'registration_date'])),
      dlicNumber: getFieldValue(['DLIC Number', 'dlicNumber', 'DLIC NUMBER', 'dlic_number']),
      dlicDate: processDateField(getFieldValue(['DLIC Date', 'dlicDate', 'DLIC DATE', 'dlic_date'])),
      quotationNo: getFieldValue(['Quotation No', 'quotationNo', 'QUOTATION NO', 'quotation_no', 'Quotation No.']),
      quotationDate: processDateField(getFieldValue(['Quotation Date', 'quotationDate', 'QUOTATION DATE', 'quotation_date'])),
      pmksySubsidy: getFieldValue(['PMKSY Subsidy', 'pmksySubsidy', 'PMKSY SUBSIDY', 'pmksy_subsidy']),
      bksySubsidy: getFieldValue(['BKSY Subsidy', 'bksySubsidy', 'BKSY SUBSIDY', 'bksy_subsidy']),
      gstAmount: getFieldValue(['GST Amount', 'gstAmount', 'GST AMOUNT', 'gst_amount']),
      farmersShare: getFieldValue(['Farmers Share', 'farmersShare', 'FARMERS SHARE', 'farmers_share']),
      pmksySubsidyAddl: getFieldValue(['PMKSY Subsidy (Addl. Item)', 'PMKSY Subsidy Addl', 'pmksySubsidyAddl', 'PMKSY SUBSIDY ADDL', 'pmksy_subsidy_addl']),
      bksySubsidyAddl: getFieldValue(['BKSY Subsidy (Addl. Item)', 'BKSY Subsidy Addl', 'bksySubsidyAddl', 'BKSY SUBSIDY ADDL', 'bksy_subsidy_addl']),
      gstAmountAddl: getFieldValue(['GST Amount (Addl. Item)', 'GST Amount Addl', 'gstAmountAddl', 'GST AMOUNT ADDL', 'gst_amount_addl']),
      farmersShareAddl: getFieldValue(['Farmers Share (Addl. Item)', 'Farmers Share Addl', 'farmersShareAddl', 'FARMERS SHARE ADDL', 'farmers_share_addl']),
      totalSubsidy: getFieldValue(['Total Subsidy', 'totalSubsidy', 'TOTAL SUBSIDY', 'total_subsidy']),
      totalFarmerShare: getFieldValue(['Total Farmer Share', 'totalFarmerShare', 'TOTAL FARMER SHARE', 'total_farmer_share']),
      paidByFarmer: getFieldValue(['Paid By Farmer', 'paidByFarmer', 'PAID BY FARMER', 'paid_by_farmer']),
      typeOfPayment: getFieldValue(['Type of Payment', 'typeOfPayment', 'TYPE OF PAYMENT', 'type_of_payment']),
      jointInspDate: processDateField(getFieldValue(['Joint Insp. Date', 'Joint Insp Date', 'jointInspDate', 'JOINT INSP DATE', 'joint_insp_date'])),
      quotApprovalDate: processDateField(getFieldValue(['Quot. Approval Date', 'Quot Approval Date', 'quotApprovalDate', 'QUOT APPROVAL DATE', 'quot_approval_date'])),
      workOrderDate: processDateField(getFieldValue(['Work Order Date', 'workOrderDate', 'WORK ORDER DATE', 'work_order_date'])),
      workOrderMemo: getFieldValue(['Work Order Memo', 'workOrderMemo', 'WORK ORDER MEMO', 'work_order_memo']),
      inspectionDate: processDateField(getFieldValue(['Inspection Date', 'inspectionDate', 'INSPECTION DATE', 'inspection_date'])),
      installationDate: processDateField(getFieldValue(['Installation Date', 'installationDate', 'INSTALLATION DATE', 'installation_date'])),
      billNo: getFieldValue(['Bill No.', 'Bill No', 'billNo', 'BILL NO', 'bill_no']),
      billDate: processDateField(getFieldValue(['Bill Date', 'billDate', 'BILL DATE', 'bill_date'])),
      approvedOn: processDateField(getFieldValue(['Approved on', 'Approved On', 'approvedOn', 'APPROVED ON', 'approved_on'])),
      pmksyAmountPaid: getFieldValue(['PMKSY Amount Paid', 'pmksyAmountPaid', 'PMKSY AMOUNT PAID', 'pmksy_amount_paid']),
      pmksyCGST: getFieldValue(['PMKSY CGST', 'pmksyCGST', 'PMKSY_CGST', 'pmksy_cgst']),
      pmksySGST: getFieldValue(['PMKSY SGST', 'pmksySGST', 'PMKSY_SGST', 'pmksy_sgst']),
      pmksyTDS: getFieldValue(['PMKSY TDS', 'pmksyTDS', 'PMKSY_TDS', 'pmksy_tds']),
      pmksyReleasedOn: processDateField(getFieldValue(['PMKSY Released On', 'pmksyReleasedOn', 'PMKSY RELEASED ON', 'pmksy_released_on'])),
      pmksyTransactionRef: getFieldValue(['PMKSY Transaction Ref.', 'PMKSY Transaction Ref', 'pmksyTransactionRef', 'PMKSY TRANSACTION REF', 'pmksy_transaction_ref']),
      pmksyTransactionDate: processDateField(getFieldValue(['PMKSY Transaction Date', 'pmksyTransactionDate', 'PMKSY TRANSACTION DATE', 'pmksy_transaction_date'])),
      pmksyPaidBy: getFieldValue(['PMKSY Paid By', 'pmksyPaidBy', 'PMKSY PAID BY', 'pmksy_paid_by']),
      bksyAmountPaid: getFieldValue(['BKSY Amount Paid', 'bksyAmountPaid', 'BKSY AMOUNT PAID', 'bksy_amount_paid']),
      bksyCGST: getFieldValue(['BKSY CGST', 'bksyCGST', 'BKSY_CGST', 'bksy_cgst']),
      bksySGST: getFieldValue(['BKSY SGST', 'bksySGST', 'BKSY_SGST', 'bksy_sgst']),
      bksyTDS: getFieldValue(['BKSY TDS', 'bksyTDS', 'BKSY_TDS', 'bksy_tds']),
      bksyReleasedOn: processDateField(getFieldValue(['BKSY Released On', 'bksyReleasedOn', 'BKSY RELEASED ON', 'bksy_released_on'])),
      bksyTransactionRef: getFieldValue(['BKSY Transaction Ref.', 'BKSY Transaction Ref', 'bksyTransactionRef', 'BKSY TRANSACTION REF', 'bksy_transaction_ref']),
      bksyTransactionDate: processDateField(getFieldValue(['BKSY Transaction Date', 'bksyTransactionDate', 'BKSY TRANSACTION DATE', 'bksy_transaction_date'])),
      bksyPaidBy: getFieldValue(['BKSY Paid By', 'bksyPaidBy', 'BKSY PAID BY', 'bksy_paid_by']),
      dealerName: getFieldValue(['Dealer Name', 'dealerName', 'DEALER NAME', 'dealer_name']),
      irrigationArea: getFieldValue(['Irrigation Area', 'irrigationArea', 'IRRIGATION AREA', 'irrigation_area'])
    };
    
    // Add debug logging for troubleshooting empty names
    if (!beneficiaryName) {
      console.log(`Row ${index + 1} data:`, row);
    }
    
    return formattedData;
  });
};

// Helper function to ensure consistent string values (never undefined or null)
function getStringValue(value: any): string {
  if (value === undefined || value === null) {
    return '';
  }
  // Convert to string and trim any whitespace
  return String(value).trim();
}
