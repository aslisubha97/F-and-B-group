
/**
 * Database Configuration
 * 
 * Note: This application now uses Supabase for data storage.
 * The MySQL configuration here is kept for reference purposes only.
 * 
 * For application data persistence, we are using the Supabase client:
 * import { supabase } from "@/integrations/supabase/client";
 * 
 * For cPanel deployment, you would create a backend server
 * (Node.js/Express) to handle database operations.
 */

export const mysqlConfig = {
  host: 'localhost',      // Replace with your actual MySQL host
  user: 'username',       // Replace with your cPanel database username
  password: 'password',   // Replace with your cPanel database password
  database: 'pmksy_bksy', // Replace with your cPanel database name
  port: 3306               // Default MySQL port
};

/**
 * Sample SQL structure for the farmers table
 * 
 * CREATE TABLE farmers (
 *   id INT AUTO_INCREMENT PRIMARY KEY,
 *   farmer_registration_number VARCHAR(50),
 *   beneficiary_name VARCHAR(100),
 *   beneficiary_type VARCHAR(50),
 *   farmer_category VARCHAR(50),
 *   sex VARCHAR(10),
 *   farmer_status VARCHAR(50),
 *   epic_number VARCHAR(50),
 *   aadhar_number VARCHAR(20),
 *   enrollment_number VARCHAR(50),
 *   district_name VARCHAR(50),
 *   block_name VARCHAR(50),
 *   gram_panchayet VARCHAR(50),
 *   mouza_name VARCHAR(50),
 *   police_station VARCHAR(50),
 *   post_office VARCHAR(50),
 *   sub_division VARCHAR(50),
 *   pincode VARCHAR(10),
 *   mobile_no VARCHAR(15),
 *   irrigation_type VARCHAR(100),
 *   irrigation_area VARCHAR(50),
 *   crop_type VARCHAR(50),
 *   crop_spacing VARCHAR(50),
 *   is_pump_available VARCHAR(10),
 *   pump_type VARCHAR(50),
 *   pump_capacity VARCHAR(50),
 *   indicative_cost VARCHAR(50),
 *   water_source VARCHAR(50),
 *   other_water_source VARCHAR(50),
 *   registration_date VARCHAR(20),
 *   current_status VARCHAR(50),
 *   dlic_number VARCHAR(50),
 *   dlic_date VARCHAR(20),
 *   quotation_no VARCHAR(50),
 *   quotation_date VARCHAR(20),
 *   total_amount DECIMAL(10,2),
 *   pmksy_subsidy DECIMAL(10,2),
 *   bksy_subsidy DECIMAL(10,2),
 *   gst_amount DECIMAL(10,2),
 *   farmers_share DECIMAL(10,2),
 *   pmksy_subsidy_addl DECIMAL(10,2),
 *   bksy_subsidy_addl DECIMAL(10,2),
 *   gst_amount_addl DECIMAL(10,2),
 *   farmers_share_addl DECIMAL(10,2),
 *   total_subsidy DECIMAL(10,2),
 *   total_farmer_share DECIMAL(10,2),
 *   paid_by_farmer DECIMAL(10,2),
 *   type_of_payment VARCHAR(50),
 *   payment_reference VARCHAR(100),
 *   payment_date VARCHAR(20),
 *   joint_insp_date VARCHAR(20),
 *   quot_approval_date VARCHAR(20),
 *   work_order_date VARCHAR(20),
 *   work_order_memo VARCHAR(100),
 *   inspection_date VARCHAR(20),
 *   installation_date VARCHAR(20),
 *   bill_no VARCHAR(50),
 *   tax_inv_no VARCHAR(50),
 *   bill_date VARCHAR(20),
 *   approved_on VARCHAR(20),
 *   pmksy_amount_paid DECIMAL(10,2),
 *   pmksy_cgst DECIMAL(10,2),
 *   pmksy_sgst DECIMAL(10,2),
 *   pmksy_tds DECIMAL(10,2),
 *   pmksy_released_on VARCHAR(20),
 *   pmksy_transaction_ref VARCHAR(100),
 *   pmksy_transaction_date VARCHAR(20),
 *   pmksy_paid_by VARCHAR(100),
 *   bksy_amount_paid DECIMAL(10,2),
 *   bksy_cgst DECIMAL(10,2),
 *   bksy_sgst DECIMAL(10,2),
 *   bksy_tds DECIMAL(10,2),
 *   bksy_released_on VARCHAR(20),
 *   bksy_transaction_ref VARCHAR(100),
 *   bksy_transaction_date VARCHAR(20),
 *   bksy_paid_by VARCHAR(100),
 *   doc_upload_status VARCHAR(20),
 *   created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 *   updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
 * );
 */

/**
 * cPanel Deployment Steps
 * 
 * 1. Build the React application:
 *    - Run 'npm run build' to create a production build
 *    - This will generate a 'build' or 'dist' folder
 * 
 * 2. cPanel File Upload:
 *    - Log in to your cPanel account
 *    - Open the File Manager
 *    - Navigate to your website's root directory (usually public_html)
 *    - Upload all files from the 'build' or 'dist' folder to this directory
 * 
 * 3. Set up the MySQL Database:
 *    - In cPanel, go to MySQL Databases
 *    - Create a new database (e.g., 'pmksy_bksy')
 *    - Create a new user with a secure password
 *    - Add the user to the database with all privileges
 *    - Import the SQL structure using phpMyAdmin
 * 
 * 4. Configure Database Connection:
 *    - Update the mysqlConfig in this file with your cPanel database credentials
 *    - For security, these credentials should be stored in environment variables
 *      on the server, not directly in the code
 * 
 * 5. Set up API Endpoints:
 *    - If you need server-side processing, create a PHP API or use Node.js
 *    - Configure .htaccess for SPA routing (see below)
 * 
 * 6. Configure .htaccess for React Router:
 *    Create a .htaccess file in your root directory with:
 *    
 *    <IfModule mod_rewrite.c>
 *      RewriteEngine On
 *      RewriteBase /
 *      RewriteRule ^index\.html$ - [L]
 *      RewriteCond %{REQUEST_FILENAME} !-f
 *      RewriteCond %{REQUEST_FILENAME} !-d
 *      RewriteRule . /index.html [L]
 *    </IfModule>
 */

// Sample function for how to connect to the database from a backend
// This would be implemented in a Node.js or PHP backend, not in the React frontend
/*
export const saveFarmerDataToDatabase = async (farmerData) => {
  try {
    // Connect to the database
    const connection = await mysql.createConnection(mysqlConfig);
    
    // Clear existing data (optional)
    await connection.query('TRUNCATE TABLE farmers');
    
    // Insert new data
    for (const farmer of farmerData) {
      await connection.query(
        'INSERT INTO farmers (farmer_registration_number, beneficiary_name, ...) VALUES (?, ?, ...)',
        [farmer.farmerRegistrationNumber, farmer.beneficiaryName, ...]
      );
    }
    
    await connection.end();
    return { success: true };
  } catch (error) {
    console.error('Database error:', error);
    return { success: false, error: error.message };
  }
};
*/
