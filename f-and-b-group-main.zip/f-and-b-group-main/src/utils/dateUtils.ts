
import { format, parse, parseISO, isValid } from 'date-fns';

// Format for date display
export const formatToDisplayDate = (dateString?: string): string => {
  if (!dateString) return '-';
  
  try {
    // Handle Excel serial dates (numbers)
    if (!isNaN(Number(dateString))) {
      return formatExcelSerialDate(Number(dateString));
    }
    
    // Handle ISO date strings
    if (dateString.includes('T')) {
      const date = parseISO(dateString);
      if (isValid(date)) {
        return format(date, 'dd-MMM-yy');
      }
    }
    
    // Try different common date formats
    const formats = [
      'yyyy-MM-dd',
      'MM/dd/yyyy',
      'dd/MM/yyyy',
      'dd-MM-yyyy',
      'dd-MMM-yy',
      'dd-MMM-yyyy'
    ];
    
    for (const formatString of formats) {
      try {
        const date = parse(dateString, formatString, new Date());
        if (isValid(date)) {
          return format(date, 'dd-MMM-yy');
        }
      } catch (error) {
        // Continue trying other formats
      }
    }
    
    // If date is already in the correct format, return it as is
    if (/^\d{1,2}-[A-Za-z]{3}-\d{2}$/.test(dateString)) {
      return dateString;
    }
    
    // For any other date format that wasn't caught
    return dateString;
  } catch (error) {
    console.error("Error formatting date:", error);
    return dateString || '-';
  }
};

// Parse Excel/serial dates
export const parseExcelDate = (excelDate: string | number): string => {
  if (!excelDate) return '';
  
  try {
    // If it's already a string that doesn't look like a number, return it
    if (typeof excelDate === 'string' && isNaN(Number(excelDate))) {
      // If it's already in DD-MMM-YY format
      if (/^\d{1,2}-[A-Za-z]{3}-\d{2}$/.test(excelDate)) {
        return excelDate;
      }
      
      // Try to parse it as a date and return in our format
      const date = new Date(excelDate);
      if (isValid(date)) {
        return format(date, 'dd-MMM-yy');
      }
      return excelDate;
    }
    
    // Convert to number if it's a string representation of a number
    const excelSerialNumber = typeof excelDate === 'string' 
      ? parseFloat(excelDate) 
      : excelDate;
    
    // Excel dates start at January 0, 1900
    // 1 = January 1, 1900
    // 60 = February 29, 1900 (non-existent date, Excel has a bug)
    // 61 = March 1, 1900
    // So we need to adjust for this bug
    
    let daysSince1900 = excelSerialNumber;
    
    // Excel has a bug where it thinks 1900 was a leap year
    if (daysSince1900 > 60) {
      daysSince1900 -= 1;
    }
    
    // Calculate the date by adding the number of days to January 0, 1900
    const date = new Date(1900, 0, 0);
    date.setDate(date.getDate() + daysSince1900);
    
    return format(date, 'dd-MMM-yy');
  } catch (error) {
    console.error("Error parsing Excel date:", error);
    return String(excelDate);
  }
};

// Format Excel serial date specifically
const formatExcelSerialDate = (serialNumber: number): string => {
  try {
    // Excel dates start at January 0, 1900
    let daysSince1900 = serialNumber;
    
    // Excel has a bug where it thinks 1900 was a leap year
    if (daysSince1900 > 60) {
      daysSince1900 -= 1;
    }
    
    // Calculate the date by adding the number of days to January 0, 1900
    const date = new Date(1900, 0, 0);
    date.setDate(date.getDate() + daysSince1900);
    
    return format(date, 'dd-MMM-yy');
  } catch (error) {
    console.error("Error formatting Excel serial date:", error);
    return String(serialNumber);
  }
};

/**
 * NEW FUNCTION: Convert a date string to YYYY-MM-DD format for database storage
 * Handles various input formats including DD-MMM-YY (02-Apr-25)
 */
export const formatToISODate = (dateString?: string): string | null => {
  if (!dateString) return null;
  
  try {
    // Handle Excel serial dates (numbers)
    if (!isNaN(Number(dateString))) {
      const date = parseExcelSerialDateToDate(Number(dateString));
      if (isValid(date)) {
        return format(date, 'yyyy-MM-dd');
      }
    }
    
    // Handle ISO date strings already in correct format
    if (/^\d{4}-\d{2}-\d{2}(T.*)?$/.test(dateString)) {
      // If it's already in YYYY-MM-DD format, return just the date part
      return dateString.split('T')[0];
    }
    
    // Try to parse common DD-MMM-YY format (like 02-Apr-25)
    if (/^\d{1,2}-[A-Za-z]{3}-\d{2}$/.test(dateString)) {
      const date = parse(dateString, 'dd-MMM-yy', new Date());
      if (isValid(date)) {
        return format(date, 'yyyy-MM-dd');
      }
    }
    
    // Try other common date formats
    const formats = [
      'dd-MMM-yyyy',
      'MM/dd/yyyy',
      'dd/MM/yyyy',
      'dd-MM-yyyy'
    ];
    
    for (const formatString of formats) {
      try {
        const date = parse(dateString, formatString, new Date());
        if (isValid(date)) {
          return format(date, 'yyyy-MM-dd');
        }
      } catch (error) {
        // Continue trying other formats
      }
    }
    
    // If we couldn't parse it with any known format, try native Date
    const date = new Date(dateString);
    if (isValid(date)) {
      return format(date, 'yyyy-MM-dd');
    }
    
    return null;
  } catch (error) {
    console.error("Error converting to ISO date:", error, dateString);
    return null;
  }
};

// Add a helper function to extract financial year from registration number
export const getFinancialYearFromRegNumber = (regNumber?: string): string => {
  if (!regNumber) return '';
  
  const match = regNumber.match(/\/(\d{4}-\d{4})$/);
  if (match && match[1]) {
    return match[1];
  }
  
  return '';
};

// Get all financial years from the data
export const getAllFinancialYears = (data: any[]): string[] => {
  const years = data
    .map(item => getFinancialYearFromRegNumber(item.farmerRegistrationNumber))
    .filter(Boolean);
  
  const uniqueYears = Array.from(new Set(years));
  
  // Sort years in descending order
  return [
    'All',
    ...uniqueYears.sort((a, b) => {
      const yearA = parseInt(a.split('-')[0]);
      const yearB = parseInt(b.split('-')[0]);
      return yearB - yearA;
    })
  ];
};

// Format date to Month Year format (e.g., "Apr 2023")
export const formatToMonthYear = (dateString?: string): string => {
  if (!dateString) return '';
  
  try {
    // Handle Excel serial dates (numbers)
    if (!isNaN(Number(dateString))) {
      const date = parseExcelSerialDateToDate(Number(dateString));
      if (isValid(date)) {
        return format(date, 'MMM yyyy');
      }
    }
    
    // Handle ISO date strings
    if (dateString.includes('T')) {
      const date = parseISO(dateString);
      if (isValid(date)) {
        return format(date, 'MMM yyyy');
      }
    }
    
    // Try different common date formats
    const formats = [
      'yyyy-MM-dd',
      'MM/dd/yyyy',
      'dd/MM/yyyy',
      'dd-MM-yyyy',
      'dd-MMM-yy',
      'dd-MMM-yyyy'
    ];
    
    for (const formatString of formats) {
      try {
        const date = parse(dateString, formatString, new Date());
        if (isValid(date)) {
          return format(date, 'MMM yyyy');
        }
      } catch (error) {
        // Continue trying other formats
      }
    }
    
    // Check if the input is already in MMM yyyy format
    if (/^[A-Za-z]{3} \d{4}$/.test(dateString)) {
      return dateString;
    }
    
    // Just extract month and year from the string as fallback
    const match = dateString.match(/([A-Za-z]{3}).*?(\d{2,4})/);
    if (match) {
      const [_, month, year] = match;
      const fullYear = year.length === 2 ? `20${year}` : year;
      return `${month} ${fullYear}`;
    }
    
    return '';
  } catch (error) {
    console.error("Error formatting date to month year:", error, dateString);
    return '';
  }
};

// Parse Excel serial date to a Date object
const parseExcelSerialDateToDate = (serialNumber: number): Date => {
  // Excel dates start at January 0, 1900
  let daysSince1900 = serialNumber;
  
  // Excel has a bug where it thinks 1900 was a leap year
  if (daysSince1900 > 60) {
    daysSince1900 -= 1;
  }
  
  // Calculate the date by adding the number of days to January 0, 1900
  const date = new Date(1900, 0, 0);
  date.setDate(date.getDate() + daysSince1900);
  
  return date;
};

// Get sorted months from a given range of farmers with payment dates
export const getSortedMonthsInRange = (farmers: any[]): string[] => {
  const months = new Set<string>();
  
  farmers.forEach(farmer => {
    if (farmer.paymentDate) {
      const monthYear = formatToMonthYear(farmer.paymentDate);
      if (monthYear) {
        months.add(monthYear);
      }
    }
  });
  
  // Sort months chronologically
  return Array.from(months).sort((a, b) => {
    try {
      const dateA = parse(a, 'MMM yyyy', new Date());
      const dateB = parse(b, 'MMM yyyy', new Date());
      return dateA.getTime() - dateB.getTime();
    } catch (error) {
      return a.localeCompare(b);
    }
  });
};

