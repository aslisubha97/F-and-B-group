
import React, { useEffect, useState } from 'react';
import Layout from '../components/Layout';
import Invoice from '../components/Invoice';
import { useAppContext } from '../context/AppContext';
import { AlertCircle } from 'lucide-react';
import Preloader from '../components/Preloader';

const InvoicePage = () => {
  const { 
    filteredFarmerData,
    loading, 
    selectedFinancialYear,
    dataLoadError 
  } = useAppContext();
  
  const [pageReady, setPageReady] = useState(false);
  
  // Update page title to include financial year if not "All Years"
  useEffect(() => {
    const yearSuffix = selectedFinancialYear !== 'All Years' ? ` (${selectedFinancialYear})` : '';
    document.title = `Invoice Dashboard${yearSuffix} | PMKSY-BKSY`;
    console.log(`Invoice Page: Applied financial year filter: ${selectedFinancialYear}`);
  }, [selectedFinancialYear]);
  
  // Ensure preloader shows until data is fully loaded
  useEffect(() => {
    if (!loading && filteredFarmerData) {
      // Add a small delay to ensure data processing is complete
      const timer = setTimeout(() => {
        setPageReady(true);
      }, 300);
      
      return () => clearTimeout(timer);
    } else {
      setPageReady(false);
    }
  }, [loading, filteredFarmerData]);
  
  return (
    <Layout>
      {!pageReady && <Preloader />}
      
      <div className="mb-4 text-left">
        <h1 className="text-xl md:text-2xl font-bold">
          Invoice Dashboard
          {selectedFinancialYear !== 'All Years' && (
            <span className="ml-2 text-base font-medium text-gray-500">
              ({selectedFinancialYear})
            </span>
          )}
        </h1>
      </div>
      
      {loading ? (
        <div className="flex justify-center items-center p-8">
          {/* Empty because we now have a preloader */}
        </div>
      ) : dataLoadError ? (
        <div className="bg-white rounded-lg shadow p-6 text-center">
          <AlertCircle className="h-12 w-12 mx-auto text-amber-500 mb-4" />
          <p className="text-red-500 mb-4">{dataLoadError}</p>
          <p className="text-gray-600">Please upload farmer data or check your database connection.</p>
        </div>
      ) : (
        <div className="space-y-8">
          <Invoice />
        </div>
      )}
    </Layout>
  );
};

export default InvoicePage;
