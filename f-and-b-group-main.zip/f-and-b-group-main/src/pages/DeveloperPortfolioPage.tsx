
import React from 'react';
import DeveloperPortfolio from '../components/DeveloperPortfolio';
import Layout from '../components/Layout';

const DeveloperPortfolioPage = () => {
  return (
    <Layout>
      <DeveloperPortfolio />
    </Layout>
  );
};

export default DeveloperPortfolioPage;
