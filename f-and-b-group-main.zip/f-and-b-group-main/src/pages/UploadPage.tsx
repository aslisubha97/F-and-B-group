
import React from 'react';
import Layout from '../components/Layout';
import CsvUpload from '../components/CsvUpload';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { AlertCircle, FileSpreadsheet } from 'lucide-react';
import { useAppContext } from '../context/AppContext';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Heading } from '../components/ui/heading';

const UploadPage = () => {
  const { farmerData } = useAppContext();
  
  return (
    <Layout>
      <div className="mb-4">
        <Heading title="Data Management" description="Upload and manage farmer data" />
        
        {farmerData.length > 0 && (
          <Alert className="mb-4 bg-amber-50 border-amber-200">
            <AlertCircle className="h-4 w-4 text-amber-600" />
            <AlertTitle className="text-amber-800">Important Note</AlertTitle>
            <AlertDescription className="text-amber-700">
              You currently have {farmerData.length} farmer records loaded. Uploading a new file will replace all existing data.
            </AlertDescription>
          </Alert>
        )}
        
        <Card>
          <CardHeader className="bg-gray-50 border-b">
            <div className="flex items-center">
              <FileSpreadsheet className="h-6 w-6 text-blue-600 mr-2" />
              <div>
                <CardTitle className="text-xl">Excel Upload</CardTitle>
                <CardDescription>Import farmer data from Excel or CSV files</CardDescription>
              </div>
            </div>
          </CardHeader>
          <CardContent className="pt-6">
            <CsvUpload />
          </CardContent>
        </Card>
      </div>
    </Layout>
  );
};

export default UploadPage;
