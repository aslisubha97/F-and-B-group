
import React, { useEffect, useState } from 'react';
import Layout from '../components/Layout';
import { useAppContext } from '../context/AppContext';
import { Upload, FileText, AlertCircle } from 'lucide-react';
import Preloader from '../components/Preloader';
import { Heading } from '../components/ui/heading';
import { Button } from '@/components/ui/button';
import { useNavigate } from 'react-router-dom';
import SearchableFarmers from '../components/SearchableFarmers';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import AnalyticsOverview from '../components/analytics/AnalyticsOverview';
import AnalyticsFinancial from '../components/analytics/AnalyticsFinancial';
import MissingDocsReport from '../components/MissingDocsReport';
import MissingBillReport from '../components/MissingBillReport';
import { Badge } from '@/components/ui/badge';
import { Popover, PopoverTrigger, PopoverContent } from '@/components/ui/popover';

const FarmersPage = () => {
  const {
    loading,
    dataLoadError,
    selectedFinancialYear,
    filteredFarmerData
  } = useAppContext();
  
  const [activeTab, setActiveTab] = useState('overview');
  const [showMissingDocsReport, setShowMissingDocsReport] = useState(false);
  const [showMissingBillReport, setShowMissingBillReport] = useState(false);
  const navigate = useNavigate();
  
  useEffect(() => {
    const yearSuffix = selectedFinancialYear !== 'All Years' ? ` (${selectedFinancialYear})` : '';
    document.title = `Analytics${yearSuffix} | PMKSY-BKSY`;
  }, [selectedFinancialYear]);
  
  const handleUploadData = () => {
    navigate('/upload');
  };

  // Updated criteria to match the component criteria exactly
  const missingDocsCount = filteredFarmerData.filter(f => 
    f.currentStatus?.toLowerCase().includes('install') && 
    f.currentStatus?.toLowerCase().includes('inspected') && 
    (!f.docUploadStatus || f.docUploadStatus === 'Insp. File Missing')
  ).length;
  
  // Updated to match the MissingBillReport component's criteria exactly
  const missingBillCount = filteredFarmerData.filter(f => {
    const isInstalledAndInspected = f.currentStatus?.toLowerCase().includes('installed & inspected');
    const hasPaymentReference = !!f.paymentReference;
    const noBillNumber = !f.billNo || f.billNo.trim() === '';
    
    return isInstalledAndInspected && hasPaymentReference && noBillNumber;
  }).length;

  // Content to display when there's a data load error
  const renderErrorContent = () => (
    <div className="bg-white rounded-lg shadow-md p-6 text-center">
      <div className="flex flex-col items-center justify-center space-y-4">
        <div className="rounded-full bg-amber-100 p-3">
          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-6 w-6 text-amber-600"><path d="m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3Z"></path><line x1="12" y1="9" x2="12" y2="13"></line><line x1="12" y1="17" x2="12.01" y2="17"></line></svg>
        </div>
        <div>
          <p className="text-lg font-semibold text-red-600">{dataLoadError}</p>
          <p className="text-gray-600 mt-1">Please upload farmer data or check your database connection.</p>
        </div>
        <Button onClick={handleUploadData} className="mt-2">
          <Upload className="h-4 w-4 mr-2" />
          Upload Farmer Data
        </Button>
      </div>
    </div>
  );

  // Advanced search component
  const renderSearchArea = () => (
    <div className="mb-8 bg-white p-4 rounded-lg shadow">
      <h3 className="text-lg font-medium mb-3">Find Farmers</h3>
      <SearchableFarmers />
    </div>
  );

  return (
    <Layout>
      <Preloader />
      
      {/* Page Header with Tabs */}
      <div className="mb-6 space-y-4">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <Heading 
            title={`Analytics Dashboard${selectedFinancialYear !== 'All Years' ? ` (${selectedFinancialYear})` : ''}`} 
            description="Explore farmer registrations, demographics, and key metrics" 
          />
          
          <div className="flex flex-wrap gap-2 self-end">
            {/* Missing Documentation Report Button */}
            <Button 
              variant="outline" 
              onClick={() => setShowMissingDocsReport(true)}
              className="relative"
              disabled={loading || !!dataLoadError}
            >
              <FileText className="h-4 w-4 mr-2 text-amber-600" />
              Missing Docs
              {missingDocsCount > 0 && (
                <Badge variant="destructive" className="ml-2 -mr-1">
                  {missingDocsCount}
                </Badge>
              )}
            </Button>
            
            {/* Missing Bill Report Button */}
            <Button 
              variant="outline" 
              onClick={() => setShowMissingBillReport(true)}
              className="relative"
              disabled={loading || !!dataLoadError}
            >
              <AlertCircle className="h-4 w-4 mr-2 text-red-600" />
              Missing Bills
              {missingBillCount > 0 && (
                <Badge variant="destructive" className="ml-2 -mr-1">
                  {missingBillCount}
                </Badge>
              )}
            </Button>
            
            {/* Upload Data Button */}
            <Button 
              onClick={handleUploadData} 
              className="bg-emerald-600 hover:bg-emerald-700"
            >
              <Upload className="h-4 w-4 mr-2" />
              Upload Data
            </Button>
          </div>
        </div>
        
        <Tabs 
          defaultValue="overview" 
          className="w-full" 
          onValueChange={setActiveTab}
          value={activeTab}
        >
          <TabsList className="grid grid-cols-2 md:w-[400px]">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="financial">Financial</TabsTrigger>
          </TabsList>
          
          {/* Search Area - Only show when data is loaded and no error */}
          {!loading && !dataLoadError && (
            <div>{renderSearchArea()}</div>
          )}
          
          {/* Overview Tab */}
          <TabsContent value="overview" className="mt-0">
            {loading ? (
              <div className="animate-pulse bg-gray-100 rounded-lg h-96"></div>
            ) : dataLoadError ? (
              renderErrorContent()
            ) : (
              <AnalyticsOverview />
            )}
          </TabsContent>
          
          {/* Financial Tab */}
          <TabsContent value="financial" className="mt-0">
            {loading ? (
              <div className="animate-pulse bg-gray-100 rounded-lg h-96"></div>
            ) : dataLoadError ? (
              renderErrorContent()
            ) : (
              <AnalyticsFinancial />
            )}
          </TabsContent>
        </Tabs>
      </div>
      
      {/* Report Dialogs */}
      <MissingDocsReport isOpen={showMissingDocsReport} onClose={() => setShowMissingDocsReport(false)} />
      <MissingBillReport isOpen={showMissingBillReport} onClose={() => setShowMissingBillReport(false)} />
    </Layout>
  );
};

export default FarmersPage;
