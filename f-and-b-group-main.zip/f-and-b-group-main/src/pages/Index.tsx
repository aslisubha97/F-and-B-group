
import React, { useEffect, useState } from 'react';
import Layout from '../components/Layout';
import Dashboard from '../components/Dashboard';
import { useAppContext } from '../context/AppContext';
import { AlertCircle } from 'lucide-react';
import { Heading } from '../components/ui/heading';
import { useNavigate } from 'react-router-dom';
import Preloader from '../components/Preloader';

const Index = () => {
  const { filteredFarmerData, loading, dataLoadError, selectedFinancialYear } = useAppContext();
  const navigate = useNavigate();
  const [pageReady, setPageReady] = useState(false);
  
  useEffect(() => {
    // Update the document title with financial year if not "All Years"
    const yearSuffix = selectedFinancialYear !== 'All Years' ? ` (${selectedFinancialYear})` : '';
    document.title = `Dashboard${yearSuffix} | PMKSY-BKSY`;
    console.log(`Dashboard Page: Applied financial year filter: ${selectedFinancialYear}`);
  }, [selectedFinancialYear]);

  // Add preloader effect
  useEffect(() => {
    if (!loading && filteredFarmerData) {
      // Add a small delay to ensure data processing is complete
      const timer = setTimeout(() => {
        setPageReady(true);
      }, 300);
      
      return () => clearTimeout(timer);
    } else {
      setPageReady(false);
    }
  }, [loading, filteredFarmerData]);

  return (
    <Layout>
      {!pageReady && <Preloader />}
      
      <div className="mb-6 text-center">
        <Heading
          title={`Dashboard${selectedFinancialYear !== 'All Years' ? ` (${selectedFinancialYear})` : ''}`}
          description="Explore farmer data and statistics across blocks"
        />
      </div>
      
      {dataLoadError ? (
        <div className="bg-white rounded-lg shadow p-6 text-center">
          <AlertCircle className="h-12 w-12 mx-auto text-amber-500 mb-4" />
          <p className="text-red-500 mb-4">{dataLoadError}</p>
          <p className="text-gray-600">Please upload farmer data or check your database connection.</p>
        </div>
      ) : (
        <Dashboard />
      )}
    </Layout>
  );
};

export default Index;
