
import React, { useEffect, useState } from 'react';
import Layout from '../components/Layout';
import BlockDetail from '../components/BlockDetail';
import { useParams, useLocation } from 'react-router-dom';
import { useAppContext } from '../context/AppContext';
import Preloader from '../components/Preloader';

const BlockDetailPage = () => {
  const { blockName } = useParams<{ blockName: string }>();
  const location = useLocation();
  const { selectedFinancialYear } = useAppContext();
  const [pageReady, setPageReady] = useState(false);
  const { loading, blockSummaries } = useAppContext();
  
  // Update page title with block name and financial year
  useEffect(() => {
    if (blockName) {
      const yearSuffix = selectedFinancialYear !== 'All Years' ? ` (${selectedFinancialYear})` : '';
      document.title = `${blockName}${yearSuffix} | PMKSY-BKSY`;
    }
  }, [blockName, selectedFinancialYear]);
  
  // Add preloader effect
  useEffect(() => {
    if (!loading && blockSummaries.length > 0) {
      // Add a small delay to ensure data processing is complete
      const timer = setTimeout(() => {
        setPageReady(true);
      }, 300);
      
      return () => clearTimeout(timer);
    } else {
      setPageReady(false);
    }
  }, [loading, blockSummaries]);
  
  return (
    <Layout>
      {!pageReady && <Preloader />}
      <div className="max-w-7xl mx-auto">
        {blockName && <BlockDetail blockName={blockName} />}
      </div>
    </Layout>
  );
};

export default BlockDetailPage;
