
import React, { useState, useEffect } from 'react';
import Layout from '../components/Layout';
import Finance from '../components/Finance';
import Preloader from '../components/Preloader';
import { useAppContext } from '../context/AppContext';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { toast } from '@/components/ui/use-toast';
import { AlertCircle } from 'lucide-react';

const FinancePage = () => {
  const { filteredFarmerData, loading, dataLoadError, selectedFinancialYear } = useAppContext();
  const [billNumberSearch, setBillNumberSearch] = useState('');

  useEffect(() => {
    // Update the document title with financial year if not "All Years"
    const yearSuffix = selectedFinancialYear !== 'All Years' ? ` (${selectedFinancialYear})` : '';
    document.title = `Finance Dashboard${yearSuffix} | PMKSY-BKSY`;
    console.log(`Finance Page: Applied financial year filter: ${selectedFinancialYear}`);
  }, [selectedFinancialYear]);

  const handleSearch = () => {
    if (!billNumberSearch.trim()) {
      toast({
        title: "Error",
        description: "Please enter a bill number to search",
        variant: "destructive"
      });
      return;
    }
    
    // Use filteredFarmerData which already has financial year filtering applied from context
    const farmersWithBill = filteredFarmerData.filter(farmer => 
      farmer.billNo && farmer.billNo.includes(billNumberSearch)
    );
    
    if (farmersWithBill.length === 0) {
      toast({
        title: "No Results",
        description: `No farmers found with bill number containing "${billNumberSearch}"${
          selectedFinancialYear !== 'All Years' ? ` in ${selectedFinancialYear}` : ''
        }`,
        variant: "destructive"
      });
    } else {
      toast({
        title: "Search Results",
        description: `Found ${farmersWithBill.length} farmers with bill number containing "${billNumberSearch}"${
          selectedFinancialYear !== 'All Years' ? ` in ${selectedFinancialYear}` : ''
        }`
      });
    }
  };

  return (
    <Layout>
      <Preloader />
      <div className="mb-6 text-left">
        <h1 className="text-xl md:text-2xl font-bold mb-4">
          Finance Dashboard
          {selectedFinancialYear !== 'All Years' && (
            <span className="ml-2 text-base font-medium text-gray-500">
              ({selectedFinancialYear})
            </span>
          )}
        </h1>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
          <div className="text-left">
            <label className="block text-sm font-medium text-gray-700 mb-1">Search by Bill Number</label>
            <div className="flex">
              <Input 
                type="text" 
                placeholder="Enter bill number" 
                value={billNumberSearch} 
                onChange={e => setBillNumberSearch(e.target.value)} 
                className="mr-2" 
              />
              <Button 
                onClick={handleSearch} 
                className="bg-emerald-600 hover:bg-emerald-500"
              >
                Search
              </Button>
            </div>
          </div>
        </div>
      </div>
      
      {loading ? (
        <div className="flex justify-center items-center p-8">
          {/* Remove duplicate loading indicator since we have Preloader */}
        </div>
      ) : dataLoadError ? (
        <div className="bg-white rounded-lg shadow p-6 text-center">
          <AlertCircle className="h-12 w-12 mx-auto text-amber-500 mb-4" />
          <p className="text-red-500 mb-4">{dataLoadError}</p>
          <p className="text-gray-600">Please upload farmer data or check your database connection.</p>
        </div>
      ) : (
        <Finance billNumberSearch={billNumberSearch} />
      )}
    </Layout>
  );
};

export default FinancePage;
