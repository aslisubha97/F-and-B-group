import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import { AppProvider } from "./context/AppContext";
import { Toaster } from "@/components/ui/toaster";
import { Toaster as SonnerToaster } from "sonner";
import Index from "./pages/Index";
import FarmersPage from "./pages/FarmersPage";
import FinancePage from "./pages/FinancePage";
import InvoicePage from "./pages/InvoicePage";
import NotFound from "./pages/NotFound";
import BlockDetailPage from "./pages/BlockDetailPage";
import UploadPage from "./pages/UploadPage";
import DeveloperPortfolioPage from "./pages/DeveloperPortfolioPage";

import "./App.css";

function App() {
  return (
    <AppProvider>
      <Router>
        <Routes>
          <Route path="/" element={<Index />} />
          <Route path="/farmers" element={<FarmersPage />} />
          <Route path="/finance" element={<FinancePage />} />
          <Route path="/invoice" element={<InvoicePage />} />
          <Route path="/upload" element={<UploadPage />} />
          <Route path="/block/:blockName" element={<BlockDetailPage />} />
          <Route path="/developer-portfolio" element={<DeveloperPortfolioPage />} />
          <Route path="*" element={<NotFound />} />
        </Routes>
      </Router>
      <Toaster />
      <SonnerToaster position="top-right" />
    </AppProvider>
  );
}

export default App;
