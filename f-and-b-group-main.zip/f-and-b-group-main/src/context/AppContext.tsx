
import React, { createContext, useContext, useState, ReactNode, useEffect } from 'react';
import { supabase } from "@/integrations/supabase/client";
import { toast } from '@/components/ui/use-toast';
import { formatToDisplayDate } from '../utils/dateUtils';

// Define farmer data interface to ensure consistent data structure
export interface FarmerData {
  id?: string;
  beneficiaryName: string;
  farmerRegistrationNumber: string;
  mobileNo: string;
  mobileNumber: string;
  blockName: string;
  districtName: string;
  currentStatus: string;
  irrigationType: string;
  docUploadStatus: string;
  taxInvNo: string;
  paymentDate: string;
  totalAmount: string;
  paymentReference: string;
  financialYear: string;
  beneficiaryType: string;
  farmerCategory: string;
  sex: string;
  farmerStatus: string;
  epicNumber: string;
  aadharNumber: string;
  enrollmentNumber: string;
  gramPanchayet: string;
  mouzaName: string;
  policeStation: string;
  postOffice: string;
  subDivision: string;
  pincode: string;
  cropType: string;
  cropSpacing: string;
  isPumpAvailable: string;
  pumpType: string;
  pumpCapacity: string;
  indicativeCost: string;
  waterSource: string;
  otherWaterSource: string;
  registrationDate: string;
  dlicNumber: string;
  dlicDate: string;
  quotationNo: string;
  quotationDate: string;
  pmksySubsidy: string;
  bksySubsidy: string;
  gstAmount: string;
  farmersShare: string;
  pmksySubsidyAddl: string;
  bksySubsidyAddl: string;
  gstAmountAddl: string;
  farmersShareAddl: string;
  totalSubsidy: string;
  totalFarmerShare: string;
  paidByFarmer: string;
  typeOfPayment: string;
  jointInspDate: string;
  quotApprovalDate: string;
  workOrderDate: string;
  workOrderMemo: string;
  inspectionDate: string;
  installationDate: string;
  billNo: string;
  billDate: string;
  approvedOn: string;
  pmksyAmountPaid: string;
  pmksyCGST: string;
  pmksySGST: string;
  pmksyTDS: string;
  pmksyReleasedOn: string;
  pmksyTransactionRef: string;
  pmksyTransactionDate: string;
  pmksyPaidBy: string;
  bksyAmountPaid: string;
  bksyCGST: string;
  bksySGST: string;
  bksyTDS: string;
  bksyReleasedOn: string;
  bksyTransactionRef: string;
  bksyTransactionDate: string;
  bksyPaidBy: string;
  dealerName: string;
  irrigationArea: string;
  // Adding the missing properties
  installDate?: string;
  pmksyAmount?: string;
  bksyAmount?: string;
}

// Define block summary interface for tracking block-level data
export interface BlockSummary {
  blockName: string;
  districtName: string;
  totalRegistered: number;
  newRegistration: number;
  jointInspection: number;
  workOrder: number;
  install: number;
  installAndInspected: number;
  invoiceDue: {
    [key: string]: number;
  };
}

// Define app context interface
interface AppContextType {
  farmerData: FarmerData[];
  setFarmerData: React.Dispatch<React.SetStateAction<FarmerData[]>>;
  blockSummaries: BlockSummary[];
  setBlockSummaries: React.Dispatch<React.SetStateAction<BlockSummary[]>>;
  loading: boolean;
  setLoading: React.Dispatch<React.SetStateAction<boolean>>;
  isLoggedIn: boolean;
  setIsLoggedIn: React.Dispatch<React.SetStateAction<boolean>>;
  showLoginModal: boolean;
  setShowLoginModal: React.Dispatch<React.SetStateAction<boolean>>;
  login: (username: string, password: string) => boolean;
  refreshData: () => Promise<void>;
  selectedFinancialYear: string;
  setSelectedFinancialYear: React.Dispatch<React.SetStateAction<string>>;
  financialYears: string[];
  filteredFarmerData: FarmerData[];
  dataLoadError: string | null;
}

// Create context with default values
const AppContext = createContext<AppContextType>({
  farmerData: [],
  setFarmerData: () => {},
  blockSummaries: [],
  setBlockSummaries: () => {},
  loading: false,
  setLoading: () => {},
  isLoggedIn: false,
  setIsLoggedIn: () => {},
  showLoginModal: false,
  setShowLoginModal: () => {},
  login: () => false,
  refreshData: async () => {},
  selectedFinancialYear: 'All Years',
  setSelectedFinancialYear: () => {},
  financialYears: [],
  filteredFarmerData: [],
  dataLoadError: null
});

// Create provider component
export const AppProvider = ({ children }: { children: ReactNode }) => {
  // Initialize state with empty arrays
  const [farmerData, setFarmerData] = useState<FarmerData[]>([]);
  const [blockSummaries, setBlockSummaries] = useState<BlockSummary[]>([]);
  const [loading, setLoading] = useState<boolean>(false);
  const [dataLoadError, setDataLoadError] = useState<string | null>(null);
  
  // Auth state
  const [isLoggedIn, setIsLoggedIn] = useState<boolean>(!!localStorage.getItem('isLoggedIn'));
  const [showLoginModal, setShowLoginModal] = useState<boolean>(false);
  
  // Financial year state
  const [selectedFinancialYear, setSelectedFinancialYear] = useState<string>('All Years');
  const [financialYears, setFinancialYears] = useState<string[]>([]);
  
  // State for filtered farmer data
  const [filteredFarmerData, setFilteredFarmerData] = useState<FarmerData[]>([]);
  
  // Login function with simple authentication
  const login = (username: string, password: string): boolean => {
    // Simple authentication check - hardcoded for demo purposes
    // In production, this should be replaced with a proper auth system
    if (username === 'admin' && password === 'admin123') {
      localStorage.setItem('isLoggedIn', 'true');
      setIsLoggedIn(true);
      return true;
    }
    return false;
  };
  
  // Apply financial year filtering whenever selectedFinancialYear or farmerData changes
  useEffect(() => {
    if (farmerData.length > 0) {
      console.log(`Financial year filter applied: ${selectedFinancialYear}. Filtering data...`);
      
      const filtered = selectedFinancialYear === 'All Years'
        ? farmerData
        : farmerData.filter(farmer => farmer.financialYear === selectedFinancialYear);
      
      console.log(`Filtered data: ${filtered.length} records out of ${farmerData.length} total records`);
      setFilteredFarmerData(filtered);
      
      // Also update block summaries based on filtered data
      const blockGroups: { [key: string]: FarmerData[] } = {};
      filtered.forEach(farmer => {
        if (farmer.blockName) {
          if (!blockGroups[farmer.blockName]) {
            blockGroups[farmer.blockName] = [];
          }
          blockGroups[farmer.blockName].push(farmer);
        }
      });
      
      const summaries = Object.entries(blockGroups).map(([blockName, farmers]) => {
        const districtName = farmers[0]?.districtName || '';
        
        const newRegistration = farmers.filter(f => 
          f.currentStatus && f.currentStatus.toLowerCase().includes('new registration')
        ).length;
        
        const jointInspection = farmers.filter(f => 
          f.currentStatus && f.currentStatus.toLowerCase().includes('joint inspection')
        ).length;
        
        const workOrder = farmers.filter(f => 
          f.currentStatus && f.currentStatus.toLowerCase().includes('work order')
        ).length;
        
        const install = farmers.filter(f => {
          if (!f.currentStatus) return false;
          const status = f.currentStatus.toLowerCase();
          return status.includes('install') && !status.includes('inspect');
        }).length;
        
        const installAndInspected = farmers.filter(f => {
          if (!f.currentStatus) return false;
          const status = f.currentStatus.toLowerCase();
          return status.includes('install') && status.includes('inspect');
        }).length;
        
        const invoiceDue: { [key: string]: number } = {};
        
        return {
          blockName,
          districtName,
          totalRegistered: farmers.length,
          newRegistration,
          jointInspection,
          workOrder,
          install,
          installAndInspected,
          invoiceDue
        };
      });
      
      setBlockSummaries(summaries);
      
      console.log(`Created ${summaries.length} block summaries from ${filtered.length} farmer records (Financial Year: ${selectedFinancialYear})`);
    }
  }, [selectedFinancialYear, farmerData]);
  
  // Function to load data from Supabase - can be called to refresh data
  const refreshData = async () => {
    try {
      setLoading(true);
      console.info("AppContext: Loading data from Supabase");
      
      // First check if the connection to Supabase is working
      try {
        const { error: pingError } = await supabase.from('farmers').select('count').limit(1);
        if (pingError) {
          console.error("Error connecting to Supabase:", pingError);
          throw new Error("Failed to connect to database. Please check your internet connection.");
        }
      } catch (connectionError) {
        console.error("Connection test failed:", connectionError);
        toast({
          title: 'Connection Error',
          description: 'Failed to connect to database. Please check your internet connection.',
          variant: 'destructive'
        });
        throw connectionError;
      }
      
      // Get all farmers data - ensure we don't limit the data
      const { data: farmersData, error: farmersError } = await supabase
        .from('farmers')
        .select('*');
      
      if (farmersError) {
        console.error("Error fetching farmers data:", farmersError);
        throw farmersError;
      }
      
      // Get all invoices
      const { data: invoiceData, error: invoiceError } = await supabase
        .from('invoices')
        .select('*');
      
      if (invoiceError) {
        console.error("Error fetching invoices data:", invoiceError);
        throw invoiceError;
      }
      
      console.info(`AppContext: Loaded ${farmersData?.length || 0} farmers and ${invoiceData?.length || 0} invoices`);
      
      // It's OK if there's no data yet - the user might be uploading for the first time
      // We don't want to show an error in this case
      if (!farmersData?.length) {
        console.info("No farmers data found in Supabase - this is expected for first-time use");
        setFarmerData([]);
        setBlockSummaries([]);
        setFilteredFarmerData([]);
        return;
      }
      
      // Map data to our expected format
      const mappedData: FarmerData[] = farmersData.map(farmer => {
        const invoice = invoiceData?.find(inv => inv.farmer_id === farmer.id);
        
        return {
          id: farmer.id || '',
          beneficiaryName: farmer.beneficiary_name || '',
          farmerRegistrationNumber: farmer.registration_number || '',
          mobileNo: farmer.mobile_number || '',
          mobileNumber: farmer.mobile_number || '',
          blockName: farmer.block_name || '',
          districtName: farmer.district_name || '',
          currentStatus: farmer.current_status || '',
          irrigationType: farmer.irrigation_type || '',
          docUploadStatus: farmer.doc_upload_status || '',
          taxInvNo: invoice?.tax_inv_no || '',
          paymentDate: invoice?.payment_date ? formatToDisplayDate(invoice.payment_date) : '',
          totalAmount: invoice?.amount?.toString() || '',
          paymentReference: invoice?.payment_reference || '',
          financialYear: farmer.financial_year || '',
          beneficiaryType: farmer.beneficiary_type || '',
          farmerCategory: farmer.farmer_category || '',
          sex: farmer.sex || '',
          farmerStatus: farmer.farmer_status || '',
          epicNumber: farmer.epic_number || '',
          aadharNumber: farmer.aadhar_number || '',
          enrollmentNumber: farmer.enrollment_number || '',
          gramPanchayet: farmer.gram_panchayet || '',
          mouzaName: farmer.mouza_name || '',
          policeStation: farmer.police_station || '',
          postOffice: farmer.post_office || '',
          subDivision: farmer.sub_division || '',
          pincode: farmer.pincode || '',
          cropType: farmer.crop_type || '',
          cropSpacing: farmer.crop_spacing || '',
          isPumpAvailable: farmer.is_pump_available || '',
          pumpType: farmer.pump_type || '',
          pumpCapacity: farmer.pump_capacity || '',
          indicativeCost: farmer.indicative_cost || '',
          waterSource: farmer.water_source || '',
          otherWaterSource: farmer.other_water_source || '',
          registrationDate: formatToDisplayDate(farmer.registration_date) || '',
          dlicNumber: invoice?.dlic_number || '',
          dlicDate: formatToDisplayDate(invoice?.dlic_date) || '',
          quotationNo: invoice?.quotation_no || '',
          quotationDate: formatToDisplayDate(invoice?.quotation_date) || '',
          pmksySubsidy: invoice?.pmksy_subsidy?.toString() || '',
          bksySubsidy: invoice?.bksy_subsidy?.toString() || '',
          gstAmount: invoice?.gst_amount?.toString() || '',
          farmersShare: invoice?.farmers_share?.toString() || '',
          pmksySubsidyAddl: invoice?.pmksy_subsidy_addl?.toString() || '',
          bksySubsidyAddl: invoice?.bksy_subsidy_addl?.toString() || '',
          gstAmountAddl: invoice?.gst_amount_addl?.toString() || '',
          farmersShareAddl: invoice?.farmers_share_addl?.toString() || '',
          totalSubsidy: invoice?.total_subsidy?.toString() || '',
          totalFarmerShare: invoice?.total_farmer_share?.toString() || '',
          paidByFarmer: invoice?.paid_by_farmer?.toString() || '',
          typeOfPayment: invoice?.type_of_payment || '',
          jointInspDate: formatToDisplayDate(invoice?.joint_insp_date) || '',
          quotApprovalDate: formatToDisplayDate(invoice?.quot_approval_date) || '',
          workOrderDate: formatToDisplayDate(invoice?.work_order_date) || '',
          workOrderMemo: invoice?.work_order_memo || '',
          inspectionDate: formatToDisplayDate(invoice?.inspection_date) || '',
          installationDate: formatToDisplayDate(invoice?.installation_date) || '',
          // Map installation_date to installDate as well for component usage
          installDate: formatToDisplayDate(invoice?.installation_date) || '',
          billNo: invoice?.bill_no || '',
          billDate: formatToDisplayDate(invoice?.bill_date) || '',
          approvedOn: formatToDisplayDate(invoice?.approved_on) || '',
          pmksyAmountPaid: invoice?.pmksy_amount_paid?.toString() || '',
          // Map pmksy_subsidy to pmksyAmount for component usage
          pmksyAmount: invoice?.pmksy_subsidy?.toString() || '',
          pmksyCGST: invoice?.pmksy_cgst?.toString() || '',
          pmksySGST: invoice?.pmksy_sgst?.toString() || '',
          pmksyTDS: invoice?.pmksy_tds?.toString() || '',
          pmksyReleasedOn: formatToDisplayDate(invoice?.pmksy_released_on) || '',
          pmksyTransactionRef: invoice?.pmksy_transaction_ref || '',
          pmksyTransactionDate: formatToDisplayDate(invoice?.pmksy_transaction_date) || '',
          pmksyPaidBy: invoice?.pmksy_paid_by || '',
          bksyAmountPaid: invoice?.bksy_amount_paid?.toString() || '',
          // Map bksy_subsidy to bksyAmount for component usage
          bksyAmount: invoice?.bksy_subsidy?.toString() || '',
          bksyCGST: invoice?.bksy_cgst?.toString() || '',
          bksySGST: invoice?.bksy_sgst?.toString() || '',
          bksyTDS: invoice?.bksy_tds?.toString() || '',
          bksyReleasedOn: formatToDisplayDate(invoice?.bksy_released_on) || '',
          bksyTransactionRef: invoice?.bksy_transaction_ref || '',
          bksyTransactionDate: formatToDisplayDate(invoice?.bksy_transaction_date) || '',
          bksyPaidBy: invoice?.bksy_paid_by || '',
          dealerName: farmer.dealer_name || '',
          irrigationArea: farmer.irrigation_area || '',
        };
      });
      
      // Extract unique financial years from the data
      const uniqueFinancialYears = Array.from(
        new Set(mappedData.map(farmer => farmer.financialYear).filter(Boolean))
      ).sort();
      
      setFinancialYears(uniqueFinancialYears);
      setFarmerData(mappedData);
      
      // Filtered data will be updated by the useEffect
      
      // Save to localStorage as backup
      try {
        localStorage.setItem('farmerData', JSON.stringify(mappedData));
        localStorage.setItem('financialYears', JSON.stringify(uniqueFinancialYears));
        console.info(`Saved ${mappedData.length} farmer records to localStorage for backup`);
      } catch (err) {
        console.error('Error saving data to localStorage:', err);
      }
      
      toast({
        title: 'Data Loaded',
        description: `${mappedData.length} farmer records loaded successfully.`,
      });
    } catch (error: any) {
      console.error('Error loading data from Supabase:', error);
      
      // Try to load from localStorage as fallback
      const savedFarmerData = localStorage.getItem('farmerData');
      const savedBlockSummaries = localStorage.getItem('blockSummaries');
      const savedFinancialYears = localStorage.getItem('financialYears');
      
      if (savedFarmerData && savedBlockSummaries) {
        try {
          const parsedFarmerData = JSON.parse(savedFarmerData);
          const parsedBlockSummaries = JSON.parse(savedBlockSummaries);
          const parsedFinancialYears = savedFinancialYears ? JSON.parse(savedFinancialYears) : [];
          
          setFarmerData(parsedFarmerData);
          setBlockSummaries(parsedBlockSummaries);
          setFinancialYears(parsedFinancialYears);
          
          toast({
            title: 'Data Loaded from Cache',
            description: `${parsedFarmerData.length} farmer records loaded from cache.`,
          });
          console.info(`Loaded ${parsedFarmerData.length} farmer records from localStorage fallback`);
        } catch (parseError) {
          console.error('Error parsing saved data:', parseError);
          toast({
            title: 'Error',
            description: 'Failed to load data. Please try refreshing the page.',
            variant: 'destructive'
          });
        }
      } else {
        toast({
          title: 'Error',
          description: 'Failed to load data from Supabase or cache. You may need to upload data first.',
          variant: 'destructive'
        });
      }
    } finally {
      setLoading(false);
    }
  };
  
  // Load data on initial mount
  useEffect(() => {
    refreshData();
  }, []);
  
  return (
    <AppContext.Provider 
      value={{ 
        farmerData, setFarmerData, 
        blockSummaries, setBlockSummaries,
        loading, setLoading,
        isLoggedIn, setIsLoggedIn,
        showLoginModal, setShowLoginModal,
        login, refreshData,
        selectedFinancialYear, setSelectedFinancialYear,
        financialYears, filteredFarmerData, dataLoadError
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

// Custom hook for using the context
export const useAppContext = () => useContext(AppContext);
