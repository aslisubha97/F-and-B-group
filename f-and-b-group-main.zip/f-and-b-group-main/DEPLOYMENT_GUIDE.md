
# Irrigation Management System Deployment Guide

This guide will help you deploy the Irrigation Management System to production with Supabase integration. Follow these steps to ensure a successful deployment.

## Prerequisites

Before you begin, make sure you have:

1. A hosting service (Vercel, Netlify, AWS Amplify, or traditional hosting)
2. A Supabase account (free tier is available)
3. Access to your domain's DNS settings (if using a custom domain)

## Step 1: Setting Up Supabase

### Create a Supabase Project

1. Go to [Supabase](https://supabase.com/) and sign up or log in
2. Click "New Project" and fill in the details:
   - Name your project (e.g., "irrigation-management")
   - Set a secure database password (save this for later)
   - Choose the region closest to your users
   - Click "Create new project"

### Set Up Database Tables

Once your project is created, set up the necessary tables:

#### 1. Farmers Table

```sql
CREATE TABLE farmers (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  farmer_registration_number VARCHAR NOT NULL,
  beneficiary_name VARCHAR NOT NULL,
  block_name VARCHAR,
  gram_panchayet VARCHAR,
  district_name VARCHAR,
  irrigation_type VARCHAR,
  farmer_category VARCHAR,
  current_status VARCHAR,
  work_order_date DATE,
  install_date DATE,
  tax_inv_no VARCHAR,
  bill_date DATE,
  payment_date DATE,
  payment_reference VARCHAR,
  pmksy_subsidy NUMERIC(10,2),
  pmksy_amount_paid NUMERIC(10,2),
  bksy_subsidy NUMERIC(10,2),
  bksy_amount_paid NUMERIC(10,2),
  total_amount NUMERIC(10,2),
  doc_upload BOOLEAN DEFAULT FALSE,
  mobile_number VARCHAR,
  financial_year VARCHAR,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create an index for faster searches
CREATE INDEX idx_farmer_reg_number ON farmers(farmer_registration_number);
CREATE INDEX idx_block_name ON farmers(block_name);
CREATE INDEX idx_district_name ON farmers(district_name);
CREATE INDEX idx_financial_year ON farmers(financial_year);
```

#### 2. Users Table

```sql
CREATE TABLE users (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  email VARCHAR UNIQUE NOT NULL,
  role VARCHAR DEFAULT 'user',
  block_access VARCHAR[], -- Array of blocks this user has access to (null for all)
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  last_sign_in TIMESTAMP WITH TIME ZONE
);
```

### Set Up Row Level Security (RLS)

Enable RLS on your tables to ensure data security:

```sql
-- Enable RLS on farmers table
ALTER TABLE farmers ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Allow authenticated users to read farmers data"
  ON farmers
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Allow administrators to modify farmers data"
  ON farmers
  FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM users
      WHERE users.id = auth.uid() AND users.role = 'admin'
    )
  );
```

### Set Up Authentication

1. Go to Authentication > Settings in Supabase dashboard
2. Configure Email Auth:
   - Enable "Email signup"
   - Set minimum password length
   - Configure your email provider for transactional emails

## Step 2: Connect Your React App to Supabase

### Install Supabase Client

The app already has Supabase installed. If you need to update it:

```
npm install @supabase/supabase-js
```

### Configure Environment Variables

Create a `.env.local` file (for local development) and set these variables:

```
VITE_SUPABASE_URL=your-project-url
VITE_SUPABASE_ANON_KEY=your-anon-key
```

You can find these values in your Supabase dashboard under Settings > API.

### Initialize Supabase Client

The app already has Supabase client configuration in `src/integrations/supabase/client.ts`:

```typescript
import { createClient } from '@supabase/supabase-js'

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY

export const supabase = createClient(supabaseUrl, supabaseAnonKey)
```

## Step 3: Implement Data Synchronization

### Create Database Functions

Create these functions in Supabase SQL Editor:

```sql
-- Function to get block summaries
CREATE OR REPLACE FUNCTION get_block_summaries(year_filter TEXT)
RETURNS TABLE (
  block_name TEXT,
  district_name TEXT,
  total_registered BIGINT,
  new_registration BIGINT,
  joint_inspection BIGINT,
  work_order BIGINT,
  install BIGINT,
  install_and_inspected BIGINT
) AS $$
BEGIN
  RETURN QUERY
  SELECT 
    f.block_name,
    f.district_name,
    COUNT(*) AS total_registered,
    COUNT(*) FILTER (WHERE f.current_status ILIKE '%new registration%') AS new_registration,
    COUNT(*) FILTER (WHERE f.current_status ILIKE '%joint inspection%') AS joint_inspection,
    COUNT(*) FILTER (WHERE f.current_status ILIKE '%work order%') AS work_order,
    COUNT(*) FILTER (WHERE f.current_status ILIKE '%install%' AND NOT f.current_status ILIKE '%inspect%') AS install,
    COUNT(*) FILTER (WHERE f.current_status ILIKE '%install%' AND f.current_status ILIKE '%inspect%') AS install_and_inspected
  FROM 
    farmers f
  WHERE
    (year_filter = 'All Years' OR f.financial_year = year_filter)
  GROUP BY 
    f.block_name, f.district_name
  ORDER BY 
    f.block_name;
END;
$$ LANGUAGE plpgsql;
```

### Implement CSV Upload Function

Create an Edge Function in Supabase to handle CSV uploads:

1. Go to Edge Functions in Supabase dashboard
2. Create a new function named "upload-csv"
3. Use this code template:

```typescript
import { serve } from 'https://deno.land/std@0.131.0/http/server.ts'
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'
import { parse } from 'https://deno.land/std@0.181.0/csv/parse.ts'

serve(async (req) => {
  // Get the authorization header
  const authHeader = req.headers.get('Authorization')
  if (!authHeader) {
    return new Response(JSON.stringify({ error: 'No authorization header' }), {
      headers: { 'Content-Type': 'application/json' },
      status: 401,
    })
  }

  // Setup Supabase client with the auth header
  const supabaseClient = createClient(
    Deno.env.get('SUPABASE_URL') ?? '',
    Deno.env.get('SUPABASE_ANON_KEY') ?? '',
    { global: { headers: { Authorization: authHeader } } }
  )
  
  // Parse CSV data from request
  const formData = await req.formData()
  const file = formData.get('file')
  
  if (!file || !(file instanceof File)) {
    return new Response(JSON.stringify({ error: 'No file uploaded' }), {
      headers: { 'Content-Type': 'application/json' },
      status: 400,
    })
  }
  
  const text = await file.text()
  const rows = parse(text, { skipFirstRow: true })
  
  // Process each row
  const processed = []
  for (const row of rows) {
    // Map CSV columns to database fields
    const farmerData = {
      farmer_registration_number: row[0],
      beneficiary_name: row[1],
      block_name: row[2],
      gram_panchayet: row[3],
      district_name: row[4],
      irrigation_type: row[5],
      farmer_category: row[6],
      current_status: row[7],
      work_order_date: row[8] ? row[8] : null,
      install_date: row[9] ? row[9] : null,
      tax_inv_no: row[10],
      bill_date: row[11] ? row[11] : null,
      payment_date: row[12] ? row[12] : null,
      payment_reference: row[13],
      financial_year: row[14] || 'Unknown',
      // Add other fields as needed
    }
    
    // Check if farmer already exists
    const { data: existingFarmer } = await supabaseClient
      .from('farmers')
      .select('id')
      .eq('farmer_registration_number', farmerData.farmer_registration_number)
      .single()
    
    if (existingFarmer) {
      // Update existing farmer
      const { error } = await supabaseClient
        .from('farmers')
        .update(farmerData)
        .eq('id', existingFarmer.id)
      
      if (!error) processed.push(farmerData.farmer_registration_number)
    } else {
      // Insert new farmer
      const { error } = await supabaseClient
        .from('farmers')
        .insert(farmerData)
      
      if (!error) processed.push(farmerData.farmer_registration_number)
    }
  }
  
  return new Response(
    JSON.stringify({ 
      success: true, 
      processed: processed.length,
      message: `Successfully processed ${processed.length} records` 
    }),
    { headers: { 'Content-Type': 'application/json' } },
  )
})
```

4. Deploy the function with:
```
supabase functions deploy upload-csv
```

## Step 4: Build and Deploy the Frontend

### Build the React App

1. Create production environment variables:
   - Create a `.env.production` file with your Supabase production URLs

2. Build the application:
```
npm run build
```

### Deploy to Hosting Service

#### Option 1: Deploy to Vercel

1. Push your code to GitHub
2. Connect your GitHub repository to Vercel
3. Configure the build settings:
   - Build Command: `npm run build`
   - Output Directory: `dist`
   - Install Command: `npm install`
4. Add the environment variables in Vercel

#### Option 2: Deploy to Netlify

1. Push your code to GitHub
2. Connect your GitHub repository to Netlify
3. Configure the build settings:
   - Build Command: `npm run build`
   - Publish Directory: `dist`
4. Add the environment variables in Netlify

#### Option 3: Traditional Web Hosting

1. Upload the contents of the `dist` folder to your web server
2. Configure your server to redirect all routes to `index.html`
3. For Apache, create a `.htaccess` file:

```
<IfModule mod_rewrite.c>
  RewriteEngine On
  RewriteBase /
  RewriteRule ^index\.html$ - [L]
  RewriteCond %{REQUEST_FILENAME} !-f
  RewriteCond %{REQUEST_FILENAME} !-d
  RewriteRule . /index.html [L]
</IfModule>
```

## Step 5: Set Up Custom Domain (Optional)

1. Purchase a domain if you don't have one
2. Configure DNS settings to point to your hosting provider
3. Set up SSL certificate for HTTPS

## Step 6: Post-Deployment Testing

After deployment, test these critical features:

1. User authentication (signup/login)
2. CSV data upload 
3. Dashboard data visualization
4. Filtering and searching functionality
5. Financial reporting features
6. Mobile responsiveness

## Step 7: Setting Up Admin User

Create your first admin user:

1. Register a new user through the app
2. Go to Supabase SQL Editor and run:

```sql
UPDATE users 
SET role = 'admin' 
WHERE email = 'your-admin-email@example.com';
```

## Monitoring and Maintenance

### Database Backups

Supabase automatically backs up your database daily. For additional protection:

1. Go to Project Settings > Database
2. Configure scheduled backups

### Performance Monitoring

Monitor your app's performance:

1. Use Supabase dashboard to monitor database performance
2. Consider adding application monitoring with tools like Sentry

### Updates and Maintenance

1. Regularly update dependencies for security patches
2. Monitor Supabase changelogs for important updates
3. Schedule regular maintenance windows for updates

## Troubleshooting Common Issues

### Authentication Problems

If users can't log in:
- Check if email verification is required
- Verify authentication settings in Supabase

### Data Not Loading

If data isn't appearing:
- Check network requests for API errors
- Verify RLS policies are correctly configured
- Check if the user has proper permissions

### Database Errors

For database-related errors:
- Review SQL logs in Supabase dashboard
- Check table constraints and relationships

## Security Best Practices

1. **Always use Row Level Security** - Never disable RLS in production
2. **Protect API Keys** - Never expose admin keys in frontend code
3. **Regular Security Audits** - Periodically review access logs and permissions
4. **Enable MFA** - For Supabase dashboard access and admin accounts

## Support Resources

- Supabase Documentation: [https://supabase.com/docs](https://supabase.com/docs)
- React Documentation: [https://react.dev/](https://react.dev/)
- Tailwind CSS Documentation: [https://tailwindcss.com/docs](https://tailwindcss.com/docs)

## Conclusion

This deployment guide covers everything needed to set up your Irrigation Management System with Supabase integration. By following these steps, you'll have a secure, scalable, and maintainable application that meets the needs of your users.

For additional assistance or customization, contact your development team or refer to the codebase documentation.
